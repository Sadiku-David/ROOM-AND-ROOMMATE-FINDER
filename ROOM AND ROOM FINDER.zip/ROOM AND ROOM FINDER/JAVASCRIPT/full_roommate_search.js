/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);






var page_full_roommate_search_ek1 = document.createElement("div");
page_full_roommate_search_ek1.id = "page_full_roommate_search_ek1";
page_full_roommate_search_ek1.style.width = "433px";
page_full_roommate_search_ek1.style.height = "801px";
page_full_roommate_search_ek1.style.left = "0px";
page_full_roommate_search_ek1.style.top = "0px";
page_full_roommate_search_ek1.style.position = "absolute";
content_container.appendChild(page_full_roommate_search_ek1);

var _bg__full_roommate_search_ek2 = document.createElement("div");
_bg__full_roommate_search_ek2.id = "_bg__full_roommate_search_ek2";
_bg__full_roommate_search_ek2.style.left = "0px";
_bg__full_roommate_search_ek2.style.top = "0px";
_bg__full_roommate_search_ek2.style.width = "433px";
_bg__full_roommate_search_ek2.style.height = "801px";
_bg__full_roommate_search_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_full_roommate_search_ek1.appendChild(_bg__full_roommate_search_ek2);

var frame_4 = document.createElement("div");
frame_4.id = "frame_4";
frame_4.style.width = "433px";
frame_4.style.height = "1248px";
frame_4.style.left = "0px";
frame_4.style.top = "0px";
frame_4.style.position = "absolute";
page_full_roommate_search_ek1.appendChild(frame_4);

var bitmap = document.createElement("div");
bitmap.id = "bitmap";
bitmap.style.width = "428px";
bitmap.style.height = "253px";
bitmap.style.left = "5px";
bitmap.style.top = "0px";
bitmap.style.position = "absolute";
frame_4.appendChild(bitmap);

var mask = document.createElement("div");
mask.id = "mask";
mask.style.left = "0px";
mask.style.top = "0px";
mask.style.width = "428px";
mask.style.height = "253px";
mask.style.background = 'rgba(215.99,215.99,215.99,1)';

bitmap.appendChild(mask);

var mask_ek1 = document.createElement("div");
mask_ek1.id = "mask_ek1";
mask_ek1.style.left = "0px";
mask_ek1.style.top = "0px";
mask_ek1.style.width = "428px";
mask_ek1.style.height = "253px";
mask_ek1.style.background = 'rgba(215.99,215.99,215.99,1)';

bitmap.appendChild(mask_ek1);

var bitmap_ek1 = document.createElement("img");
bitmap_ek1.id = "bitmap_ek1";
bitmap_ek1.style.left = "0px";
bitmap_ek1.style.top = "0px";
bitmap_ek1.style.width = "432.57px";
bitmap_ek1.style.height = "253px";
bitmap_ek1.src = "skins/bitmap_ek1.png";

bitmap.appendChild(bitmap_ek1);

var rectangle = document.createElement("div");
rectangle.id = "rectangle";
rectangle.style.left = "5px";
rectangle.style.opacity = "0.8";
rectangle.style.filter = "alpha(opacity='80')";
rectangle.style.top = "173px";
rectangle.style.width = "428px";
rectangle.style.height = "80px";
rectangle.style.background = 'rgba(255,255,255,0)';
rectangle.style.background = "linear-gradient(-180deg , rgba(0,0,0,0) 0%, rgba(0,0,0,1) 100%)";

frame_4.appendChild(rectangle);

var group_ek5 = document.createElement("div");
group_ek5.id = "group_ek5";
group_ek5.style.width = "40px";
group_ek5.style.height = "40px";
group_ek5.style.left = "29px";
group_ek5.style.top = "29px";
group_ek5.style.position = "absolute";
frame_4.appendChild(group_ek5);

var oval = document.createElement("div");
oval.id = "oval";
oval.style.left = "0px";
oval.style.opacity = "0.20000000298023";
oval.style.filter = "alpha(opacity='20.000000298023')";
oval.style.top = "0px";
oval.style.width = "40px";
oval.style.height = "40px";
oval.style.borderRadius = "20px / 20px";
oval.style.background = 'rgba(255,255,255,0.2)';

group_ek5.appendChild(oval);

var combined_shape = document.createElement("img");
combined_shape.id = "combined_shape";
combined_shape.style.left = "12px";
combined_shape.style.top = "12px";
combined_shape.style.width = "16.71px";
combined_shape.style.height = "16.71px";
combined_shape.src = "skins/combined_shape.png";

group_ek5.appendChild(combined_shape);

var __1_200___mo = document.createElement("div");
__1_200___mo.innerHTML = "<span style=\"font-style:normal; font-weight:normal; text-decoration:NONE; \"> 500,000 </span><span style=\"font-size:17; font-style:normal; font-weight:normal; text-decoration:NONE; \">/ m</span>";
__1_200___mo.style.textAlign = "left";
__1_200___mo.id = "__1_200___mo";
__1_200___mo.style.left = "30.29px";
__1_200___mo.style.top = "197px";
__1_200___mo.style.width = "170.5px";
__1_200___mo.style.height = "46.5px";
__1_200___mo.style.fontFamily = "Poppins";
__1_200___mo.style.fontSize = "21px";
__1_200___mo.style.overflow = "hidden";
__1_200___mo.style.color = "#FFFFFF";

frame_4.appendChild(__1_200___mo);

var vector_ek40 = document.createElement("img");
vector_ek40.id = "vector_ek40";
vector_ek40.style.left = "20px";
vector_ek40.style.top = "206px";
vector_ek40.style.width = "16.62px";
vector_ek40.style.height = "13.13px";
vector_ek40.src = "skins/vector_ek40.png";

frame_4.appendChild(vector_ek40);

var group_6 = document.createElement("div");
group_6.id = "group_6";
group_6.style.width = "56px";
group_6.style.height = "56px";
group_6.style.left = "327px";
group_6.style.top = "225px";
group_6.style.position = "absolute";
frame_4.appendChild(group_6);

var oval_ek1 = document.createElement("div");
oval_ek1.id = "oval_ek1";
oval_ek1.style.left = "0px";
oval_ek1.style.top = "0px";
oval_ek1.style.width = "56px";
oval_ek1.style.height = "56px";
oval_ek1.style.borderRadius = "28px / 28px";
oval_ek1.style.background = 'rgba(203,90,122,1)';

group_6.appendChild(oval_ek1);

var subtitles = document.createElement("div");
subtitles.id = "subtitles";
subtitles.style.width = "24px";
subtitles.style.height = "24px";
subtitles.style.left = "16px";
subtitles.style.top = "16px";
subtitles.style.position = "absolute";
group_6.appendChild(subtitles);

var phone_call = document.createElement("div");
phone_call.id = "phone_call";
phone_call.style.width = "24px";
phone_call.style.height = "24px";
phone_call.style.left = "0px";
phone_call.style.top = "0px";
phone_call.style.position = "absolute";
subtitles.appendChild(phone_call);

var combined_shape_ek1 = document.createElement("img");
combined_shape_ek1.id = "combined_shape_ek1";
combined_shape_ek1.style.left = "0px";
combined_shape_ek1.style.top = "0px";
combined_shape_ek1.style.width = "24px";
combined_shape_ek1.style.height = "24px";
combined_shape_ek1.src = "skins/combined_shape_ek1.png";

phone_call.appendChild(combined_shape_ek1);

var group_2 = document.createElement("div");
group_2.id = "group_2";
group_2.style.width = "48px";
group_2.style.height = "8px";
group_2.style.left = "28px";
group_2.style.top = "273px";
group_2.style.position = "absolute";
frame_4.appendChild(group_2);

var oval_ek2 = document.createElement("div");
oval_ek2.id = "oval_ek2";
oval_ek2.style.left = "0px";
oval_ek2.style.top = "0px";
oval_ek2.style.width = "8px";
oval_ek2.style.height = "8px";
oval_ek2.style.borderRadius = "4px / 4px";
oval_ek2.style.background = 'rgba(203,90,122,1)';

group_2.appendChild(oval_ek2);

var oval_ek3 = document.createElement("div");
oval_ek3.id = "oval_ek3";
oval_ek3.style.left = "20px";
oval_ek3.style.opacity = "0.20999999344349";
oval_ek3.style.filter = "alpha(opacity='20.999999344349')";
oval_ek3.style.top = "0px";
oval_ek3.style.width = "8px";
oval_ek3.style.height = "8px";
oval_ek3.style.borderRadius = "4px / 4px";
oval_ek3.style.background = 'rgba(203,90,122,0.21)';

group_2.appendChild(oval_ek3);

var oval_ek4 = document.createElement("div");
oval_ek4.id = "oval_ek4";
oval_ek4.style.left = "40px";
oval_ek4.style.opacity = "0.20999999344349";
oval_ek4.style.filter = "alpha(opacity='20.999999344349')";
oval_ek4.style.top = "0px";
oval_ek4.style.width = "8px";
oval_ek4.style.height = "8px";
oval_ek4.style.borderRadius = "4px / 4px";
oval_ek4.style.background = 'rgba(203,90,122,0.21)';

group_2.appendChild(oval_ek4);

var midtown_south__new_y = document.createElement("div");
midtown_south__new_y.innerHTML = "Midtown Street, Maitama";
midtown_south__new_y.style.textAlign = "left";
midtown_south__new_y.id = "midtown_south__new_y";
midtown_south__new_y.style.left = "29px";
midtown_south__new_y.style.top = "301px";
midtown_south__new_y.style.width = "244.5px";
midtown_south__new_y.style.height = "33.5px";
midtown_south__new_y.style.fontFamily = "Poppins";
midtown_south__new_y.style.fontSize = "15px";
midtown_south__new_y.style.overflow = "hidden";
midtown_south__new_y.style.color = "#303135";

frame_4.appendChild(midtown_south__new_y);

var _70_west_37th_street = document.createElement("div");
_70_west_37th_street.innerHTML = "Block 5 Opposite Total St";
_70_west_37th_street.style.textAlign = "left";
_70_west_37th_street.id = "_70_west_37th_street";
_70_west_37th_street.style.left = "28px";
_70_west_37th_street.style.top = "319px";
_70_west_37th_street.style.width = "309.5px";
_70_west_37th_street.style.height = "46.5px";
_70_west_37th_street.style.fontFamily = "Poppins";
_70_west_37th_street.style.fontSize = "21px";
_70_west_37th_street.style.overflow = "hidden";
_70_west_37th_street.style.color = "#303135";

frame_4.appendChild(_70_west_37th_street);

var group_4 = document.createElement("div");
group_4.id = "group_4";
group_4.style.width = "301px";
group_4.style.height = "18px";
group_4.style.left = "28px";
group_4.style.top = "357px";
group_4.style.position = "absolute";
frame_4.appendChild(group_4);

var group_3 = document.createElement("div");
group_3.id = "group_3";
group_3.style.width = "67px";
group_3.style.height = "18px";
group_3.style.left = "0px";
group_3.style.top = "0px";
group_3.style.position = "absolute";
group_4.appendChild(group_3);

var _12_sqft = document.createElement("div");
_12_sqft.innerHTML = "12 sqft";
_12_sqft.style.textAlign = "left";
_12_sqft.id = "_12_sqft";
_12_sqft.style.left = "24px";
_12_sqft.style.top = "0px";
_12_sqft.style.width = "66.5px";
_12_sqft.style.height = "33.5px";
_12_sqft.style.fontFamily = "Poppins";
_12_sqft.style.fontSize = "15px";
_12_sqft.style.overflow = "hidden";
_12_sqft.style.color = "#757984";

group_3.appendChild(_12_sqft);

var measurement = document.createElement("div");
measurement.id = "measurement";
measurement.style.width = "16px";
measurement.style.height = "12px";
measurement.style.left = "0px";
measurement.style.top = "3px";
measurement.style.position = "absolute";
group_3.appendChild(measurement);

var combined_shape_ek2 = document.createElement("img");
combined_shape_ek2.id = "combined_shape_ek2";
combined_shape_ek2.style.left = "0px";
combined_shape_ek2.style.top = "0px";
combined_shape_ek2.style.width = "16px";
combined_shape_ek2.style.height = "12px";
combined_shape_ek2.src = "skins/combined_shape_ek2.png";

measurement.appendChild(combined_shape_ek2);

var group_2_ek1 = document.createElement("div");
group_2_ek1.id = "group_2_ek1";
group_2_ek1.style.width = "70px";
group_2_ek1.style.height = "18px";
group_2_ek1.style.left = "91px";
group_2_ek1.style.top = "0px";
group_2_ek1.style.position = "absolute";
group_4.appendChild(group_2_ek1);

var _2_baths = document.createElement("div");
_2_baths.innerHTML = "2 baths";
_2_baths.style.textAlign = "left";
_2_baths.id = "_2_baths";
_2_baths.style.left = "23px";
_2_baths.style.top = "0px";
_2_baths.style.width = "76.5px";
_2_baths.style.height = "33.5px";
_2_baths.style.fontFamily = "Poppins";
_2_baths.style.fontSize = "15px";
_2_baths.style.overflow = "hidden";
_2_baths.style.color = "#757984";

group_2_ek1.appendChild(_2_baths);

var shower = document.createElement("div");
shower.id = "shower";
shower.style.width = "15px";
shower.style.height = "15px";
shower.style.left = "0px";
shower.style.top = "2px";
shower.style.position = "absolute";
group_2_ek1.appendChild(shower);

var combined_shape_ek3 = document.createElement("img");
combined_shape_ek3.id = "combined_shape_ek3";
combined_shape_ek3.style.left = "0px";
combined_shape_ek3.style.top = "0px";
combined_shape_ek3.style.width = "15px";
combined_shape_ek3.style.height = "15px";
combined_shape_ek3.src = "skins/combined_shape_ek3.png";

shower.appendChild(combined_shape_ek3);

var group_ek6 = document.createElement("div");
group_ek6.id = "group_ek6";
group_ek6.style.width = "116px";
group_ek6.style.height = "18px";
group_ek6.style.left = "185px";
group_ek6.style.top = "0px";
group_ek6.style.position = "absolute";
group_4.appendChild(group_ek6);

var bedroom = document.createElement("div");
bedroom.id = "bedroom";
bedroom.style.width = "16px";
bedroom.style.height = "13px";
bedroom.style.left = "0px";
bedroom.style.top = "3px";
bedroom.style.position = "absolute";
group_ek6.appendChild(bedroom);

var combined_shape_ek4 = document.createElement("img");
combined_shape_ek4.id = "combined_shape_ek4";
combined_shape_ek4.style.left = "0px";
combined_shape_ek4.style.top = "0px";
combined_shape_ek4.style.width = "16px";
combined_shape_ek4.style.height = "13px";
combined_shape_ek4.src = "skins/combined_shape_ek4.png";

bedroom.appendChild(combined_shape_ek4);

var _3_beds_in_total = document.createElement("div");
_3_beds_in_total.innerHTML = "3 beds in total ";
_3_beds_in_total.style.textAlign = "left";
_3_beds_in_total.id = "_3_beds_in_total";
_3_beds_in_total.style.left = "24px";
_3_beds_in_total.style.top = "0px";
_3_beds_in_total.style.width = "126.5px";
_3_beds_in_total.style.height = "33.5px";
_3_beds_in_total.style.fontFamily = "Poppins";
_3_beds_in_total.style.fontSize = "15px";
_3_beds_in_total.style.overflow = "hidden";
_3_beds_in_total.style.color = "#757984";

group_ek6.appendChild(_3_beds_in_total);

var rectangle_ek1 = document.createElement("div");
rectangle_ek1.id = "rectangle_ek1";
rectangle_ek1.style.left = "20px";
rectangle_ek1.style.top = "395px";
rectangle_ek1.style.width = "382px";
rectangle_ek1.style.height = "1px";
rectangle_ek1.style.background = 'rgba(215.2,217.67,225.1,1)';

frame_4.appendChild(rectangle_ek1);

var room_description = document.createElement("div");
room_description.innerHTML = "Room description";
room_description.style.textAlign = "left";
room_description.id = "room_description";
room_description.style.left = "20px";
room_description.style.top = "406px";
room_description.style.width = "166.5px";
room_description.style.height = "33.5px";
room_description.style.fontFamily = "Poppins";
room_description.style.fontSize = "15px";
room_description.style.overflow = "hidden";
room_description.style.color = "#303135";

frame_4.appendChild(room_description);

var feel_at_home_whereve = document.createElement("div");
feel_at_home_whereve.innerHTML = "<span style=\"font-style:normal; font-weight:normal; text-decoration:NONE; \">Feel at home wherever you choose to live with.Youll<br/>love this sophisticated Midtown furnished one-<br/>bedroom apartment with its modern decor, fully <br/>equipped kitchen, and cheery living room with great <br/>balcony views. Ideally located, youre close to all the <br/>best that Abuja has to off</span><span style=\"color:#CB5A7A; font-style:normal; font-weight:normal; text-decoration:NONE; \">er re</span>";
feel_at_home_whereve.style.textAlign = "left";
feel_at_home_whereve.id = "feel_at_home_whereve";
feel_at_home_whereve.style.left = "20px";
feel_at_home_whereve.style.top = "427px";
feel_at_home_whereve.style.width = "423px";
feel_at_home_whereve.style.height = "130px";
feel_at_home_whereve.style.fontFamily = "Poppins";
feel_at_home_whereve.style.fontSize = "14px";
feel_at_home_whereve.style.lineHeight = "20px";
feel_at_home_whereve.style.overflow = "hidden";
feel_at_home_whereve.style.color = "#000000";

frame_4.appendChild(feel_at_home_whereve);

var amenities = document.createElement("div");
amenities.innerHTML = "Amenities";
amenities.style.textAlign = "left";
amenities.id = "amenities";
amenities.style.left = "20px";
amenities.style.top = "569px";
amenities.style.width = "106.5px";
amenities.style.height = "33.5px";
amenities.style.fontFamily = "Poppins";
amenities.style.fontSize = "15px";
amenities.style.overflow = "hidden";
amenities.style.color = "#303135";

frame_4.appendChild(amenities);

var group_3_ek1 = document.createElement("div");
group_3_ek1.id = "group_3_ek1";
group_3_ek1.style.width = "80px";
group_3_ek1.style.height = "76px";
group_3_ek1.style.left = "0px";
group_3_ek1.style.top = "597px";
group_3_ek1.style.position = "absolute";
frame_4.appendChild(group_3_ek1);

var oval_ek5 = document.createElement("div");
oval_ek5.id = "oval_ek5";
oval_ek5.style.left = "16px";
oval_ek5.style.top = "0px";
oval_ek5.style.width = "48px";
oval_ek5.style.height = "48px";
oval_ek5.style.borderRadius = "24px / 24px";
oval_ek5.style.background = 'rgba(255,255,255,1)';

group_3_ek1.appendChild(oval_ek5);

var wifi_ek1 = document.createElement("div");
wifi_ek1.id = "wifi_ek1";
wifi_ek1.style.width = "15.33px";
wifi_ek1.style.height = "12.33px";
wifi_ek1.style.left = "32px";
wifi_ek1.style.top = "18px";
wifi_ek1.style.position = "absolute";
group_3_ek1.appendChild(wifi_ek1);

var combined_shape_ek5 = document.createElement("img");
combined_shape_ek5.id = "combined_shape_ek5";
combined_shape_ek5.style.left = "0px";
combined_shape_ek5.style.top = "0px";
combined_shape_ek5.style.width = "15.33px";
combined_shape_ek5.style.height = "12.33px";
combined_shape_ek5.src = "skins/combined_shape_ek5.png";

wifi_ek1.appendChild(combined_shape_ek5);

var wifi_ek2 = document.createElement("div");
wifi_ek2.innerHTML = "WiFi";
wifi_ek2.style.textAlign = "center";
wifi_ek2.id = "wifi_ek2";
wifi_ek2.style.left = "-2px";
wifi_ek2.style.top = "56px";
wifi_ek2.style.width = "92px";
wifi_ek2.style.height = "29.5px";
wifi_ek2.style.fontFamily = "Poppins";
wifi_ek2.style.fontSize = "13px";
wifi_ek2.style.lineHeight = "20px";
wifi_ek2.style.overflow = "hidden";
wifi_ek2.style.color = "#757984";

group_3_ek1.appendChild(wifi_ek2);

var group_3_ek2 = document.createElement("div");
group_3_ek2.id = "group_3_ek2";
group_3_ek2.style.width = "80px";
group_3_ek2.style.height = "76px";
group_3_ek2.style.left = "115px";
group_3_ek2.style.top = "597px";
group_3_ek2.style.position = "absolute";
frame_4.appendChild(group_3_ek2);

var oval_ek6 = document.createElement("div");
oval_ek6.id = "oval_ek6";
oval_ek6.style.left = "16px";
oval_ek6.style.top = "0px";
oval_ek6.style.width = "48px";
oval_ek6.style.height = "48px";
oval_ek6.style.borderRadius = "24px / 24px";
oval_ek6.style.background = 'rgba(255,255,255,1)';

group_3_ek2.appendChild(oval_ek6);

var air_conditioner = document.createElement("div");
air_conditioner.id = "air_conditioner";
air_conditioner.style.width = "17.13px";
air_conditioner.style.height = "18.13px";
air_conditioner.style.left = "32px";
air_conditioner.style.top = "15px";
air_conditioner.style.position = "absolute";
group_3_ek2.appendChild(air_conditioner);

var combined_shape_ek6 = document.createElement("img");
combined_shape_ek6.id = "combined_shape_ek6";
combined_shape_ek6.style.left = "0px";
combined_shape_ek6.style.top = "0px";
combined_shape_ek6.style.width = "17.13px";
combined_shape_ek6.style.height = "18.13px";
combined_shape_ek6.src = "skins/combined_shape_ek6.png";

air_conditioner.appendChild(combined_shape_ek6);

var ac = document.createElement("div");
ac.innerHTML = "AC";
ac.style.textAlign = "center";
ac.id = "ac";
ac.style.left = "-2px";
ac.style.top = "56px";
ac.style.width = "92px";
ac.style.height = "29.5px";
ac.style.fontFamily = "Poppins";
ac.style.fontSize = "13px";
ac.style.lineHeight = "20px";
ac.style.overflow = "hidden";
ac.style.color = "#757984";

group_3_ek2.appendChild(ac);

var group_3_ek3 = document.createElement("div");
group_3_ek3.id = "group_3_ek3";
group_3_ek3.style.width = "80px";
group_3_ek3.style.height = "76px";
group_3_ek3.style.left = "230px";
group_3_ek3.style.top = "597px";
group_3_ek3.style.position = "absolute";
frame_4.appendChild(group_3_ek3);

var oval_ek7 = document.createElement("div");
oval_ek7.id = "oval_ek7";
oval_ek7.style.left = "16px";
oval_ek7.style.top = "0px";
oval_ek7.style.width = "48px";
oval_ek7.style.height = "48px";
oval_ek7.style.borderRadius = "24px / 24px";
oval_ek7.style.background = 'rgba(255,255,255,1)';

group_3_ek3.appendChild(oval_ek7);

var tv = document.createElement("div");
tv.id = "tv";
tv.style.width = "16.67px";
tv.style.height = "15.33px";
tv.style.left = "32px";
tv.style.top = "17px";
tv.style.position = "absolute";
group_3_ek3.appendChild(tv);

var combined_shape_ek7 = document.createElement("img");
combined_shape_ek7.id = "combined_shape_ek7";
combined_shape_ek7.style.left = "0px";
combined_shape_ek7.style.top = "0px";
combined_shape_ek7.style.width = "16.67px";
combined_shape_ek7.style.height = "15.33px";
combined_shape_ek7.src = "skins/combined_shape_ek7.png";

tv.appendChild(combined_shape_ek7);

var tv_ek1 = document.createElement("div");
tv_ek1.innerHTML = "TV";
tv_ek1.style.textAlign = "center";
tv_ek1.id = "tv_ek1";
tv_ek1.style.left = "-2px";
tv_ek1.style.top = "56px";
tv_ek1.style.width = "92px";
tv_ek1.style.height = "29.5px";
tv_ek1.style.fontFamily = "Poppins";
tv_ek1.style.fontSize = "13px";
tv_ek1.style.lineHeight = "20px";
tv_ek1.style.overflow = "hidden";
tv_ek1.style.color = "#757984";

group_3_ek3.appendChild(tv_ek1);

var group_3_ek4 = document.createElement("div");
group_3_ek4.id = "group_3_ek4";
group_3_ek4.style.width = "80px";
group_3_ek4.style.height = "96px";
group_3_ek4.style.left = "345px";
group_3_ek4.style.top = "597px";
group_3_ek4.style.position = "absolute";
frame_4.appendChild(group_3_ek4);

var oval_ek8 = document.createElement("div");
oval_ek8.id = "oval_ek8";
oval_ek8.style.left = "16px";
oval_ek8.style.top = "0px";
oval_ek8.style.width = "48px";
oval_ek8.style.height = "48px";
oval_ek8.style.borderRadius = "24px / 24px";
oval_ek8.style.background = 'rgba(255,255,255,1)';

group_3_ek4.appendChild(oval_ek8);

var dog = document.createElement("div");
dog.id = "dog";
dog.style.width = "16px";
dog.style.height = "16px";
dog.style.left = "32px";
dog.style.top = "16px";
dog.style.position = "absolute";
group_3_ek4.appendChild(dog);

var combined_shape_ek8 = document.createElement("img");
combined_shape_ek8.id = "combined_shape_ek8";
combined_shape_ek8.style.left = "0px";
combined_shape_ek8.style.top = "0px";
combined_shape_ek8.style.width = "16px";
combined_shape_ek8.style.height = "16px";
combined_shape_ek8.src = "skins/combined_shape_ek8.png";

dog.appendChild(combined_shape_ek8);

var pets_allowed_ek1 = document.createElement("div");
pets_allowed_ek1.innerHTML = "Pets allowed";
pets_allowed_ek1.style.textAlign = "center";
pets_allowed_ek1.id = "pets_allowed_ek1";
pets_allowed_ek1.style.left = "-2px";
pets_allowed_ek1.style.top = "56px";
pets_allowed_ek1.style.width = "92px";
pets_allowed_ek1.style.height = "49.5px";
pets_allowed_ek1.style.fontFamily = "Poppins";
pets_allowed_ek1.style.fontSize = "13px";
pets_allowed_ek1.style.lineHeight = "20px";
pets_allowed_ek1.style.overflow = "hidden";
pets_allowed_ek1.style.color = "#757984";

group_3_ek4.appendChild(pets_allowed_ek1);

var see_all = document.createElement("div");
see_all.innerHTML = "See all";
see_all.style.textAlign = "right";
see_all.id = "see_all";
see_all.style.left = "353px";
see_all.style.top = "558px";
see_all.style.width = "66px";
see_all.style.height = "33.5px";
see_all.style.fontFamily = "Poppins";
see_all.style.fontSize = "15px";
see_all.style.overflow = "hidden";
see_all.style.color = "#CB5A7A";

frame_4.appendChild(see_all);

var more_photos = document.createElement("div");
more_photos.innerHTML = "More photos";
more_photos.style.textAlign = "left";
more_photos.id = "more_photos";
more_photos.style.left = "20px";
more_photos.style.top = "730px";
more_photos.style.width = "122.5px";
more_photos.style.height = "33.5px";
more_photos.style.fontFamily = "Poppins";
more_photos.style.fontSize = "15px";
more_photos.style.overflow = "hidden";
more_photos.style.color = "#303135";

frame_4.appendChild(more_photos);

var frame_2 = document.createElement("div");
frame_2.id = "frame_2";
frame_2.style.width = "414px";
frame_2.style.height = "140px";
frame_2.style.left = "19px";
frame_2.style.top = "768px";
frame_2.style.position = "absolute";
frame_4.appendChild(frame_2);

var frame_8 = document.createElement("div");
frame_8.id = "frame_8";
frame_8.style.width = "414px";
frame_8.style.height = "140px";
frame_8.style.left = "0px";
frame_8.style.top = "0px";
frame_8.style.position = "absolute";
frame_2.appendChild(frame_8);

var bitmap_ek2 = document.createElement("div");
bitmap_ek2.id = "bitmap_ek2";
bitmap_ek2.style.width = "140px";
bitmap_ek2.style.height = "140px";
bitmap_ek2.style.left = "0px";
bitmap_ek2.style.top = "0px";
bitmap_ek2.style.position = "absolute";
frame_8.appendChild(bitmap_ek2);

var mask_ek2 = document.createElement("div");
mask_ek2.id = "mask_ek2";
mask_ek2.style.left = "0px";
mask_ek2.style.top = "0px";
mask_ek2.style.width = "140px";
mask_ek2.style.height = "140px";
mask_ek2.style.borderRadius = "5px";
mask_ek2.style.background = 'rgba(215.99,215.99,215.99,1)';

bitmap_ek2.appendChild(mask_ek2);

var mask_ek3 = document.createElement("div");
mask_ek3.id = "mask_ek3";
mask_ek3.style.left = "0px";
mask_ek3.style.top = "0px";
mask_ek3.style.width = "140px";
mask_ek3.style.height = "140px";
mask_ek3.style.borderRadius = "5px";
mask_ek3.style.background = 'rgba(215.99,215.99,215.99,1)';

bitmap_ek2.appendChild(mask_ek3);

var bitmap_ek3 = document.createElement("img");
bitmap_ek3.id = "bitmap_ek3";
bitmap_ek3.style.left = "-24px";
bitmap_ek3.style.top = "0px";
bitmap_ek3.style.width = "226px";
bitmap_ek3.style.height = "151px";
bitmap_ek3.src = "skins/bitmap_ek3.png";

bitmap_ek2.appendChild(bitmap_ek3);

var bitmap_ek4 = document.createElement("div");
bitmap_ek4.id = "bitmap_ek4";
bitmap_ek4.style.width = "140px";
bitmap_ek4.style.height = "140px";
bitmap_ek4.style.left = "156px";
bitmap_ek4.style.top = "0px";
bitmap_ek4.style.position = "absolute";
frame_8.appendChild(bitmap_ek4);

var mask_ek4 = document.createElement("div");
mask_ek4.id = "mask_ek4";
mask_ek4.style.left = "0px";
mask_ek4.style.top = "0px";
mask_ek4.style.width = "140px";
mask_ek4.style.height = "140px";
mask_ek4.style.borderRadius = "5px";
mask_ek4.style.background = 'rgba(215.99,215.99,215.99,1)';

bitmap_ek4.appendChild(mask_ek4);

var mask_ek5 = document.createElement("div");
mask_ek5.id = "mask_ek5";
mask_ek5.style.left = "0px";
mask_ek5.style.top = "0px";
mask_ek5.style.width = "140px";
mask_ek5.style.height = "140px";
mask_ek5.style.borderRadius = "5px";
mask_ek5.style.background = 'rgba(215.99,215.99,215.99,1)';

bitmap_ek4.appendChild(mask_ek5);

var bitmap_ek5 = document.createElement("img");
bitmap_ek5.id = "bitmap_ek5";
bitmap_ek5.style.left = "-15px";
bitmap_ek5.style.top = "0px";
bitmap_ek5.style.width = "210px";
bitmap_ek5.style.height = "140px";
bitmap_ek5.src = "skins/bitmap_ek5.png";

bitmap_ek4.appendChild(bitmap_ek5);

var bitmap_ek6 = document.createElement("div");
bitmap_ek6.id = "bitmap_ek6";
bitmap_ek6.style.width = "140px";
bitmap_ek6.style.height = "140px";
bitmap_ek6.style.left = "312px";
bitmap_ek6.style.top = "0px";
bitmap_ek6.style.position = "absolute";
frame_8.appendChild(bitmap_ek6);

var mask_ek6 = document.createElement("div");
mask_ek6.id = "mask_ek6";
mask_ek6.style.left = "0px";
mask_ek6.style.top = "0px";
mask_ek6.style.width = "140px";
mask_ek6.style.height = "140px";
mask_ek6.style.borderRadius = "5px";
mask_ek6.style.background = 'rgba(215.99,215.99,215.99,1)';

bitmap_ek6.appendChild(mask_ek6);

var mask_ek7 = document.createElement("div");
mask_ek7.id = "mask_ek7";
mask_ek7.style.left = "0px";
mask_ek7.style.top = "0px";
mask_ek7.style.width = "140px";
mask_ek7.style.height = "140px";
mask_ek7.style.borderRadius = "5px";
mask_ek7.style.background = 'rgba(215.99,215.99,215.99,1)';

bitmap_ek6.appendChild(mask_ek7);

var bitmap_ek7 = document.createElement("img");
bitmap_ek7.id = "bitmap_ek7";
bitmap_ek7.style.left = "0px";
bitmap_ek7.style.top = "0px";
bitmap_ek7.style.width = "210px";
bitmap_ek7.style.height = "140px";
bitmap_ek7.src = "skins/bitmap_ek7.png";

bitmap_ek6.appendChild(bitmap_ek7);

var see_all_ek1 = document.createElement("div");
see_all_ek1.innerHTML = "See all";
see_all_ek1.style.textAlign = "right";
see_all_ek1.id = "see_all_ek1";
see_all_ek1.style.left = "353px";
see_all_ek1.style.top = "724px";
see_all_ek1.style.width = "66px";
see_all_ek1.style.height = "33.5px";
see_all_ek1.style.fontFamily = "Poppins";
see_all_ek1.style.fontSize = "15px";
see_all_ek1.style.overflow = "hidden";
see_all_ek1.style.color = "#CB5A7A";

frame_4.appendChild(see_all_ek1);

var about_roommate = document.createElement("div");
about_roommate.innerHTML = "About roommate";
about_roommate.style.textAlign = "left";
about_roommate.id = "about_roommate";
about_roommate.style.left = "20px";
about_roommate.style.top = "928px";
about_roommate.style.width = "161.5px";
about_roommate.style.height = "33.5px";
about_roommate.style.fontFamily = "Poppins";
about_roommate.style.fontSize = "15px";
about_roommate.style.overflow = "hidden";
about_roommate.style.color = "#303135";

frame_4.appendChild(about_roommate);

var oval_ek9 = document.createElement("img");
oval_ek9.id = "oval_ek9";
oval_ek9.style.left = "16px";
oval_ek9.style.top = "956px";
oval_ek9.style.width = "64px";
oval_ek9.style.height = "64px";
oval_ek9.src = "skins/oval_ek9.png";

frame_4.appendChild(oval_ek9);

var group_5 = document.createElement("div");
group_5.id = "group_5";
group_5.style.width = "185px";
group_5.style.height = "37px";
group_5.style.left = "104px";
group_5.style.top = "970px";
group_5.style.position = "absolute";
frame_4.appendChild(group_5);

var dennis__25 = document.createElement("div");
dennis__25.innerHTML = "Funmi, 21";
dennis__25.style.textAlign = "left";
dennis__25.id = "dennis__25";
dennis__25.style.left = "0px";
dennis__25.style.top = "0px";
dennis__25.style.width = "97.5px";
dennis__25.style.height = "33.5px";
dennis__25.style.fontFamily = "Poppins";
dennis__25.style.fontSize = "15px";
dennis__25.style.overflow = "hidden";
dennis__25.style.color = "#303135";

group_5.appendChild(dennis__25);

var software_developer_a = document.createElement("div");
software_developer_a.innerHTML = "Software developer at Blueground";
software_developer_a.style.textAlign = "left";
software_developer_a.id = "software_developer_a";
software_developer_a.style.left = "0px";
software_developer_a.style.top = "22px";
software_developer_a.style.width = "240.5px";
software_developer_a.style.height = "29.5px";
software_developer_a.style.fontFamily = "Poppins";
software_developer_a.style.fontSize = "13px";
software_developer_a.style.overflow = "hidden";
software_developer_a.style.color = "#757984";

group_5.appendChild(software_developer_a);

var lorem_ipsum_dolor_si = document.createElement("div");
lorem_ipsum_dolor_si.innerHTML = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras eu semper velit. Nam tempor gravida libero, a gravida odio dapibus at. Donec sagittis neque lacus, vel posuere tortor volutpat et. Nulla ut tempor arcu. Quisque id sapien at augue elementum consequat. Vestibulum ac consequat quam.";
lorem_ipsum_dolor_si.style.textAlign = "left";
lorem_ipsum_dolor_si.id = "lorem_ipsum_dolor_si";
lorem_ipsum_dolor_si.style.left = "24px";
lorem_ipsum_dolor_si.style.top = "1028px";
lorem_ipsum_dolor_si.style.width = "428px";
lorem_ipsum_dolor_si.style.height = "130px";
lorem_ipsum_dolor_si.style.fontFamily = "Poppins";
lorem_ipsum_dolor_si.style.fontSize = "14px";
lorem_ipsum_dolor_si.style.lineHeight = "20px";
lorem_ipsum_dolor_si.style.overflow = "hidden";
lorem_ipsum_dolor_si.style.color = "#000000";

frame_4.appendChild(lorem_ipsum_dolor_si);

var rectangle_63 = document.createElement("img");
rectangle_63.id = "rectangle_63";
rectangle_63.style.left = "16px";
rectangle_63.style.top = "1170px";
rectangle_63.style.width = "387px";
rectangle_63.style.height = "244px";
rectangle_63.src = "skins/rectangle_63.png";

frame_4.appendChild(rectangle_63);

var group_ek7 = document.createElement("div");
group_ek7.id = "group_ek7";
group_ek7.style.width = "327px";
group_ek7.style.height = "56px";
group_ek7.style.left = "53px";
group_ek7.style.top = "1480px";
group_ek7.style.position = "absolute";
page_full_roommate_search_ek1.appendChild(group_ek7);

var rectangle_ek2 = document.createElement("div");
rectangle_ek2.id = "rectangle_ek2";
rectangle_ek2.style.left = "0px";
rectangle_ek2.style.top = "0px";
rectangle_ek2.style.width = "327px";
rectangle_ek2.style.height = "56px";
rectangle_ek2.style.borderRadius = "5px";
rectangle_ek2.style.background = 'rgba(203,90,122,1)';

group_ek7.appendChild(rectangle_ek2);

var chat_with_dennis = document.createElement("div");
chat_with_dennis.innerHTML = "CHAT WITH FUNMI";
chat_with_dennis.style.textAlign = "center";
chat_with_dennis.id = "chat_with_dennis";
chat_with_dennis.style.left = "84px";
chat_with_dennis.style.top = "19px";
chat_with_dennis.style.width = "168px";
chat_with_dennis.style.height = "33.5px";
chat_with_dennis.style.fontFamily = "Poppins";
chat_with_dennis.style.fontSize = "15px";
chat_with_dennis.style.overflow = "hidden";
chat_with_dennis.style.color = "#FFFFFF";

group_ek7.appendChild(chat_with_dennis);










