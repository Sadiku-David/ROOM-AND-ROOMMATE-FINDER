/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);














var page_account_ek5 = document.createElement("div");
page_account_ek5.id = "page_account_ek5";
page_account_ek5.style.width = "414px";
page_account_ek5.style.height = "826px";
page_account_ek5.style.left = "0px";
page_account_ek5.style.top = "0px";
page_account_ek5.style.position = "absolute";
content_container.appendChild(page_account_ek5);

var _bg__account_ek6 = document.createElement("div");
_bg__account_ek6.id = "_bg__account_ek6";
_bg__account_ek6.style.left = "0px";
_bg__account_ek6.style.top = "0px";
_bg__account_ek6.style.width = "414px";
_bg__account_ek6.style.height = "826px";
_bg__account_ek6.style.background = 'rgba(249,253,255,1)';

page_account_ek5.appendChild(_bg__account_ek6);

var rectangle_2_ek5 = document.createElement("div");
rectangle_2_ek5.id = "rectangle_2_ek5";
rectangle_2_ek5.style.left = "0px";
rectangle_2_ek5.style.opacity = "0";
rectangle_2_ek5.style.filter = "alpha(opacity='0')";
rectangle_2_ek5.style.top = "-61px";
rectangle_2_ek5.style.width = "414px";
rectangle_2_ek5.style.height = "826px";
rectangle_2_ek5.style.borderRadius = "22px";
rectangle_2_ek5.style.background = 'rgba(233,233,233,0)';

page_account_ek5.appendChild(rectangle_2_ek5);

var ellipse_1 = document.createElement("img");
ellipse_1.id = "ellipse_1";
ellipse_1.style.left = "176px";
ellipse_1.style.top = "54px";
ellipse_1.style.width = "57px";
ellipse_1.style.height = "57px";
ellipse_1.src = "skins/ellipse_1.png";

page_account_ek5.appendChild(ellipse_1);

var david_watkins = document.createElement("div");
david_watkins.innerHTML = "David Watkins";
david_watkins.style.textAlign = "left";
david_watkins.id = "david_watkins";
david_watkins.style.left = "160px";
david_watkins.style.top = "117px";
david_watkins.style.width = "108px";
david_watkins.style.height = "30px";
david_watkins.style.fontFamily = "Coda";
david_watkins.style.fontSize = "14px";
david_watkins.style.overflow = "hidden";
david_watkins.style.color = "#000000";

page_account_ek5.appendChild(david_watkins);

var watkins01_gmail_com = document.createElement("div");
watkins01_gmail_com.innerHTML = "watkins01@gmail.com";
watkins01_gmail_com.style.textAlign = "left";
watkins01_gmail_com.id = "watkins01_gmail_com";
watkins01_gmail_com.style.left = "156px";
watkins01_gmail_com.style.top = "137px";
watkins01_gmail_com.style.width = "116px";
watkins01_gmail_com.style.height = "21px";
watkins01_gmail_com.style.fontFamily = "Coda";
watkins01_gmail_com.style.fontSize = "10px";
watkins01_gmail_com.style.overflow = "hidden";
watkins01_gmail_com.style.color = "#000000";

page_account_ek5.appendChild(watkins01_gmail_com);

var vector_ek83 = document.createElement("img");
vector_ek83.id = "vector_ek83";
vector_ek83.style.left = "24px";
vector_ek83.style.top = "193px";
vector_ek83.style.width = "26px";
vector_ek83.style.height = "29px";
vector_ek83.src = "skins/vector_ek83.png";

page_account_ek5.appendChild(vector_ek83);

var vector_ek84 = document.createElement("img");
vector_ek84.id = "vector_ek84";
vector_ek84.style.left = "21px";
vector_ek84.style.top = "257px";
vector_ek84.style.width = "29px";
vector_ek84.style.height = "29px";
vector_ek84.src = "skins/vector_ek84.png";

page_account_ek5.appendChild(vector_ek84);

var vector_ek85 = document.createElement("img");
vector_ek85.id = "vector_ek85";
vector_ek85.style.left = "19px";
vector_ek85.style.top = "518px";
vector_ek85.style.width = "29px";
vector_ek85.style.height = "29px";
vector_ek85.src = "skins/vector_ek85.png";

page_account_ek5.appendChild(vector_ek85);

var vector_ek86 = document.createElement("img");
vector_ek86.id = "vector_ek86";
vector_ek86.style.left = "21px";
vector_ek86.style.top = "414px";
vector_ek86.style.width = "29px";
vector_ek86.style.height = "29px";
vector_ek86.src = "skins/vector_ek86.png";

page_account_ek5.appendChild(vector_ek86);

var vector_ek87 = document.createElement("img");
vector_ek87.id = "vector_ek87";
vector_ek87.style.left = "383px";
vector_ek87.style.top = "200px";
vector_ek87.style.width = "8.46px";
vector_ek87.style.height = "16.92px";
vector_ek87.src = "skins/vector_ek87.png";

page_account_ek5.appendChild(vector_ek87);

var vector_ek88 = document.createElement("img");
vector_ek88.id = "vector_ek88";
vector_ek88.style.left = "383px";
vector_ek88.style.top = "263px";
vector_ek88.style.width = "8.46px";
vector_ek88.style.height = "16.92px";
vector_ek88.src = "skins/vector_ek88.png";

page_account_ek5.appendChild(vector_ek88);

var vector_ek89 = document.createElement("img");
vector_ek89.id = "vector_ek89";
vector_ek89.style.left = "383px";
vector_ek89.style.top = "326px";
vector_ek89.style.width = "8.46px";
vector_ek89.style.height = "16.92px";
vector_ek89.src = "skins/vector_ek89.png";

page_account_ek5.appendChild(vector_ek89);

var vector_ek90 = document.createElement("img");
vector_ek90.id = "vector_ek90";
vector_ek90.style.left = "383px";
vector_ek90.style.top = "391px";
vector_ek90.style.width = "8.46px";
vector_ek90.style.height = "16.92px";
vector_ek90.src = "skins/vector_ek90.png";

page_account_ek5.appendChild(vector_ek90);

var vector_ek91 = document.createElement("img");
vector_ek91.id = "vector_ek91";
vector_ek91.style.left = "383px";
vector_ek91.style.top = "454px";
vector_ek91.style.width = "8.46px";
vector_ek91.style.height = "16.92px";
vector_ek91.src = "skins/vector_ek91.png";

page_account_ek5.appendChild(vector_ek91);

var vector_ek92 = document.createElement("img");
vector_ek92.id = "vector_ek92";
vector_ek92.style.left = "383px";
vector_ek92.style.top = "525px";
vector_ek92.style.width = "8.46px";
vector_ek92.style.height = "16.92px";
vector_ek92.src = "skins/vector_ek92.png";

page_account_ek5.appendChild(vector_ek92);

var notification = document.createElement("div");
notification.innerHTML = "Notification";
notification.style.textAlign = "left";
notification.id = "notification";
notification.style.left = "71px";
notification.style.top = "198px";
notification.style.width = "93px";
notification.style.height = "30px";
notification.style.fontFamily = "Coda";
notification.style.fontSize = "14px";
notification.style.overflow = "hidden";
notification.style.color = "#000000";

page_account_ek5.appendChild(notification);

var messages_ek4 = document.createElement("div");
messages_ek4.innerHTML = "Messages";
messages_ek4.style.textAlign = "left";
messages_ek4.id = "messages_ek4";
messages_ek4.style.left = "71px";
messages_ek4.style.top = "263px";
messages_ek4.style.width = "83px";
messages_ek4.style.height = "30px";
messages_ek4.style.fontFamily = "Coda";
messages_ek4.style.fontSize = "14px";
messages_ek4.style.overflow = "hidden";
messages_ek4.style.color = "#000000";

page_account_ek5.appendChild(messages_ek4);

var favourites = document.createElement("div");
favourites.innerHTML = "Favourites";
favourites.style.textAlign = "left";
favourites.id = "favourites";
favourites.style.left = "72px";
favourites.style.top = "329px";
favourites.style.width = "85px";
favourites.style.height = "30px";
favourites.style.fontFamily = "Coda";
favourites.style.fontSize = "14px";
favourites.style.overflow = "hidden";
favourites.style.color = "#000000";

page_account_ek5.appendChild(favourites);

var help = document.createElement("div");
help.innerHTML = "Help";
help.style.textAlign = "left";
help.id = "help";
help.style.left = "71px";
help.style.top = "394px";
help.style.width = "48px";
help.style.height = "30px";
help.style.fontFamily = "Coda";
help.style.fontSize = "14px";
help.style.overflow = "hidden";
help.style.color = "#000000";

page_account_ek5.appendChild(help);

var settings = document.createElement("div");
settings.innerHTML = "Settings";
settings.style.textAlign = "left";
settings.id = "settings";
settings.style.left = "72px";
settings.style.top = "453px";
settings.style.width = "72px";
settings.style.height = "30px";
settings.style.fontFamily = "Coda";
settings.style.fontSize = "14px";
settings.style.overflow = "hidden";
settings.style.color = "#000000";

page_account_ek5.appendChild(settings);

var about_us = document.createElement("div");
about_us.innerHTML = "About Us";
about_us.style.textAlign = "left";
about_us.id = "about_us";
about_us.style.left = "71px";
about_us.style.top = "519px";
about_us.style.width = "77px";
about_us.style.height = "30px";
about_us.style.fontFamily = "Coda";
about_us.style.fontSize = "14px";
about_us.style.overflow = "hidden";
about_us.style.color = "#000000";

page_account_ek5.appendChild(about_us);

var vector_ek93 = document.createElement("img");
vector_ek93.id = "vector_ek93";
vector_ek93.style.left = "20px";
vector_ek93.style.top = "448px";
vector_ek93.style.width = "27.18px";
vector_ek93.style.height = "27.92px";
vector_ek93.src = "skins/vector_ek93.png";

page_account_ek5.appendChild(vector_ek93);

var vector_ek94 = document.createElement("img");
vector_ek94.id = "vector_ek94";
vector_ek94.style.left = "27.59px";
vector_ek94.style.top = "455.96px";
vector_ek94.style.width = "12px";
vector_ek94.style.height = "12px";
vector_ek94.src = "skins/vector_ek94.png";

page_account_ek5.appendChild(vector_ek94);

var rectangle_4_ek1 = document.createElement("div");
rectangle_4_ek1.id = "rectangle_4_ek1";
rectangle_4_ek1.style.left = "82px";
rectangle_4_ek1.style.opacity = "0.33000001311302";
rectangle_4_ek1.style.filter = "alpha(opacity='33.000001311302')";
rectangle_4_ek1.style.top = "647px";
rectangle_4_ek1.style.width = "242px";
rectangle_4_ek1.style.height = "57px";
rectangle_4_ek1.style.borderRadius = "15px";
rectangle_4_ek1.style.background = 'rgba(203,90,122,0.33)';

page_account_ek5.appendChild(rectangle_4_ek1);

var vector_ek95 = document.createElement("img");
vector_ek95.id = "vector_ek95";
vector_ek95.style.left = "100px";
vector_ek95.style.top = "661px";
vector_ek95.style.width = "29px";
vector_ek95.style.height = "29px";
vector_ek95.src = "skins/vector_ek95.png";

page_account_ek5.appendChild(vector_ek95);

var log_out = document.createElement("div");
log_out.innerHTML = "Log Out";
log_out.style.textAlign = "left";
log_out.id = "log_out";
log_out.style.left = "182px";
log_out.style.top = "666px";
log_out.style.width = "68px";
log_out.style.height = "30px";
log_out.style.fontFamily = "Coda";
log_out.style.fontSize = "14px";
log_out.style.overflow = "hidden";
log_out.style.color = "#CB5A7A";

page_account_ek5.appendChild(log_out);

var akar_icons_heart_ek6 = document.createElement("div");
akar_icons_heart_ek6.id = "akar_icons_heart_ek6";
akar_icons_heart_ek6.style.width = "29px";
akar_icons_heart_ek6.style.height = "29px";
akar_icons_heart_ek6.style.left = "21px";
akar_icons_heart_ek6.style.top = "324px";
akar_icons_heart_ek6.style.position = "absolute";
page_account_ek5.appendChild(akar_icons_heart_ek6);

var vector_ek96 = document.createElement("img");
vector_ek96.id = "vector_ek96";
vector_ek96.style.left = "2.42px";
vector_ek96.style.top = "3.63px";
vector_ek96.style.width = "24.17px";
vector_ek96.style.height = "21.55px";
vector_ek96.src = "skins/vector_ek96.png";

akar_icons_heart_ek6.appendChild(vector_ek96);

var down_ek4 = document.createElement("div");
down_ek4.id = "down_ek4";
down_ek4.style.width = "419px";
down_ek4.style.height = "105px";
down_ek4.style.left = "-2px";
down_ek4.style.top = "721px";
down_ek4.style.position = "absolute";
page_account_ek5.appendChild(down_ek4);

var rectangle_3_ek7 = document.createElement("div");
rectangle_3_ek7.id = "rectangle_3_ek7";
rectangle_3_ek7.style.left = "0px";
rectangle_3_ek7.style.opacity = "0.75999999046326";
rectangle_3_ek7.style.filter = "alpha(opacity='75.999999046326')";
rectangle_3_ek7.style.top = "0px";
rectangle_3_ek7.style.width = "419px";
rectangle_3_ek7.style.height = "105px";
rectangle_3_ek7.style.borderRadius = "10px";
rectangle_3_ek7.style.background = 'rgba(253.94,253.94,253.94,0.76)';

down_ek4.appendChild(rectangle_3_ek7);

var vector_ek97 = document.createElement("img");
vector_ek97.id = "vector_ek97";
vector_ek97.style.left = "30px";
vector_ek97.style.top = "38px";
vector_ek97.style.width = "29px";
vector_ek97.style.height = "29px";
vector_ek97.src = "skins/vector_ek97.png";

down_ek4.appendChild(vector_ek97);

var vector_ek98 = document.createElement("img");
vector_ek98.id = "vector_ek98";
vector_ek98.style.left = "144px";
vector_ek98.style.top = "38px";
vector_ek98.style.width = "29px";
vector_ek98.style.height = "29px";
vector_ek98.src = "skins/vector_ek98.png";

down_ek4.appendChild(vector_ek98);

var vector_ek99 = document.createElement("img");
vector_ek99.id = "vector_ek99";
vector_ek99.style.left = "255px";
vector_ek99.style.top = "43px";
vector_ek99.style.width = "29px";
vector_ek99.style.height = "29px";
vector_ek99.src = "skins/vector_ek99.png";

down_ek4.appendChild(vector_ek99);

var group_ek11 = document.createElement("div");
group_ek11.id = "group_ek11";
group_ek11.style.width = "29px";
group_ek11.style.height = "29px";
group_ek11.style.left = "367px";
group_ek11.style.top = "9px";
group_ek11.style.position = "absolute";
down_ek4.appendChild(group_ek11);

var vector_ek100 = document.createElement("img");
vector_ek100.id = "vector_ek100";
vector_ek100.style.left = "0px";
vector_ek100.style.top = "0px";
vector_ek100.style.width = "29px";
vector_ek100.style.height = "29px";
vector_ek100.src = "skins/vector_ek100.png";

group_ek11.appendChild(vector_ek100);

var home_ek7 = document.createElement("div");
home_ek7.innerHTML = "Home";
home_ek7.style.textAlign = "left";
home_ek7.id = "home_ek7";
home_ek7.style.left = "26px";
home_ek7.style.top = "72px";
home_ek7.style.width = "61px";
home_ek7.style.height = "31px";
home_ek7.style.fontFamily = "Poppins";
home_ek7.style.fontSize = "14px";
home_ek7.style.overflow = "hidden";
home_ek7.style.color = "#07132A";

down_ek4.appendChild(home_ek7);

var search_ek11 = document.createElement("div");
search_ek11.innerHTML = "Search";
search_ek11.style.textAlign = "left";
search_ek11.id = "search_ek11";
search_ek11.style.left = "136px";
search_ek11.style.top = "72px";
search_ek11.style.width = "69px";
search_ek11.style.height = "31px";
search_ek11.style.fontFamily = "Poppins";
search_ek11.style.fontSize = "14px";
search_ek11.style.overflow = "hidden";
search_ek11.style.color = "#000000";

down_ek4.appendChild(search_ek11);

var saved_ek4 = document.createElement("div");
saved_ek4.innerHTML = "Saved";
saved_ek4.style.textAlign = "left";
saved_ek4.id = "saved_ek4";
saved_ek4.style.left = "248px";
saved_ek4.style.top = "72px";
saved_ek4.style.width = "63px";
saved_ek4.style.height = "31px";
saved_ek4.style.fontFamily = "Poppins";
saved_ek4.style.fontSize = "14px";
saved_ek4.style.overflow = "hidden";
saved_ek4.style.color = "#000000";

down_ek4.appendChild(saved_ek4);

var account_ek7 = document.createElement("div");
account_ek7.innerHTML = "Account";
account_ek7.style.textAlign = "left";
account_ek7.id = "account_ek7";
account_ek7.style.left = "352px";
account_ek7.style.top = "72px";
account_ek7.style.width = "78px";
account_ek7.style.height = "31px";
account_ek7.style.fontFamily = "Poppins";
account_ek7.style.fontSize = "14px";
account_ek7.style.overflow = "hidden";
account_ek7.style.color = "#CB5A7A";

down_ek4.appendChild(account_ek7);
