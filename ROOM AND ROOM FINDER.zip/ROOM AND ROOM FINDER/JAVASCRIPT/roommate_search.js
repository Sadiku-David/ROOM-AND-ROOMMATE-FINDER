/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);












var page_roommate_search_ek1 = document.createElement("div");
page_roommate_search_ek1.id = "page_roommate_search_ek1";
page_roommate_search_ek1.style.width = "428px";
page_roommate_search_ek1.style.height = "826px";
page_roommate_search_ek1.style.left = "0px";
page_roommate_search_ek1.style.top = "0px";
page_roommate_search_ek1.style.position = "absolute";
content_container.appendChild(page_roommate_search_ek1);

var _bg__roommate_search_ek2 = document.createElement("div");
_bg__roommate_search_ek2.id = "_bg__roommate_search_ek2";
_bg__roommate_search_ek2.style.left = "0px";
_bg__roommate_search_ek2.style.top = "0px";
_bg__roommate_search_ek2.style.width = "428px";
_bg__roommate_search_ek2.style.height = "826px";
_bg__roommate_search_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_roommate_search_ek1.appendChild(_bg__roommate_search_ek2);

var rectangle_53_ek5 = document.createElement("div");
rectangle_53_ek5.id = "rectangle_53_ek5";
rectangle_53_ek5.style.left = "0px";
rectangle_53_ek5.style.top = "0px";
rectangle_53_ek5.style.width = "428px";
rectangle_53_ek5.style.height = "89px";
rectangle_53_ek5.style.background = 'rgba(203,90,122,1)';

page_roommate_search_ek1.appendChild(rectangle_53_ek5);

var _238_matches = document.createElement("div");
_238_matches.innerHTML = "238 Matches";
_238_matches.style.textAlign = "left";
_238_matches.id = "_238_matches";
_238_matches.style.left = "57px";
_238_matches.style.top = "44px";
_238_matches.style.width = "100.5px";
_238_matches.style.height = "29.5px";
_238_matches.style.fontFamily = "Poppins";
_238_matches.style.fontSize = "13px";
_238_matches.style.overflow = "hidden";
_238_matches.style.color = "#FFFFFF";

page_roommate_search_ek1.appendChild(_238_matches);

var eva_arrow_back_outline_ek1 = document.createElement("div");
eva_arrow_back_outline_ek1.id = "eva_arrow_back_outline_ek1";
eva_arrow_back_outline_ek1.style.width = "33px";
eva_arrow_back_outline_ek1.style.height = "33px";
eva_arrow_back_outline_ek1.style.left = "12px";
eva_arrow_back_outline_ek1.style.top = "36px";
eva_arrow_back_outline_ek1.style.position = "absolute";
page_roommate_search_ek1.appendChild(eva_arrow_back_outline_ek1);

var vector_ek75 = document.createElement("img");
vector_ek75.id = "vector_ek75";
vector_ek75.style.left = "5.5px";
vector_ek75.style.top = "6.87px";
vector_ek75.style.width = "22px";
vector_ek75.style.height = "19.25px";
vector_ek75.src = "skins/vector_ek75.png";

eva_arrow_back_outline_ek1.appendChild(vector_ek75);

var rectangle_57_ek1 = document.createElement("div");
rectangle_57_ek1.id = "rectangle_57_ek1";
rectangle_57_ek1.style.left = "18px";
rectangle_57_ek1.style.opacity = "0.74000000953674";
rectangle_57_ek1.style.filter = "alpha(opacity='74.000000953674')";
rectangle_57_ek1.style.top = "101px";
rectangle_57_ek1.style.width = "106px";
rectangle_57_ek1.style.height = "39px";
rectangle_57_ek1.style.borderRadius = "10px";
rectangle_57_ek1.style.background = 'rgba(255,255,255,0.74)';

page_roommate_search_ek1.appendChild(rectangle_57_ek1);

var rectangle_58_ek1 = document.createElement("div");
rectangle_58_ek1.id = "rectangle_58_ek1";
rectangle_58_ek1.style.left = "161px";
rectangle_58_ek1.style.opacity = "0.74000000953674";
rectangle_58_ek1.style.filter = "alpha(opacity='74.000000953674')";
rectangle_58_ek1.style.top = "101px";
rectangle_58_ek1.style.width = "106px";
rectangle_58_ek1.style.height = "39px";
rectangle_58_ek1.style.borderRadius = "10px";
rectangle_58_ek1.style.background = 'rgba(255,255,255,0.74)';

page_roommate_search_ek1.appendChild(rectangle_58_ek1);

var rectangle_59_ek1 = document.createElement("div");
rectangle_59_ek1.id = "rectangle_59_ek1";
rectangle_59_ek1.style.left = "304px";
rectangle_59_ek1.style.opacity = "0.74000000953674";
rectangle_59_ek1.style.filter = "alpha(opacity='74.000000953674')";
rectangle_59_ek1.style.top = "101px";
rectangle_59_ek1.style.width = "106px";
rectangle_59_ek1.style.height = "39px";
rectangle_59_ek1.style.borderRadius = "10px";
rectangle_59_ek1.style.background = 'rgba(255,255,255,0.74)';

page_roommate_search_ek1.appendChild(rectangle_59_ek1);

var system_uicons_filtering_ek1 = document.createElement("div");
system_uicons_filtering_ek1.id = "system_uicons_filtering_ek1";
system_uicons_filtering_ek1.style.width = "24px";
system_uicons_filtering_ek1.style.height = "24px";
system_uicons_filtering_ek1.style.left = "28px";
system_uicons_filtering_ek1.style.top = "108px";
system_uicons_filtering_ek1.style.position = "absolute";
page_roommate_search_ek1.appendChild(system_uicons_filtering_ek1);

var vector_ek76 = document.createElement("img");
vector_ek76.id = "vector_ek76";
vector_ek76.style.left = "2.86px";
vector_ek76.style.top = "4.57px";
vector_ek76.style.width = "18.29px";
vector_ek76.style.height = "16px";
vector_ek76.src = "skins/vector_ek76.png";

system_uicons_filtering_ek1.appendChild(vector_ek76);

var filters_ek1 = document.createElement("div");
filters_ek1.innerHTML = "Filters";
filters_ek1.style.textAlign = "left";
filters_ek1.id = "filters_ek1";
filters_ek1.style.left = "57px";
filters_ek1.style.top = "108px";
filters_ek1.style.width = "69px";
filters_ek1.style.height = "36px";
filters_ek1.style.fontFamily = "Poppins";
filters_ek1.style.fontSize = "16px";
filters_ek1.style.lineHeight = "25px";
filters_ek1.style.overflow = "hidden";
filters_ek1.style.color = "#000000";

page_roommate_search_ek1.appendChild(filters_ek1);

var save_ek4 = document.createElement("div");
save_ek4.innerHTML = "Save";
save_ek4.style.textAlign = "left";
save_ek4.id = "save_ek4";
save_ek4.style.left = "200px";
save_ek4.style.top = "108px";
save_ek4.style.width = "61px";
save_ek4.style.height = "36px";
save_ek4.style.fontFamily = "Poppins";
save_ek4.style.fontSize = "16px";
save_ek4.style.lineHeight = "25px";
save_ek4.style.overflow = "hidden";
save_ek4.style.color = "#000000";

page_roommate_search_ek1.appendChild(save_ek4);

var sort_ek1 = document.createElement("div");
sort_ek1.innerHTML = "Sort";
sort_ek1.style.textAlign = "left";
sort_ek1.id = "sort_ek1";
sort_ek1.style.left = "343px";
sort_ek1.style.top = "108px";
sort_ek1.style.width = "53px";
sort_ek1.style.height = "36px";
sort_ek1.style.fontFamily = "Poppins";
sort_ek1.style.fontSize = "16px";
sort_ek1.style.lineHeight = "25px";
sort_ek1.style.overflow = "hidden";
sort_ek1.style.color = "#000000";

page_roommate_search_ek1.appendChild(sort_ek1);

var bi_save2_ek1 = document.createElement("div");
bi_save2_ek1.id = "bi_save2_ek1";
bi_save2_ek1.style.width = "24px";
bi_save2_ek1.style.height = "24px";
bi_save2_ek1.style.left = "170px";
bi_save2_ek1.style.top = "108px";
bi_save2_ek1.style.position = "absolute";
page_roommate_search_ek1.appendChild(bi_save2_ek1);

var vector_ek77 = document.createElement("img");
vector_ek77.id = "vector_ek77";
vector_ek77.style.left = "0px";
vector_ek77.style.top = "0px";
vector_ek77.style.width = "24px";
vector_ek77.style.height = "24px";
vector_ek77.src = "skins/vector_ek77.png";

bi_save2_ek1.appendChild(vector_ek77);

var ic_round_sort_ek1 = document.createElement("div");
ic_round_sort_ek1.id = "ic_round_sort_ek1";
ic_round_sort_ek1.style.width = "24px";
ic_round_sort_ek1.style.height = "24px";
ic_round_sort_ek1.style.left = "313px";
ic_round_sort_ek1.style.top = "108px";
ic_round_sort_ek1.style.position = "absolute";
page_roommate_search_ek1.appendChild(ic_round_sort_ek1);

var vector_ek78 = document.createElement("img");
vector_ek78.id = "vector_ek78";
vector_ek78.style.left = "3px";
vector_ek78.style.top = "6px";
vector_ek78.style.width = "18px";
vector_ek78.style.height = "12px";
vector_ek78.src = "skins/vector_ek78.png";

ic_round_sort_ek1.appendChild(vector_ek78);

var cardddd = document.createElement("div");
cardddd.id = "cardddd";
cardddd.style.width = "405px";
cardddd.style.height = "576px";
cardddd.style.left = "18px";
cardddd.style.top = "159px";
cardddd.style.position = "absolute";
page_roommate_search_ek1.appendChild(cardddd);

var card_top_1 = document.createElement("div");
card_top_1.id = "card_top_1";
card_top_1.style.width = "405px";
card_top_1.style.height = "292px";
card_top_1.style.left = "0px";
card_top_1.style.top = "0px";
card_top_1.style.position = "absolute";
cardddd.appendChild(card_top_1);

var cardd_1 = document.createElement("div");
cardd_1.id = "cardd_1";
cardd_1.style.width = "232px";
cardd_1.style.height = "292px";
cardd_1.style.left = "0px";
cardd_1.style.top = "0px";
cardd_1.style.position = "absolute";
card_top_1.appendChild(cardd_1);

var card_background_ek4 = document.createElement("div");
card_background_ek4.id = "card_background_ek4";
card_background_ek4.style.left = "0px";
card_background_ek4.style.top = "0px";
card_background_ek4.style.width = "232px";
card_background_ek4.style.height = "292px";
card_background_ek4.style.borderRadius = "16px";
card_background_ek4.style.background = 'rgba(255,255,255,1)';

cardd_1.appendChild(card_background_ek4);

var funmi = document.createElement("div");
funmi.innerHTML = "Funmi";
funmi.style.fontWeight = "bold";
funmi.style.textAlign = "left";
funmi.id = "funmi";
funmi.style.left = "14px";
funmi.style.top = "179px";
funmi.style.width = "52.5px";
funmi.style.height = "24.5px";
funmi.style.fontFamily = "Poppins";
funmi.style.fontSize = "11px";
funmi.style.overflow = "hidden";
funmi.style.color = "#000000";

cardd_1.appendChild(funmi);

var icon_background = document.createElement("div");
icon_background.id = "icon_background";
icon_background.style.left = "0px";
icon_background.style.top = "0px";
icon_background.style.width = "232px";
icon_background.style.height = "168px";
icon_background.style.borderRadius = "16px";
icon_background.style.background = 'rgba(188,209,255,0)';

cardd_1.appendChild(icon_background);

var _21_years_old = document.createElement("div");
_21_years_old.innerHTML = "21 Years old";
_21_years_old.style.textAlign = "right";
_21_years_old.id = "_21_years_old";
_21_years_old.style.left = "12px";
_21_years_old.style.top = "202px";
_21_years_old.style.width = "74px";
_21_years_old.style.height = "22.5px";
_21_years_old.style.fontFamily = "Open Sans";
_21_years_old.style.fontSize = "11px";
_21_years_old.style.overflow = "hidden";
_21_years_old.style.color = "#000000";

cardd_1.appendChild(_21_years_old);

var female__developer__christain = document.createElement("div");
female__developer__christain.innerHTML = "Female, Developer, Christain";
female__developer__christain.style.textAlign = "right";
female__developer__christain.id = "female__developer__christain";
female__developer__christain.style.left = "12px";
female__developer__christain.style.top = "223px";
female__developer__christain.style.width = "158px";
female__developer__christain.style.height = "22.5px";
female__developer__christain.style.fontFamily = "Open Sans";
female__developer__christain.style.fontSize = "11px";
female__developer__christain.style.overflow = "hidden";
female__developer__christain.style.color = "#000000";

cardd_1.appendChild(female__developer__christain);

var likes_tech_and_music = document.createElement("div");
likes_tech_and_music.innerHTML = "Likes Tech and Music";
likes_tech_and_music.style.textAlign = "right";
likes_tech_and_music.id = "likes_tech_and_music";
likes_tech_and_music.style.left = "12px";
likes_tech_and_music.style.top = "242px";
likes_tech_and_music.style.width = "120px";
likes_tech_and_music.style.height = "22.5px";
likes_tech_and_music.style.fontFamily = "Open Sans";
likes_tech_and_music.style.fontSize = "11px";
likes_tech_and_music.style.overflow = "hidden";
likes_tech_and_music.style.color = "#000000";

cardd_1.appendChild(likes_tech_and_music);

var joined_25_08_22 = document.createElement("div");
joined_25_08_22.innerHTML = "Joined 25/08/22";
joined_25_08_22.style.textAlign = "right";
joined_25_08_22.id = "joined_25_08_22";
joined_25_08_22.style.left = "12px";
joined_25_08_22.style.top = "262px";
joined_25_08_22.style.width = "92px";
joined_25_08_22.style.height = "22.5px";
joined_25_08_22.style.fontFamily = "Open Sans";
joined_25_08_22.style.fontSize = "11px";
joined_25_08_22.style.overflow = "hidden";
joined_25_08_22.style.color = "#000000";

cardd_1.appendChild(joined_25_08_22);

var cardd_2 = document.createElement("div");
cardd_2.id = "cardd_2";
cardd_2.style.width = "232px";
cardd_2.style.height = "292px";
cardd_2.style.left = "256px";
cardd_2.style.top = "0px";
cardd_2.style.position = "absolute";
card_top_1.appendChild(cardd_2);

var card_background_ek5 = document.createElement("div");
card_background_ek5.id = "card_background_ek5";
card_background_ek5.style.left = "0px";
card_background_ek5.style.top = "0px";
card_background_ek5.style.width = "232px";
card_background_ek5.style.height = "292px";
card_background_ek5.style.borderRadius = "16px";
card_background_ek5.style.background = 'rgba(255,255,255,1)';

cardd_2.appendChild(card_background_ek5);

var bisola = document.createElement("div");
bisola.innerHTML = "Bisola";
bisola.style.fontWeight = "bold";
bisola.style.textAlign = "left";
bisola.id = "bisola";
bisola.style.left = "14px";
bisola.style.top = "179px";
bisola.style.width = "51.5px";
bisola.style.height = "24.5px";
bisola.style.fontFamily = "Poppins";
bisola.style.fontSize = "11px";
bisola.style.overflow = "hidden";
bisola.style.color = "#000000";

cardd_2.appendChild(bisola);

var icon_background_ek1 = document.createElement("div");
icon_background_ek1.id = "icon_background_ek1";
icon_background_ek1.style.left = "0px";
icon_background_ek1.style.top = "0px";
icon_background_ek1.style.width = "232px";
icon_background_ek1.style.height = "168px";
icon_background_ek1.style.borderRadius = "16px";
icon_background_ek1.style.background = 'rgba(188,209,255,0)';

cardd_2.appendChild(icon_background_ek1);

var _20_years_old = document.createElement("div");
_20_years_old.innerHTML = "20 Years old";
_20_years_old.style.textAlign = "right";
_20_years_old.id = "_20_years_old";
_20_years_old.style.left = "12px";
_20_years_old.style.top = "202px";
_20_years_old.style.width = "74px";
_20_years_old.style.height = "22.5px";
_20_years_old.style.fontFamily = "Open Sans";
_20_years_old.style.fontSize = "11px";
_20_years_old.style.overflow = "hidden";
_20_years_old.style.color = "#000000";

cardd_2.appendChild(_20_years_old);

var female__student__christain = document.createElement("div");
female__student__christain.innerHTML = "Female, Student, Christain";
female__student__christain.style.textAlign = "right";
female__student__christain.id = "female__student__christain";
female__student__christain.style.left = "12px";
female__student__christain.style.top = "222px";
female__student__christain.style.width = "146px";
female__student__christain.style.height = "22.5px";
female__student__christain.style.fontFamily = "Open Sans";
female__student__christain.style.fontSize = "11px";
female__student__christain.style.overflow = "hidden";
female__student__christain.style.color = "#000000";

cardd_2.appendChild(female__student__christain);

var likes_tech_and_music_ek1 = document.createElement("div");
likes_tech_and_music_ek1.innerHTML = "Likes Tech and Music";
likes_tech_and_music_ek1.style.textAlign = "right";
likes_tech_and_music_ek1.id = "likes_tech_and_music_ek1";
likes_tech_and_music_ek1.style.left = "12px";
likes_tech_and_music_ek1.style.top = "242px";
likes_tech_and_music_ek1.style.width = "120px";
likes_tech_and_music_ek1.style.height = "22.5px";
likes_tech_and_music_ek1.style.fontFamily = "Open Sans";
likes_tech_and_music_ek1.style.fontSize = "11px";
likes_tech_and_music_ek1.style.overflow = "hidden";
likes_tech_and_music_ek1.style.color = "#000000";

cardd_2.appendChild(likes_tech_and_music_ek1);

var joined_2008_22 = document.createElement("div");
joined_2008_22.innerHTML = "Joined 2008/22";
joined_2008_22.style.textAlign = "right";
joined_2008_22.id = "joined_2008_22";
joined_2008_22.style.left = "16px";
joined_2008_22.style.top = "262px";
joined_2008_22.style.width = "88px";
joined_2008_22.style.height = "22.5px";
joined_2008_22.style.fontFamily = "Open Sans";
joined_2008_22.style.fontSize = "11px";
joined_2008_22.style.overflow = "hidden";
joined_2008_22.style.color = "#000000";

cardd_2.appendChild(joined_2008_22);

var cardd_3 = document.createElement("div");
cardd_3.id = "cardd_3";
cardd_3.style.width = "232px";
cardd_3.style.height = "292px";
cardd_3.style.left = "512px";
cardd_3.style.top = "0px";
cardd_3.style.position = "absolute";
card_top_1.appendChild(cardd_3);

var card_background_ek6 = document.createElement("div");
card_background_ek6.id = "card_background_ek6";
card_background_ek6.style.left = "0px";
card_background_ek6.style.top = "0px";
card_background_ek6.style.width = "232px";
card_background_ek6.style.height = "292px";
card_background_ek6.style.borderRadius = "16px";
card_background_ek6.style.background = 'rgba(255,255,255,1)';

cardd_3.appendChild(card_background_ek6);

var damian = document.createElement("div");
damian.innerHTML = "Damian";
damian.style.fontWeight = "bold";
damian.style.textAlign = "left";
damian.id = "damian";
damian.style.left = "14px";
damian.style.top = "179px";
damian.style.width = "62.5px";
damian.style.height = "24.5px";
damian.style.fontFamily = "Poppins";
damian.style.fontSize = "11px";
damian.style.overflow = "hidden";
damian.style.color = "#000000";

cardd_3.appendChild(damian);

var icon_background_ek2 = document.createElement("div");
icon_background_ek2.id = "icon_background_ek2";
icon_background_ek2.style.left = "0px";
icon_background_ek2.style.top = "0px";
icon_background_ek2.style.width = "232px";
icon_background_ek2.style.height = "168px";
icon_background_ek2.style.borderRadius = "16px";
icon_background_ek2.style.background = 'rgba(188,209,255,0)';

cardd_3.appendChild(icon_background_ek2);

var _25_years_old = document.createElement("div");
_25_years_old.innerHTML = "25 Years old";
_25_years_old.style.textAlign = "right";
_25_years_old.id = "_25_years_old";
_25_years_old.style.left = "12px";
_25_years_old.style.top = "202px";
_25_years_old.style.width = "74px";
_25_years_old.style.height = "22.5px";
_25_years_old.style.fontFamily = "Open Sans";
_25_years_old.style.fontSize = "11px";
_25_years_old.style.overflow = "hidden";
_25_years_old.style.color = "#000000";

cardd_3.appendChild(_25_years_old);

var male__game_dev__christain = document.createElement("div");
male__game_dev__christain.innerHTML = "Male, Game dev, Christain";
male__game_dev__christain.style.textAlign = "right";
male__game_dev__christain.id = "male__game_dev__christain";
male__game_dev__christain.style.left = "13px";
male__game_dev__christain.style.top = "222px";
male__game_dev__christain.style.width = "145px";
male__game_dev__christain.style.height = "22.5px";
male__game_dev__christain.style.fontFamily = "Open Sans";
male__game_dev__christain.style.fontSize = "11px";
male__game_dev__christain.style.overflow = "hidden";
male__game_dev__christain.style.color = "#000000";

cardd_3.appendChild(male__game_dev__christain);

var likes_tech_and_music_ek2 = document.createElement("div");
likes_tech_and_music_ek2.innerHTML = "Likes Tech and Music";
likes_tech_and_music_ek2.style.textAlign = "right";
likes_tech_and_music_ek2.id = "likes_tech_and_music_ek2";
likes_tech_and_music_ek2.style.left = "12px";
likes_tech_and_music_ek2.style.top = "242px";
likes_tech_and_music_ek2.style.width = "120px";
likes_tech_and_music_ek2.style.height = "22.5px";
likes_tech_and_music_ek2.style.fontFamily = "Open Sans";
likes_tech_and_music_ek2.style.fontSize = "11px";
likes_tech_and_music_ek2.style.overflow = "hidden";
likes_tech_and_music_ek2.style.color = "#000000";

cardd_3.appendChild(likes_tech_and_music_ek2);

var joined_25_08_22_ek1 = document.createElement("div");
joined_25_08_22_ek1.innerHTML = "Joined 25/08/22";
joined_25_08_22_ek1.style.textAlign = "right";
joined_25_08_22_ek1.id = "joined_25_08_22_ek1";
joined_25_08_22_ek1.style.left = "12px";
joined_25_08_22_ek1.style.top = "262px";
joined_25_08_22_ek1.style.width = "92px";
joined_25_08_22_ek1.style.height = "22.5px";
joined_25_08_22_ek1.style.fontFamily = "Open Sans";
joined_25_08_22_ek1.style.fontSize = "11px";
joined_25_08_22_ek1.style.overflow = "hidden";
joined_25_08_22_ek1.style.color = "#000000";

cardd_3.appendChild(joined_25_08_22_ek1);

var card_top_2 = document.createElement("div");
card_top_2.id = "card_top_2";
card_top_2.style.width = "405px";
card_top_2.style.height = "292px";
card_top_2.style.left = "0px";
card_top_2.style.top = "311px";
card_top_2.style.position = "absolute";
cardddd.appendChild(card_top_2);

var cardd_4 = document.createElement("div");
cardd_4.id = "cardd_4";
cardd_4.style.width = "232px";
cardd_4.style.height = "292px";
cardd_4.style.left = "0px";
cardd_4.style.top = "0px";
cardd_4.style.position = "absolute";
card_top_2.appendChild(cardd_4);

var card_background_ek7 = document.createElement("div");
card_background_ek7.id = "card_background_ek7";
card_background_ek7.style.left = "0px";
card_background_ek7.style.top = "0px";
card_background_ek7.style.width = "232px";
card_background_ek7.style.height = "292px";
card_background_ek7.style.borderRadius = "16px";
card_background_ek7.style.background = 'rgba(255,255,255,1)';

cardd_4.appendChild(card_background_ek7);

var ahmed = document.createElement("div");
ahmed.innerHTML = "Ahmed";
ahmed.style.fontWeight = "bold";
ahmed.style.textAlign = "left";
ahmed.id = "ahmed";
ahmed.style.left = "14px";
ahmed.style.top = "179px";
ahmed.style.width = "58.5px";
ahmed.style.height = "24.5px";
ahmed.style.fontFamily = "Poppins";
ahmed.style.fontSize = "11px";
ahmed.style.overflow = "hidden";
ahmed.style.color = "#000000";

cardd_4.appendChild(ahmed);

var icon_background_ek3 = document.createElement("div");
icon_background_ek3.id = "icon_background_ek3";
icon_background_ek3.style.left = "0px";
icon_background_ek3.style.top = "0px";
icon_background_ek3.style.width = "232px";
icon_background_ek3.style.height = "168px";
icon_background_ek3.style.borderRadius = "16px";
icon_background_ek3.style.background = 'rgba(188,209,255,0)';

cardd_4.appendChild(icon_background_ek3);

var _27_years_old = document.createElement("div");
_27_years_old.innerHTML = "27 Years old";
_27_years_old.style.textAlign = "right";
_27_years_old.id = "_27_years_old";
_27_years_old.style.left = "12px";
_27_years_old.style.top = "202px";
_27_years_old.style.width = "74px";
_27_years_old.style.height = "22.5px";
_27_years_old.style.fontFamily = "Open Sans";
_27_years_old.style.fontSize = "11px";
_27_years_old.style.overflow = "hidden";
_27_years_old.style.color = "#000000";

cardd_4.appendChild(_27_years_old);

var male__banker__muslim = document.createElement("div");
male__banker__muslim.innerHTML = "Male, Banker, Muslim";
male__banker__muslim.style.textAlign = "right";
male__banker__muslim.id = "male__banker__muslim";
male__banker__muslim.style.left = "12px";
male__banker__muslim.style.top = "221px";
male__banker__muslim.style.width = "122px";
male__banker__muslim.style.height = "22.5px";
male__banker__muslim.style.fontFamily = "Open Sans";
male__banker__muslim.style.fontSize = "11px";
male__banker__muslim.style.overflow = "hidden";
male__banker__muslim.style.color = "#000000";

cardd_4.appendChild(male__banker__muslim);

var likes_art_and_anime = document.createElement("div");
likes_art_and_anime.innerHTML = "Likes Art and Anime";
likes_art_and_anime.style.textAlign = "right";
likes_art_and_anime.id = "likes_art_and_anime";
likes_art_and_anime.style.left = "12px";
likes_art_and_anime.style.top = "241px";
likes_art_and_anime.style.width = "114px";
likes_art_and_anime.style.height = "22.5px";
likes_art_and_anime.style.fontFamily = "Open Sans";
likes_art_and_anime.style.fontSize = "11px";
likes_art_and_anime.style.overflow = "hidden";
likes_art_and_anime.style.color = "#000000";

cardd_4.appendChild(likes_art_and_anime);

var joined_25_08_22_ek2 = document.createElement("div");
joined_25_08_22_ek2.innerHTML = "Joined 25/08/22";
joined_25_08_22_ek2.style.textAlign = "right";
joined_25_08_22_ek2.id = "joined_25_08_22_ek2";
joined_25_08_22_ek2.style.left = "12px";
joined_25_08_22_ek2.style.top = "262px";
joined_25_08_22_ek2.style.width = "92px";
joined_25_08_22_ek2.style.height = "22.5px";
joined_25_08_22_ek2.style.fontFamily = "Open Sans";
joined_25_08_22_ek2.style.fontSize = "11px";
joined_25_08_22_ek2.style.overflow = "hidden";
joined_25_08_22_ek2.style.color = "#000000";

cardd_4.appendChild(joined_25_08_22_ek2);

var cardd_5 = document.createElement("div");
cardd_5.id = "cardd_5";
cardd_5.style.width = "232px";
cardd_5.style.height = "292px";
cardd_5.style.left = "256px";
cardd_5.style.top = "0px";
cardd_5.style.position = "absolute";
card_top_2.appendChild(cardd_5);

var card_background_ek8 = document.createElement("div");
card_background_ek8.id = "card_background_ek8";
card_background_ek8.style.left = "0px";
card_background_ek8.style.top = "0px";
card_background_ek8.style.width = "232px";
card_background_ek8.style.height = "292px";
card_background_ek8.style.borderRadius = "16px";
card_background_ek8.style.background = 'rgba(255,255,255,1)';

cardd_5.appendChild(card_background_ek8);

var bryann = document.createElement("div");
bryann.innerHTML = "Bryann";
bryann.style.fontWeight = "bold";
bryann.style.textAlign = "left";
bryann.id = "bryann";
bryann.style.left = "14px";
bryann.style.top = "179px";
bryann.style.width = "58.5px";
bryann.style.height = "24.5px";
bryann.style.fontFamily = "Poppins";
bryann.style.fontSize = "11px";
bryann.style.overflow = "hidden";
bryann.style.color = "#000000";

cardd_5.appendChild(bryann);

var icon_background_ek4 = document.createElement("div");
icon_background_ek4.id = "icon_background_ek4";
icon_background_ek4.style.left = "0px";
icon_background_ek4.style.top = "0px";
icon_background_ek4.style.width = "232px";
icon_background_ek4.style.height = "168px";
icon_background_ek4.style.borderRadius = "16px";
icon_background_ek4.style.background = 'rgba(188,209,255,0)';

cardd_5.appendChild(icon_background_ek4);

var _20_years_old_ek1 = document.createElement("div");
_20_years_old_ek1.innerHTML = "20 Years old";
_20_years_old_ek1.style.textAlign = "right";
_20_years_old_ek1.id = "_20_years_old_ek1";
_20_years_old_ek1.style.left = "12px";
_20_years_old_ek1.style.top = "202px";
_20_years_old_ek1.style.width = "74px";
_20_years_old_ek1.style.height = "22.5px";
_20_years_old_ek1.style.fontFamily = "Open Sans";
_20_years_old_ek1.style.fontSize = "11px";
_20_years_old_ek1.style.overflow = "hidden";
_20_years_old_ek1.style.color = "#000000";

cardd_5.appendChild(_20_years_old_ek1);

var male__student__christain = document.createElement("div");
male__student__christain.innerHTML = "Male, Student, Christain";
male__student__christain.style.textAlign = "right";
male__student__christain.id = "male__student__christain";
male__student__christain.style.left = "13px";
male__student__christain.style.top = "221px";
male__student__christain.style.width = "134px";
male__student__christain.style.height = "22.5px";
male__student__christain.style.fontFamily = "Open Sans";
male__student__christain.style.fontSize = "11px";
male__student__christain.style.overflow = "hidden";
male__student__christain.style.color = "#000000";

cardd_5.appendChild(male__student__christain);

var likes_tech_and_music_ek3 = document.createElement("div");
likes_tech_and_music_ek3.innerHTML = "Likes Tech and Music";
likes_tech_and_music_ek3.style.textAlign = "right";
likes_tech_and_music_ek3.id = "likes_tech_and_music_ek3";
likes_tech_and_music_ek3.style.left = "12px";
likes_tech_and_music_ek3.style.top = "242px";
likes_tech_and_music_ek3.style.width = "120px";
likes_tech_and_music_ek3.style.height = "22.5px";
likes_tech_and_music_ek3.style.fontFamily = "Open Sans";
likes_tech_and_music_ek3.style.fontSize = "11px";
likes_tech_and_music_ek3.style.overflow = "hidden";
likes_tech_and_music_ek3.style.color = "#000000";

cardd_5.appendChild(likes_tech_and_music_ek3);

var joined_16_02_22 = document.createElement("div");
joined_16_02_22.innerHTML = "Joined 16/02/22";
joined_16_02_22.style.textAlign = "right";
joined_16_02_22.id = "joined_16_02_22";
joined_16_02_22.style.left = "13px";
joined_16_02_22.style.top = "261px";
joined_16_02_22.style.width = "92px";
joined_16_02_22.style.height = "22.5px";
joined_16_02_22.style.fontFamily = "Open Sans";
joined_16_02_22.style.fontSize = "11px";
joined_16_02_22.style.overflow = "hidden";
joined_16_02_22.style.color = "#000000";

cardd_5.appendChild(joined_16_02_22);

var cardd_6 = document.createElement("div");
cardd_6.id = "cardd_6";
cardd_6.style.width = "232px";
cardd_6.style.height = "292px";
cardd_6.style.left = "512px";
cardd_6.style.top = "0px";
cardd_6.style.position = "absolute";
card_top_2.appendChild(cardd_6);

var card_background_ek9 = document.createElement("div");
card_background_ek9.id = "card_background_ek9";
card_background_ek9.style.left = "0px";
card_background_ek9.style.top = "0px";
card_background_ek9.style.width = "232px";
card_background_ek9.style.height = "292px";
card_background_ek9.style.borderRadius = "16px";
card_background_ek9.style.background = 'rgba(255,255,255,1)';

cardd_6.appendChild(card_background_ek9);

var akeem = document.createElement("div");
akeem.innerHTML = "Akeem";
akeem.style.fontWeight = "bold";
akeem.style.textAlign = "left";
akeem.id = "akeem";
akeem.style.left = "14px";
akeem.style.top = "179px";
akeem.style.width = "57.5px";
akeem.style.height = "24.5px";
akeem.style.fontFamily = "Poppins";
akeem.style.fontSize = "11px";
akeem.style.overflow = "hidden";
akeem.style.color = "#000000";

cardd_6.appendChild(akeem);

var icon_background_ek5 = document.createElement("div");
icon_background_ek5.id = "icon_background_ek5";
icon_background_ek5.style.left = "0px";
icon_background_ek5.style.top = "0px";
icon_background_ek5.style.width = "232px";
icon_background_ek5.style.height = "168px";
icon_background_ek5.style.borderRadius = "16px";
icon_background_ek5.style.background = 'rgba(188,209,255,0)';

cardd_6.appendChild(icon_background_ek5);

var _31_years_old = document.createElement("div");
_31_years_old.innerHTML = "31 Years old";
_31_years_old.style.textAlign = "right";
_31_years_old.id = "_31_years_old";
_31_years_old.style.left = "12px";
_31_years_old.style.top = "202px";
_31_years_old.style.width = "74px";
_31_years_old.style.height = "22.5px";
_31_years_old.style.fontFamily = "Open Sans";
_31_years_old.style.fontSize = "11px";
_31_years_old.style.overflow = "hidden";
_31_years_old.style.color = "#000000";

cardd_6.appendChild(_31_years_old);

var male__engineer__muslim = document.createElement("div");
male__engineer__muslim.innerHTML = "Male, Engineer, Muslim";
male__engineer__muslim.style.textAlign = "right";
male__engineer__muslim.id = "male__engineer__muslim";
male__engineer__muslim.style.left = "12px";
male__engineer__muslim.style.top = "222px";
male__engineer__muslim.style.width = "131px";
male__engineer__muslim.style.height = "22.5px";
male__engineer__muslim.style.fontFamily = "Open Sans";
male__engineer__muslim.style.fontSize = "11px";
male__engineer__muslim.style.overflow = "hidden";
male__engineer__muslim.style.color = "#000000";

cardd_6.appendChild(male__engineer__muslim);

var likes_tech_and_art = document.createElement("div");
likes_tech_and_art.innerHTML = "Likes Tech and Art";
likes_tech_and_art.style.textAlign = "right";
likes_tech_and_art.id = "likes_tech_and_art";
likes_tech_and_art.style.left = "12px";
likes_tech_and_art.style.top = "243px";
likes_tech_and_art.style.width = "105px";
likes_tech_and_art.style.height = "22.5px";
likes_tech_and_art.style.fontFamily = "Open Sans";
likes_tech_and_art.style.fontSize = "11px";
likes_tech_and_art.style.overflow = "hidden";
likes_tech_and_art.style.color = "#000000";

cardd_6.appendChild(likes_tech_and_art);

var joined_15_09_22 = document.createElement("div");
joined_15_09_22.innerHTML = "Joined 15/09/22";
joined_15_09_22.style.textAlign = "right";
joined_15_09_22.id = "joined_15_09_22";
joined_15_09_22.style.left = "12px";
joined_15_09_22.style.top = "262px";
joined_15_09_22.style.width = "92px";
joined_15_09_22.style.height = "22.5px";
joined_15_09_22.style.fontFamily = "Open Sans";
joined_15_09_22.style.fontSize = "11px";
joined_15_09_22.style.overflow = "hidden";
joined_15_09_22.style.color = "#000000";

cardd_6.appendChild(joined_15_09_22);

var card_top_3 = document.createElement("div");
card_top_3.id = "card_top_3";
card_top_3.style.width = "405px";
card_top_3.style.height = "292px";
card_top_3.style.left = "0px";
card_top_3.style.top = "622px";
card_top_3.style.position = "absolute";
cardddd.appendChild(card_top_3);

var cardd_7 = document.createElement("div");
cardd_7.id = "cardd_7";
cardd_7.style.width = "232px";
cardd_7.style.height = "292px";
cardd_7.style.left = "0px";
cardd_7.style.top = "0px";
cardd_7.style.position = "absolute";
card_top_3.appendChild(cardd_7);

var card_background_ek10 = document.createElement("div");
card_background_ek10.id = "card_background_ek10";
card_background_ek10.style.left = "0px";
card_background_ek10.style.top = "0px";
card_background_ek10.style.width = "232px";
card_background_ek10.style.height = "292px";
card_background_ek10.style.borderRadius = "16px";
card_background_ek10.style.background = 'rgba(255,255,255,1)';

cardd_7.appendChild(card_background_ek10);

var bella = document.createElement("div");
bella.innerHTML = "Bella";
bella.style.fontWeight = "bold";
bella.style.textAlign = "left";
bella.id = "bella";
bella.style.left = "14px";
bella.style.top = "179px";
bella.style.width = "44.5px";
bella.style.height = "24.5px";
bella.style.fontFamily = "Poppins";
bella.style.fontSize = "11px";
bella.style.overflow = "hidden";
bella.style.color = "#000000";

cardd_7.appendChild(bella);

var icon_background_ek6 = document.createElement("div");
icon_background_ek6.id = "icon_background_ek6";
icon_background_ek6.style.left = "0px";
icon_background_ek6.style.top = "0px";
icon_background_ek6.style.width = "232px";
icon_background_ek6.style.height = "168px";
icon_background_ek6.style.borderRadius = "16px";
icon_background_ek6.style.background = 'rgba(188,209,255,0)';

cardd_7.appendChild(icon_background_ek6);

var _25_years_old_ek1 = document.createElement("div");
_25_years_old_ek1.innerHTML = "25 Years old";
_25_years_old_ek1.style.textAlign = "right";
_25_years_old_ek1.id = "_25_years_old_ek1";
_25_years_old_ek1.style.left = "12px";
_25_years_old_ek1.style.top = "202px";
_25_years_old_ek1.style.width = "74px";
_25_years_old_ek1.style.height = "22.5px";
_25_years_old_ek1.style.fontFamily = "Open Sans";
_25_years_old_ek1.style.fontSize = "11px";
_25_years_old_ek1.style.overflow = "hidden";
_25_years_old_ek1.style.color = "#000000";

cardd_7.appendChild(_25_years_old_ek1);

var female__student__christain_ek1 = document.createElement("div");
female__student__christain_ek1.innerHTML = "Female, Student, Christain";
female__student__christain_ek1.style.textAlign = "right";
female__student__christain_ek1.id = "female__student__christain_ek1";
female__student__christain_ek1.style.left = "12px";
female__student__christain_ek1.style.top = "222px";
female__student__christain_ek1.style.width = "146px";
female__student__christain_ek1.style.height = "22.5px";
female__student__christain_ek1.style.fontFamily = "Open Sans";
female__student__christain_ek1.style.fontSize = "11px";
female__student__christain_ek1.style.overflow = "hidden";
female__student__christain_ek1.style.color = "#000000";

cardd_7.appendChild(female__student__christain_ek1);

var likes_singing_and_music = document.createElement("div");
likes_singing_and_music.innerHTML = "Likes Singing and Music";
likes_singing_and_music.style.textAlign = "right";
likes_singing_and_music.id = "likes_singing_and_music";
likes_singing_and_music.style.left = "12px";
likes_singing_and_music.style.top = "242px";
likes_singing_and_music.style.width = "132px";
likes_singing_and_music.style.height = "22.5px";
likes_singing_and_music.style.fontFamily = "Open Sans";
likes_singing_and_music.style.fontSize = "11px";
likes_singing_and_music.style.overflow = "hidden";
likes_singing_and_music.style.color = "#000000";

cardd_7.appendChild(likes_singing_and_music);

var joined_25_08_22_ek3 = document.createElement("div");
joined_25_08_22_ek3.innerHTML = "Joined 25/08/22";
joined_25_08_22_ek3.style.textAlign = "right";
joined_25_08_22_ek3.id = "joined_25_08_22_ek3";
joined_25_08_22_ek3.style.left = "12px";
joined_25_08_22_ek3.style.top = "262px";
joined_25_08_22_ek3.style.width = "92px";
joined_25_08_22_ek3.style.height = "22.5px";
joined_25_08_22_ek3.style.fontFamily = "Open Sans";
joined_25_08_22_ek3.style.fontSize = "11px";
joined_25_08_22_ek3.style.overflow = "hidden";
joined_25_08_22_ek3.style.color = "#000000";

cardd_7.appendChild(joined_25_08_22_ek3);

var cardd_8 = document.createElement("div");
cardd_8.id = "cardd_8";
cardd_8.style.width = "232px";
cardd_8.style.height = "292px";
cardd_8.style.left = "256px";
cardd_8.style.top = "0px";
cardd_8.style.position = "absolute";
card_top_3.appendChild(cardd_8);

var card_background_ek11 = document.createElement("div");
card_background_ek11.id = "card_background_ek11";
card_background_ek11.style.left = "0px";
card_background_ek11.style.top = "0px";
card_background_ek11.style.width = "232px";
card_background_ek11.style.height = "292px";
card_background_ek11.style.borderRadius = "16px";
card_background_ek11.style.background = 'rgba(255,255,255,1)';

cardd_8.appendChild(card_background_ek11);

var paulinha = document.createElement("div");
paulinha.innerHTML = "Paulinha";
paulinha.style.fontWeight = "bold";
paulinha.style.textAlign = "left";
paulinha.id = "paulinha";
paulinha.style.left = "14px";
paulinha.style.top = "179px";
paulinha.style.width = "67.5px";
paulinha.style.height = "24.5px";
paulinha.style.fontFamily = "Poppins";
paulinha.style.fontSize = "11px";
paulinha.style.overflow = "hidden";
paulinha.style.color = "#000000";

cardd_8.appendChild(paulinha);

var icon_background_ek7 = document.createElement("div");
icon_background_ek7.id = "icon_background_ek7";
icon_background_ek7.style.left = "0px";
icon_background_ek7.style.top = "0px";
icon_background_ek7.style.width = "232px";
icon_background_ek7.style.height = "168px";
icon_background_ek7.style.borderRadius = "16px";
icon_background_ek7.style.background = 'rgba(188,209,255,0)';

cardd_8.appendChild(icon_background_ek7);

var _21_years_old_ek1 = document.createElement("div");
_21_years_old_ek1.innerHTML = "21 Years old";
_21_years_old_ek1.style.textAlign = "right";
_21_years_old_ek1.id = "_21_years_old_ek1";
_21_years_old_ek1.style.left = "12px";
_21_years_old_ek1.style.top = "202px";
_21_years_old_ek1.style.width = "74px";
_21_years_old_ek1.style.height = "22.5px";
_21_years_old_ek1.style.fontFamily = "Open Sans";
_21_years_old_ek1.style.fontSize = "11px";
_21_years_old_ek1.style.overflow = "hidden";
_21_years_old_ek1.style.color = "#000000";

cardd_8.appendChild(_21_years_old_ek1);

var female__student__christain_ek2 = document.createElement("div");
female__student__christain_ek2.innerHTML = "Female, Student, Christain";
female__student__christain_ek2.style.textAlign = "right";
female__student__christain_ek2.id = "female__student__christain_ek2";
female__student__christain_ek2.style.left = "12px";
female__student__christain_ek2.style.top = "222px";
female__student__christain_ek2.style.width = "146px";
female__student__christain_ek2.style.height = "22.5px";
female__student__christain_ek2.style.fontFamily = "Open Sans";
female__student__christain_ek2.style.fontSize = "11px";
female__student__christain_ek2.style.overflow = "hidden";
female__student__christain_ek2.style.color = "#000000";

cardd_8.appendChild(female__student__christain_ek2);

var likes_tech_and_music_ek4 = document.createElement("div");
likes_tech_and_music_ek4.innerHTML = "Likes Tech and Music";
likes_tech_and_music_ek4.style.textAlign = "right";
likes_tech_and_music_ek4.id = "likes_tech_and_music_ek4";
likes_tech_and_music_ek4.style.left = "12px";
likes_tech_and_music_ek4.style.top = "242px";
likes_tech_and_music_ek4.style.width = "120px";
likes_tech_and_music_ek4.style.height = "22.5px";
likes_tech_and_music_ek4.style.fontFamily = "Open Sans";
likes_tech_and_music_ek4.style.fontSize = "11px";
likes_tech_and_music_ek4.style.overflow = "hidden";
likes_tech_and_music_ek4.style.color = "#000000";

cardd_8.appendChild(likes_tech_and_music_ek4);

var joined_25_08_22_ek4 = document.createElement("div");
joined_25_08_22_ek4.innerHTML = "Joined 25/08/22";
joined_25_08_22_ek4.style.textAlign = "right";
joined_25_08_22_ek4.id = "joined_25_08_22_ek4";
joined_25_08_22_ek4.style.left = "12px";
joined_25_08_22_ek4.style.top = "262px";
joined_25_08_22_ek4.style.width = "92px";
joined_25_08_22_ek4.style.height = "22.5px";
joined_25_08_22_ek4.style.fontFamily = "Open Sans";
joined_25_08_22_ek4.style.fontSize = "11px";
joined_25_08_22_ek4.style.overflow = "hidden";
joined_25_08_22_ek4.style.color = "#000000";

cardd_8.appendChild(joined_25_08_22_ek4);

var cardd_9 = document.createElement("div");
cardd_9.id = "cardd_9";
cardd_9.style.width = "232px";
cardd_9.style.height = "292px";
cardd_9.style.left = "512px";
cardd_9.style.top = "0px";
cardd_9.style.position = "absolute";
card_top_3.appendChild(cardd_9);

var card_background_ek12 = document.createElement("div");
card_background_ek12.id = "card_background_ek12";
card_background_ek12.style.left = "0px";
card_background_ek12.style.top = "0px";
card_background_ek12.style.width = "232px";
card_background_ek12.style.height = "292px";
card_background_ek12.style.borderRadius = "16px";
card_background_ek12.style.background = 'rgba(255,255,255,1)';

cardd_9.appendChild(card_background_ek12);

var deji = document.createElement("div");
deji.innerHTML = "Deji";
deji.style.fontWeight = "bold";
deji.style.textAlign = "left";
deji.id = "deji";
deji.style.left = "14px";
deji.style.top = "179px";
deji.style.width = "38.5px";
deji.style.height = "24.5px";
deji.style.fontFamily = "Poppins";
deji.style.fontSize = "11px";
deji.style.overflow = "hidden";
deji.style.color = "#000000";

cardd_9.appendChild(deji);

var icon_background_ek8 = document.createElement("div");
icon_background_ek8.id = "icon_background_ek8";
icon_background_ek8.style.left = "0px";
icon_background_ek8.style.top = "0px";
icon_background_ek8.style.width = "232px";
icon_background_ek8.style.height = "168px";
icon_background_ek8.style.borderRadius = "16px";
icon_background_ek8.style.background = 'rgba(188,209,255,0)';

cardd_9.appendChild(icon_background_ek8);

var _21_years_old_ek2 = document.createElement("div");
_21_years_old_ek2.innerHTML = "21 Years old";
_21_years_old_ek2.style.textAlign = "right";
_21_years_old_ek2.id = "_21_years_old_ek2";
_21_years_old_ek2.style.left = "12px";
_21_years_old_ek2.style.top = "202px";
_21_years_old_ek2.style.width = "74px";
_21_years_old_ek2.style.height = "22.5px";
_21_years_old_ek2.style.fontFamily = "Open Sans";
_21_years_old_ek2.style.fontSize = "11px";
_21_years_old_ek2.style.overflow = "hidden";
_21_years_old_ek2.style.color = "#000000";

cardd_9.appendChild(_21_years_old_ek2);

var male__student__christain_ek1 = document.createElement("div");
male__student__christain_ek1.innerHTML = "Male, Student, Christain";
male__student__christain_ek1.style.textAlign = "right";
male__student__christain_ek1.id = "male__student__christain_ek1";
male__student__christain_ek1.style.left = "11px";
male__student__christain_ek1.style.top = "221px";
male__student__christain_ek1.style.width = "134px";
male__student__christain_ek1.style.height = "22.5px";
male__student__christain_ek1.style.fontFamily = "Open Sans";
male__student__christain_ek1.style.fontSize = "11px";
male__student__christain_ek1.style.overflow = "hidden";
male__student__christain_ek1.style.color = "#000000";

cardd_9.appendChild(male__student__christain_ek1);

var likes_tech_and_music_ek5 = document.createElement("div");
likes_tech_and_music_ek5.innerHTML = "Likes Tech and Music";
likes_tech_and_music_ek5.style.textAlign = "right";
likes_tech_and_music_ek5.id = "likes_tech_and_music_ek5";
likes_tech_and_music_ek5.style.left = "12px";
likes_tech_and_music_ek5.style.top = "242px";
likes_tech_and_music_ek5.style.width = "120px";
likes_tech_and_music_ek5.style.height = "22.5px";
likes_tech_and_music_ek5.style.fontFamily = "Open Sans";
likes_tech_and_music_ek5.style.fontSize = "11px";
likes_tech_and_music_ek5.style.overflow = "hidden";
likes_tech_and_music_ek5.style.color = "#000000";

cardd_9.appendChild(likes_tech_and_music_ek5);

var joined_25_08_22_ek5 = document.createElement("div");
joined_25_08_22_ek5.innerHTML = "Joined 25/08/22";
joined_25_08_22_ek5.style.textAlign = "right";
joined_25_08_22_ek5.id = "joined_25_08_22_ek5";
joined_25_08_22_ek5.style.left = "12px";
joined_25_08_22_ek5.style.top = "262px";
joined_25_08_22_ek5.style.width = "92px";
joined_25_08_22_ek5.style.height = "22.5px";
joined_25_08_22_ek5.style.fontFamily = "Open Sans";
joined_25_08_22_ek5.style.fontSize = "11px";
joined_25_08_22_ek5.style.overflow = "hidden";
joined_25_08_22_ek5.style.color = "#000000";

cardd_9.appendChild(joined_25_08_22_ek5);

var down_ek3 = document.createElement("div");
down_ek3.id = "down_ek3";
down_ek3.style.width = "428px";
down_ek3.style.height = "105px";
down_ek3.style.left = "0px";
down_ek3.style.top = "728px";
down_ek3.style.position = "absolute";
page_roommate_search_ek1.appendChild(down_ek3);

var rectangle_3_ek5 = document.createElement("div");
rectangle_3_ek5.id = "rectangle_3_ek5";
rectangle_3_ek5.style.left = "0px";
rectangle_3_ek5.style.opacity = "0.75999999046326";
rectangle_3_ek5.style.filter = "alpha(opacity='75.999999046326')";
rectangle_3_ek5.style.top = "0px";
rectangle_3_ek5.style.width = "428px";
rectangle_3_ek5.style.height = "105px";
rectangle_3_ek5.style.borderRadius = "10px";
rectangle_3_ek5.style.background = 'rgba(253.94,253.94,253.94,0.76)';

down_ek3.appendChild(rectangle_3_ek5);

var vector_ek79 = document.createElement("img");
vector_ek79.id = "vector_ek79";
vector_ek79.style.left = "30.64px";
vector_ek79.style.top = "38px";
vector_ek79.style.width = "29.62px";
vector_ek79.style.height = "29px";
vector_ek79.src = "skins/vector_ek79.png";

down_ek3.appendChild(vector_ek79);

var vector_ek80 = document.createElement("img");
vector_ek80.id = "vector_ek80";
vector_ek80.style.left = "147.09px";
vector_ek80.style.top = "38px";
vector_ek80.style.width = "29.62px";
vector_ek80.style.height = "29px";
vector_ek80.src = "skins/vector_ek80.png";

down_ek3.appendChild(vector_ek80);

var vector_ek81 = document.createElement("img");
vector_ek81.id = "vector_ek81";
vector_ek81.style.left = "260.48px";
vector_ek81.style.top = "43px";
vector_ek81.style.width = "29.62px";
vector_ek81.style.height = "29px";
vector_ek81.src = "skins/vector_ek81.png";

down_ek3.appendChild(vector_ek81);

var group_ek10 = document.createElement("div");
group_ek10.id = "group_ek10";
group_ek10.style.width = "29.62px";
group_ek10.style.height = "29px";
group_ek10.style.left = "375px";
group_ek10.style.top = "9px";
group_ek10.style.position = "absolute";
down_ek3.appendChild(group_ek10);

var vector_ek82 = document.createElement("img");
vector_ek82.id = "vector_ek82";
vector_ek82.style.left = "0px";
vector_ek82.style.top = "0px";
vector_ek82.style.width = "29.62px";
vector_ek82.style.height = "29px";
vector_ek82.src = "skins/vector_ek82.png";

group_ek10.appendChild(vector_ek82);

var home_ek6 = document.createElement("div");
home_ek6.innerHTML = "Home";
home_ek6.style.textAlign = "left";
home_ek6.id = "home_ek6";
home_ek6.style.left = "26.56px";
home_ek6.style.top = "72px";
home_ek6.style.width = "61.9px";
home_ek6.style.height = "31px";
home_ek6.style.fontFamily = "Poppins";
home_ek6.style.fontSize = "14px";
home_ek6.style.overflow = "hidden";
home_ek6.style.color = "#000000";

down_ek3.appendChild(home_ek6);

var search_ek10 = document.createElement("div");
search_ek10.innerHTML = "Search";
search_ek10.style.textAlign = "left";
search_ek10.id = "search_ek10";
search_ek10.style.left = "138.92px";
search_ek10.style.top = "72px";
search_ek10.style.width = "70.07px";
search_ek10.style.height = "31px";
search_ek10.style.fontFamily = "Poppins";
search_ek10.style.fontSize = "14px";
search_ek10.style.overflow = "hidden";
search_ek10.style.color = "#CB5A7A";

down_ek3.appendChild(search_ek10);

var saved_ek3 = document.createElement("div");
saved_ek3.innerHTML = "Saved";
saved_ek3.style.textAlign = "left";
saved_ek3.id = "saved_ek3";
saved_ek3.style.left = "253.33px";
saved_ek3.style.top = "72px";
saved_ek3.style.width = "63.95px";
saved_ek3.style.height = "31px";
saved_ek3.style.fontFamily = "Poppins";
saved_ek3.style.fontSize = "14px";
saved_ek3.style.overflow = "hidden";
saved_ek3.style.color = "#000000";

down_ek3.appendChild(saved_ek3);

var account_ek3 = document.createElement("div");
account_ek3.innerHTML = "Account";
account_ek3.style.textAlign = "left";
account_ek3.id = "account_ek3";
account_ek3.style.left = "359.56px";
account_ek3.style.top = "72px";
account_ek3.style.width = "79.27px";
account_ek3.style.height = "31px";
account_ek3.style.fontFamily = "Poppins";
account_ek3.style.fontSize = "14px";
account_ek3.style.overflow = "hidden";
account_ek3.style.color = "#07132A";

down_ek3.appendChild(account_ek3);




