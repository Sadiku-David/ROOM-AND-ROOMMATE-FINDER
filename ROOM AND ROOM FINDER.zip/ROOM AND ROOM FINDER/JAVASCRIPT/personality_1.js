/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);
var page_personality_1_ek1 = document.createElement("div");
page_personality_1_ek1.id = "page_personality_1_ek1";
page_personality_1_ek1.style.width = "428px";
page_personality_1_ek1.style.height = "826px";
page_personality_1_ek1.style.left = "0px";
page_personality_1_ek1.style.top = "0px";
page_personality_1_ek1.style.position = "absolute";
content_container.appendChild(page_personality_1_ek1);

var _bg__personality_1_ek2 = document.createElement("div");
_bg__personality_1_ek2.id = "_bg__personality_1_ek2";
_bg__personality_1_ek2.style.left = "0px";
_bg__personality_1_ek2.style.top = "0px";
_bg__personality_1_ek2.style.width = "428px";
_bg__personality_1_ek2.style.height = "826px";
_bg__personality_1_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_personality_1_ek1.appendChild(_bg__personality_1_ek2);

var rectangle_13 = document.createElement("div");
rectangle_13.id = "rectangle_13";
rectangle_13.style.left = "22px";
rectangle_13.style.top = "43px";
rectangle_13.style.width = "385px";
rectangle_13.style.height = "7px";
rectangle_13.style.borderRadius = "7px";
rectangle_13.style.background = 'rgba(205.2,205.2,205.2,1)';

page_personality_1_ek1.appendChild(rectangle_13);

var rectangle_14 = document.createElement("div");
rectangle_14.id = "rectangle_14";
rectangle_14.style.left = "22px";
rectangle_14.style.top = "43px";
rectangle_14.style.width = "82px";
rectangle_14.style.height = "7px";
rectangle_14.style.borderRadius = "7px";
rectangle_14.style.background = 'rgba(203,90,122,1)';

page_personality_1_ek1.appendChild(rectangle_14);

var steps_1_4_personality = document.createElement("div");
steps_1_4_personality.innerHTML = "Steps 1/4 Personality";
steps_1_4_personality.style.textAlign = "left";
steps_1_4_personality.id = "steps_1_4_personality";
steps_1_4_personality.style.left = "22px";
steps_1_4_personality.style.top = "22px";
steps_1_4_personality.style.width = "162px";
steps_1_4_personality.style.height = "31px";
steps_1_4_personality.style.fontFamily = "Poppins";
steps_1_4_personality.style.fontSize = "14px";
steps_1_4_personality.style.overflow = "hidden";
steps_1_4_personality.style.color = "#000000";

page_personality_1_ek1.appendChild(steps_1_4_personality);

var how_would_you_describe_your_personality = document.createElement("div");
how_would_you_describe_your_personality.innerHTML = "How would you describe your <br/>Personality";
how_would_you_describe_your_personality.style.fontWeight = "bold";
how_would_you_describe_your_personality.style.textAlign = "left";
how_would_you_describe_your_personality.id = "how_would_you_describe_your_personality";
how_would_you_describe_your_personality.style.left = "22px";
how_would_you_describe_your_personality.style.top = "64px";
how_would_you_describe_your_personality.style.width = "231px";
how_would_you_describe_your_personality.style.height = "52px";
how_would_you_describe_your_personality.style.fontFamily = "Poppins";
how_would_you_describe_your_personality.style.fontSize = "14px";
how_would_you_describe_your_personality.style.overflow = "hidden";
how_would_you_describe_your_personality.style.color = "#000000";

page_personality_1_ek1.appendChild(how_would_you_describe_your_personality);

var please_choose_all_that_apply = document.createElement("div");
please_choose_all_that_apply.innerHTML = "Please choose all that apply";
please_choose_all_that_apply.style.textAlign = "left";
please_choose_all_that_apply.id = "please_choose_all_that_apply";
please_choose_all_that_apply.style.left = "22px";
please_choose_all_that_apply.style.top = "106px";
please_choose_all_that_apply.style.width = "152px";
please_choose_all_that_apply.style.height = "22px";
please_choose_all_that_apply.style.fontFamily = "Poppins";
please_choose_all_that_apply.style.fontSize = "10px";
please_choose_all_that_apply.style.overflow = "hidden";
please_choose_all_that_apply.style.color = "#000000";

page_personality_1_ek1.appendChild(please_choose_all_that_apply);

var rectangle_15 = document.createElement("div");
rectangle_15.id = "rectangle_15";
rectangle_15.style.left = "22px";
rectangle_15.style.top = "133px";
rectangle_15.style.width = "82px";
rectangle_15.style.height = "32px";
rectangle_15.style.borderRadius = "20px";
rectangle_15.style.background = 'rgba(203,90,122,1)';

page_personality_1_ek1.appendChild(rectangle_15);

var rectangle_19 = document.createElement("div");
rectangle_19.id = "rectangle_19";
rectangle_19.style.left = "22px";
rectangle_19.style.top = "186px";
rectangle_19.style.width = "82px";
rectangle_19.style.height = "32px";
rectangle_19.style.borderRadius = "20px";
rectangle_19.style.background = 'rgba(203,90,122,1)';

page_personality_1_ek1.appendChild(rectangle_19);

var rectangle_22 = document.createElement("div");
rectangle_22.id = "rectangle_22";
rectangle_22.style.left = "118px";
rectangle_22.style.top = "186px";
rectangle_22.style.width = "84px";
rectangle_22.style.height = "34px";
rectangle_22.style.borderRadius = "20px";
rectangle_22.style.border = "1px solid #cb5a7a";
rectangle_22.style.background = 'rgba(255,255,255,0)';

page_personality_1_ek1.appendChild(rectangle_22);

var extrovert = document.createElement("div");
extrovert.innerHTML = "Extrovert";
extrovert.style.textAlign = "left";
extrovert.id = "extrovert";
extrovert.style.left = "137px";
extrovert.style.top = "195px";
extrovert.style.width = "59px";
extrovert.style.height = "22px";
extrovert.style.fontFamily = "Poppins";
extrovert.style.fontSize = "10px";
extrovert.style.overflow = "hidden";
extrovert.style.color = "#CB5A7A";

page_personality_1_ek1.appendChild(extrovert);

var rectangle_23 = document.createElement("div");
rectangle_23.id = "rectangle_23";
rectangle_23.style.left = "214px";
rectangle_23.style.top = "186px";
rectangle_23.style.width = "82px";
rectangle_23.style.height = "32px";
rectangle_23.style.borderRadius = "20px";
rectangle_23.style.background = 'rgba(203,90,122,1)';

page_personality_1_ek1.appendChild(rectangle_23);

var friendly = document.createElement("div");
friendly.innerHTML = "Friendly";
friendly.style.textAlign = "left";
friendly.id = "friendly";
friendly.style.left = "235px";
friendly.style.top = "195px";
friendly.style.width = "55px";
friendly.style.height = "22px";
friendly.style.fontFamily = "Poppins";
friendly.style.fontSize = "10px";
friendly.style.overflow = "hidden";
friendly.style.color = "#FFFFFF";

page_personality_1_ek1.appendChild(friendly);

var rectangle_24 = document.createElement("div");
rectangle_24.id = "rectangle_24";
rectangle_24.style.left = "310px";
rectangle_24.style.top = "186px";
rectangle_24.style.width = "84px";
rectangle_24.style.height = "34px";
rectangle_24.style.borderRadius = "20px";
rectangle_24.style.border = "1px solid #cb5a7a";
rectangle_24.style.background = 'rgba(255,255,255,0)';

page_personality_1_ek1.appendChild(rectangle_24);

var fun = document.createElement("div");
fun.innerHTML = "Fun";
fun.style.textAlign = "left";
fun.id = "fun";
fun.style.left = "342px";
fun.style.top = "195px";
fun.style.width = "34px";
fun.style.height = "22px";
fun.style.fontFamily = "Poppins";
fun.style.fontSize = "10px";
fun.style.overflow = "hidden";
fun.style.color = "#CB5A7A";

page_personality_1_ek1.appendChild(fun);

var rectangle_20 = document.createElement("div");
rectangle_20.id = "rectangle_20";
rectangle_20.style.left = "22px";
rectangle_20.style.top = "239px";
rectangle_20.style.width = "82px";
rectangle_20.style.height = "32px";
rectangle_20.style.borderRadius = "20px";
rectangle_20.style.background = 'rgba(203,90,122,1)';

page_personality_1_ek1.appendChild(rectangle_20);

var caring = document.createElement("div");
caring.innerHTML = "Caring";
caring.style.textAlign = "left";
caring.id = "caring";
caring.style.left = "45px";
caring.style.top = "248px";
caring.style.width = "50px";
caring.style.height = "22px";
caring.style.fontFamily = "Poppins";
caring.style.fontSize = "10px";
caring.style.overflow = "hidden";
caring.style.color = "#FFFFFF";

page_personality_1_ek1.appendChild(caring);

var rectangle_25 = document.createElement("div");
rectangle_25.id = "rectangle_25";
rectangle_25.style.left = "118px";
rectangle_25.style.top = "239px";
rectangle_25.style.width = "84px";
rectangle_25.style.height = "34px";
rectangle_25.style.borderRadius = "20px";
rectangle_25.style.border = "1px solid #cb5a7a";
rectangle_25.style.background = 'rgba(255,255,255,0)';

page_personality_1_ek1.appendChild(rectangle_25);

var sensitive = document.createElement("div");
sensitive.innerHTML = "Sensitive";
sensitive.style.textAlign = "left";
sensitive.id = "sensitive";
sensitive.style.left = "137px";
sensitive.style.top = "248px";
sensitive.style.width = "60px";
sensitive.style.height = "22px";
sensitive.style.fontFamily = "Poppins";
sensitive.style.fontSize = "10px";
sensitive.style.overflow = "hidden";
sensitive.style.color = "#CB5A7A";

page_personality_1_ek1.appendChild(sensitive);

var rectangle_26 = document.createElement("div");
rectangle_26.id = "rectangle_26";
rectangle_26.style.left = "214px";
rectangle_26.style.top = "239px";
rectangle_26.style.width = "84px";
rectangle_26.style.height = "34px";
rectangle_26.style.borderRadius = "20px";
rectangle_26.style.border = "1px solid #cb5a7a";
rectangle_26.style.background = 'rgba(255,255,255,0)';

page_personality_1_ek1.appendChild(rectangle_26);

var talkative = document.createElement("div");
talkative.innerHTML = "Talkative";
talkative.style.textAlign = "left";
talkative.id = "talkative";
talkative.style.left = "232px";
talkative.style.top = "248px";
talkative.style.width = "61px";
talkative.style.height = "22px";
talkative.style.fontFamily = "Poppins";
talkative.style.fontSize = "10px";
talkative.style.overflow = "hidden";
talkative.style.color = "#CB5A7A";

page_personality_1_ek1.appendChild(talkative);

var l = document.createElement("div");
l.innerHTML = "l";
l.style.textAlign = "left";
l.id = "l";
l.style.left = "340px";
l.style.top = "252px";
l.style.width = "18px";
l.style.height = "22px";
l.style.fontFamily = "Poppins";
l.style.fontSize = "10px";
l.style.overflow = "hidden";
l.style.color = "#000000";

page_personality_1_ek1.appendChild(l);

var rectangle_27 = document.createElement("div");
rectangle_27.id = "rectangle_27";
rectangle_27.style.left = "310px";
rectangle_27.style.top = "239px";
rectangle_27.style.width = "82px";
rectangle_27.style.height = "32px";
rectangle_27.style.borderRadius = "20px";
rectangle_27.style.background = 'rgba(203,90,122,1)';

page_personality_1_ek1.appendChild(rectangle_27);

var rectangle_21 = document.createElement("div");
rectangle_21.id = "rectangle_21";
rectangle_21.style.left = "22px";
rectangle_21.style.top = "292px";
rectangle_21.style.width = "84px";
rectangle_21.style.height = "34px";
rectangle_21.style.borderRadius = "20px";
rectangle_21.style.border = "1px solid #cb5a7a";
rectangle_21.style.background = 'rgba(255,255,255,0)';

page_personality_1_ek1.appendChild(rectangle_21);

var sociable = document.createElement("div");
sociable.innerHTML = "Sociable";
sociable.style.textAlign = "left";
sociable.id = "sociable";
sociable.style.left = "40px";
sociable.style.top = "301px";
sociable.style.width = "59px";
sociable.style.height = "22px";
sociable.style.fontFamily = "Poppins";
sociable.style.fontSize = "10px";
sociable.style.overflow = "hidden";
sociable.style.color = "#CB5A7A";

page_personality_1_ek1.appendChild(sociable);

var rectangle_28 = document.createElement("div");
rectangle_28.id = "rectangle_28";
rectangle_28.style.left = "118px";
rectangle_28.style.top = "292px";
rectangle_28.style.width = "84px";
rectangle_28.style.height = "34px";
rectangle_28.style.borderRadius = "20px";
rectangle_28.style.border = "1px solid #cb5a7a";
rectangle_28.style.background = 'rgba(255,255,255,0)';

page_personality_1_ek1.appendChild(rectangle_28);

var rectangle_16 = document.createElement("div");
rectangle_16.id = "rectangle_16";
rectangle_16.style.left = "118px";
rectangle_16.style.top = "133px";
rectangle_16.style.width = "84px";
rectangle_16.style.height = "34px";
rectangle_16.style.borderRadius = "20px";
rectangle_16.style.border = "1px solid #cb5a7a";
rectangle_16.style.background = 'rgba(255,255,255,0)';

page_personality_1_ek1.appendChild(rectangle_16);

var rectangle_17 = document.createElement("div");
rectangle_17.id = "rectangle_17";
rectangle_17.style.left = "214px";
rectangle_17.style.top = "133px";
rectangle_17.style.width = "84px";
rectangle_17.style.height = "34px";
rectangle_17.style.borderRadius = "20px";
rectangle_17.style.border = "1px solid #cb5a7a";
rectangle_17.style.background = 'rgba(255,255,255,0)';

page_personality_1_ek1.appendChild(rectangle_17);

var calm = document.createElement("div");
calm.innerHTML = "Calm";
calm.style.textAlign = "left";
calm.id = "calm";
calm.style.left = "241px";
calm.style.top = "142px";
calm.style.width = "43px";
calm.style.height = "22px";
calm.style.fontFamily = "Poppins";
calm.style.fontSize = "10px";
calm.style.overflow = "hidden";
calm.style.color = "#CB5A7A";

page_personality_1_ek1.appendChild(calm);

var introvert = document.createElement("div");
introvert.innerHTML = "Introvert";
introvert.style.textAlign = "left";
introvert.id = "introvert";
introvert.style.left = "42px";
introvert.style.top = "195px";
introvert.style.width = "58px";
introvert.style.height = "22px";
introvert.style.fontFamily = "Poppins";
introvert.style.fontSize = "10px";
introvert.style.overflow = "hidden";
introvert.style.color = "#FFFFFF";

page_personality_1_ek1.appendChild(introvert);

var respectful = document.createElement("div");
respectful.innerHTML = "Respectful";
respectful.style.textAlign = "left";
respectful.id = "respectful";
respectful.style.left = "37px";
respectful.style.top = "142px";
respectful.style.width = "68px";
respectful.style.height = "22px";
respectful.style.fontFamily = "Poppins";
respectful.style.fontSize = "10px";
respectful.style.overflow = "hidden";
respectful.style.color = "#FFFFFF";

page_personality_1_ek1.appendChild(respectful);

var organized = document.createElement("div");
organized.innerHTML = "Organized";
organized.style.textAlign = "left";
organized.id = "organized";
organized.style.left = "133px";
organized.style.top = "142px";
organized.style.width = "68px";
organized.style.height = "22px";
organized.style.fontFamily = "Poppins";
organized.style.fontSize = "10px";
organized.style.overflow = "hidden";
organized.style.color = "#CB5A7A";

page_personality_1_ek1.appendChild(organized);

var rectangle_18 = document.createElement("div");
rectangle_18.id = "rectangle_18";
rectangle_18.style.left = "310px";
rectangle_18.style.top = "133px";
rectangle_18.style.width = "82px";
rectangle_18.style.height = "32px";
rectangle_18.style.borderRadius = "20px";
rectangle_18.style.background = 'rgba(203,90,122,1)';

page_personality_1_ek1.appendChild(rectangle_18);

var energetic = document.createElement("div");
energetic.innerHTML = "Energetic";
energetic.style.textAlign = "left";
energetic.id = "energetic";
energetic.style.left = "327px";
energetic.style.top = "142px";
energetic.style.width = "63px";
energetic.style.height = "22px";
energetic.style.fontFamily = "Poppins";
energetic.style.fontSize = "10px";
energetic.style.overflow = "hidden";
energetic.style.color = "#FFFFFF";

page_personality_1_ek1.appendChild(energetic);

var laid_back = document.createElement("div");
laid_back.innerHTML = "Laid back";
laid_back.style.textAlign = "left";
laid_back.id = "laid_back";
laid_back.style.left = "329px";
laid_back.style.top = "247px";
laid_back.style.width = "64px";
laid_back.style.height = "22px";
laid_back.style.fontFamily = "Poppins";
laid_back.style.fontSize = "10px";
laid_back.style.overflow = "hidden";
laid_back.style.color = "#F9FDFF";

page_personality_1_ek1.appendChild(laid_back);

var night_out = document.createElement("div");
night_out.innerHTML = "Night out";
night_out.style.textAlign = "left";
night_out.id = "night_out";
night_out.style.left = "136px";
night_out.style.top = "301px";
night_out.style.width = "62px";
night_out.style.height = "22px";
night_out.style.fontFamily = "Poppins";
night_out.style.fontSize = "10px";
night_out.style.overflow = "hidden";
night_out.style.color = "#CB5A7A";

page_personality_1_ek1.appendChild(night_out);

var rectangle_29 = document.createElement("div");
rectangle_29.id = "rectangle_29";
rectangle_29.style.left = "214px";
rectangle_29.style.top = "292px";
rectangle_29.style.width = "84px";
rectangle_29.style.height = "34px";
rectangle_29.style.borderRadius = "20px";
rectangle_29.style.border = "1px solid #cb5a7a";
rectangle_29.style.background = 'rgba(255,255,255,0)';

page_personality_1_ek1.appendChild(rectangle_29);

var easygoing = document.createElement("div");
easygoing.innerHTML = "Easygoing";
easygoing.style.textAlign = "left";
easygoing.id = "easygoing";
easygoing.style.left = "222px";
easygoing.style.top = "298px";
easygoing.style.width = "85.5px";
easygoing.style.height = "29.5px";
easygoing.style.fontFamily = "Poppins";
easygoing.style.fontSize = "13px";
easygoing.style.overflow = "hidden";
easygoing.style.color = "#CB5A7A";

page_personality_1_ek1.appendChild(easygoing);

var next = document.createElement("div");
next.innerHTML = "Next";
next.style.fontWeight = "bold";
next.style.textAlign = "center";
next.id = "next";
next.style.left = "361px";
next.style.top = "732px";
next.style.width = "57px";
next.style.height = "40px";
next.style.fontFamily = "Poppins";
next.style.fontSize = "18px";
next.style.overflow = "hidden";
next.style.color = "#000000";

page_personality_1_ek1.appendChild(next);














