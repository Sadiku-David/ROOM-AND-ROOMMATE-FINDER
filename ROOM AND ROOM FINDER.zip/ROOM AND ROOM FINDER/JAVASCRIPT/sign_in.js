/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);














var page_sign_in_ek2 = document.createElement("div");
page_sign_in_ek2.id = "page_sign_in_ek2";
page_sign_in_ek2.style.width = "414px";
page_sign_in_ek2.style.height = "826px";
page_sign_in_ek2.style.left = "0px";
page_sign_in_ek2.style.top = "0px";
page_sign_in_ek2.style.position = "absolute";
content_container.appendChild(page_sign_in_ek2);

var _bg__sign_in_ek3 = document.createElement("div");
_bg__sign_in_ek3.id = "_bg__sign_in_ek3";
_bg__sign_in_ek3.style.left = "0px";
_bg__sign_in_ek3.style.top = "0px";
_bg__sign_in_ek3.style.width = "414px";
_bg__sign_in_ek3.style.height = "826px";
_bg__sign_in_ek3.style.background = 'rgba(234.81,234.81,234.81,1)';

page_sign_in_ek2.appendChild(_bg__sign_in_ek3);

var _rectangle_1_ek4 = document.createElement("div");
_rectangle_1_ek4.id = "_rectangle_1_ek4";
_rectangle_1_ek4.style.left = "88px";
_rectangle_1_ek4.style.top = "531px";
_rectangle_1_ek4.style.width = "225px";
_rectangle_1_ek4.style.height = "52px";
_rectangle_1_ek4.style.borderRadius = "20px";
_rectangle_1_ek4.style.background = 'rgba(203,90,122,1)';

page_sign_in_ek2.appendChild(_rectangle_1_ek4);

_rectangle_1_ek4.style.cursor = "pointer";
_rectangle_1_ek4.onclick = (e) => {
	@page_view("home");
}

var rommie = document.createElement("div");
rommie.innerHTML = "ROMMIE";
rommie.style.textAlign = "center";
rommie.id = "rommie";
rommie.style.left = "117px";
rommie.style.top = "99px";
rommie.style.width = "191px";
rommie.style.height = "81px";
rommie.style.fontFamily = "Level 01";
rommie.style.fontSize = "48px";
rommie.style.overflow = "hidden";
rommie.style.color = "#000000";

page_sign_in_ek2.appendChild(rommie);

var welcome = document.createElement("div");
welcome.innerHTML = "Welcome";
welcome.style.textAlign = "center";
welcome.id = "welcome";
welcome.style.left = "93px";
welcome.style.top = "195px";
welcome.style.width = "232px";
welcome.style.height = "123px";
welcome.style.fontFamily = "Morning Signature";
welcome.style.fontSize = "70px";
welcome.style.overflow = "hidden";
welcome.style.color = "#CB5A7A";

page_sign_in_ek2.appendChild(welcome);

var email_ek1 = document.createElement("div");
email_ek1.innerHTML = "Email";
email_ek1.style.textAlign = "center";
email_ek1.id = "email_ek1";
email_ek1.style.left = "37px";
email_ek1.style.top = "292px";
email_ek1.style.width = "51px";
email_ek1.style.height = "31px";
email_ek1.style.fontFamily = "Poppins";
email_ek1.style.fontSize = "14px";
email_ek1.style.overflow = "hidden";
email_ek1.style.color = "#000000";

page_sign_in_ek2.appendChild(email_ek1);

var password_ek1 = document.createElement("div");
password_ek1.innerHTML = "Password";
password_ek1.style.textAlign = "center";
password_ek1.id = "password_ek1";
password_ek1.style.left = "37px";
password_ek1.style.top = "393px";
password_ek1.style.width = "81px";
password_ek1.style.height = "31px";
password_ek1.style.fontFamily = "Poppins";
password_ek1.style.fontSize = "14px";
password_ek1.style.overflow = "hidden";
password_ek1.style.color = "#000000";

page_sign_in_ek2.appendChild(password_ek1);

var welcome_ek1 = document.createElement("div");
welcome_ek1.innerHTML = "Welcome";
welcome_ek1.style.textAlign = "center";
welcome_ek1.id = "welcome_ek1";
welcome_ek1.style.left = "45px";
welcome_ek1.style.top = "195px";
welcome_ek1.style.width = "232px";
welcome_ek1.style.height = "123px";
welcome_ek1.style.fontFamily = "Morning Signature";
welcome_ek1.style.fontSize = "70px";
welcome_ek1.style.overflow = "hidden";
welcome_ek1.style.color = "#CB5A7A";

page_sign_in_ek2.appendChild(welcome_ek1);

var line_1_ek1 = document.createElement("div");
line_1_ek1.id = "line_1_ek1";
line_1_ek1.style.left = "39px";
line_1_ek1.style.top = "357px";
line_1_ek1.style.width = "333px";
line_1_ek1.style.height = "1px";
line_1_ek1.style.background = "#000000";

page_sign_in_ek2.appendChild(line_1_ek1);

var line_2_ek1 = document.createElement("div");
line_2_ek1.id = "line_2_ek1";
line_2_ek1.style.left = "39px";
line_2_ek1.style.top = "457px";
line_2_ek1.style.width = "333px";
line_2_ek1.style.height = "1px";
line_2_ek1.style.background = "#000000";

page_sign_in_ek2.appendChild(line_2_ek1);

var ____ek1 = document.createElement("img");
____ek1.id = "____ek1";
____ek1.style.left = "354px";
____ek1.style.top = "424px";
____ek1.style.width = "18px";
____ek1.style.height = "12px";
____ek1.src = "skins/____ek1.png";

page_sign_in_ek2.appendChild(____ek1);

var forgot_password_ = document.createElement("div");
forgot_password_.innerHTML = "Forgot Password?";
forgot_password_.style.textAlign = "center";
forgot_password_.id = "forgot_password_";
forgot_password_.style.left = "253px";
forgot_password_.style.top = "475px";
forgot_password_.style.width = "136px";
forgot_password_.style.height = "31px";
forgot_password_.style.fontFamily = "Poppins";
forgot_password_.style.fontSize = "14px";
forgot_password_.style.overflow = "hidden";
forgot_password_.style.color = "#000000";

page_sign_in_ek2.appendChild(forgot_password_);

var log_in = document.createElement("div");
log_in.innerHTML = "Log In";
log_in.style.fontWeight = "bold";
log_in.style.textAlign = "left";
log_in.id = "log_in";
log_in.style.left = "180px";
log_in.style.top = "544px";
log_in.style.width = "77px";
log_in.style.height = "40px";
log_in.style.fontFamily = "Poppins";
log_in.style.fontSize = "18px";
log_in.style.overflow = "hidden";
log_in.style.color = "#FFFFFF";

page_sign_in_ek2.appendChild(log_in);

var don_t_have_an_account_yet_ = document.createElement("div");
don_t_have_an_account_yet_.innerHTML = "Don\'t have an account yet? ";
don_t_have_an_account_yet_.style.textAlign = "left";
don_t_have_an_account_yet_.id = "don_t_have_an_account_yet_";
don_t_have_an_account_yet_.style.left = "83px";
don_t_have_an_account_yet_.style.top = "745px";
don_t_have_an_account_yet_.style.width = "211px";
don_t_have_an_account_yet_.style.height = "31px";
don_t_have_an_account_yet_.style.fontFamily = "Poppins";
don_t_have_an_account_yet_.style.fontSize = "14px";
don_t_have_an_account_yet_.style.overflow = "hidden";
don_t_have_an_account_yet_.style.color = "#000000";

page_sign_in_ek2.appendChild(don_t_have_an_account_yet_);

var _sign_up_ek6 = document.createElement("div");
_sign_up_ek6.innerHTML = "Sign up";
_sign_up_ek6.style.textAlign = "left";
_sign_up_ek6.id = "_sign_up_ek6";
_sign_up_ek6.style.left = "279px";
_sign_up_ek6.style.top = "745px";
_sign_up_ek6.style.width = "72px";
_sign_up_ek6.style.height = "31px";
_sign_up_ek6.style.fontFamily = "Poppins";
_sign_up_ek6.style.fontSize = "14px";
_sign_up_ek6.style.overflow = "hidden";
_sign_up_ek6.style.color = "#CB5A7A";

page_sign_in_ek2.appendChild(_sign_up_ek6);

_sign_up_ek6.style.cursor = "pointer";
_sign_up_ek6.onclick = (e) => {
	@page_view("sign_up");
}

var line_3_ek1 = document.createElement("div");
line_3_ek1.id = "line_3_ek1";
line_3_ek1.style.left = "0px";
line_3_ek1.style.top = "625px";
line_3_ek1.style.width = "135px";
line_3_ek1.style.height = "1px";
line_3_ek1.style.background = "#000000";

page_sign_in_ek2.appendChild(line_3_ek1);

var line_4 = document.createElement("div");
line_4.id = "line_4";
line_4.style.left = "279px";
line_4.style.top = "625px";
line_4.style.width = "135px";
line_4.style.height = "1px";
line_4.style.background = "#000000";

page_sign_in_ek2.appendChild(line_4);

var or_continue_with = document.createElement("div");
or_continue_with.innerHTML = "Or  continue  with";
or_continue_with.style.textAlign = "left";
or_continue_with.id = "or_continue_with";
or_continue_with.style.left = "145px";
or_continue_with.style.top = "615px";
or_continue_with.style.width = "141px";
or_continue_with.style.height = "31px";
or_continue_with.style.fontFamily = "Poppins";
or_continue_with.style.fontSize = "14px";
or_continue_with.style.overflow = "hidden";
or_continue_with.style.color = "#000000";

page_sign_in_ek2.appendChild(or_continue_with);

var google = document.createElement("img");
google.id = "google";
google.style.left = "135px";
google.style.top = "683px";
google.style.width = "44px";
google.style.height = "44px";
google.src = "skins/google.png";

page_sign_in_ek2.appendChild(google);

var facebook = document.createElement("img");
facebook.id = "facebook";
facebook.style.left = "218px";
facebook.style.top = "683px";
facebook.style.width = "44px";
facebook.style.height = "44px";
facebook.src = "skins/facebook.png";

page_sign_in_ek2.appendChild(facebook);

var status_bar_ek7 = document.createElement("div");
status_bar_ek7.id = "status_bar_ek7";
status_bar_ek7.style.width = "387px";
status_bar_ek7.style.height = "18px";
status_bar_ek7.style.left = "18px";
status_bar_ek7.style.top = "6px";
status_bar_ek7.style.position = "absolute";
page_sign_in_ek2.appendChild(status_bar_ek7);

var wifi_ek10 = document.createElement("img");
wifi_ek10.id = "wifi_ek10";
wifi_ek10.style.left = "294px";
wifi_ek10.style.top = "5px";
wifi_ek10.style.width = "14.94px";
wifi_ek10.style.height = "10px";
wifi_ek10.src = "skins/wifi_ek10.png";

status_bar_ek7.appendChild(wifi_ek10);

var time_ek7 = document.createElement("div");
time_ek7.innerHTML = "9:41 AM";
time_ek7.style.textAlign = "center";
time_ek7.id = "time_ek7";
time_ek7.style.left = "-2px";
time_ek7.style.top = "0px";
time_ek7.style.width = "62px";
time_ek7.style.height = "26px";
time_ek7.style.fontFamily = "Poppins";
time_ek7.style.fontSize = "12px";
time_ek7.style.overflow = "hidden";
time_ek7.style.color = "#030303";

status_bar_ek7.appendChild(time_ek7);

var battery_ek7 = document.createElement("div");
battery_ek7.id = "battery_ek7";
battery_ek7.style.width = "27.61px";
battery_ek7.style.height = "11.5px";
battery_ek7.style.left = "359px";
battery_ek7.style.top = "5px";
battery_ek7.style.position = "absolute";
status_bar_ek7.appendChild(battery_ek7);

var border_ek7 = document.createElement("img");
border_ek7.id = "border_ek7";
border_ek7.style.left = "0px";
border_ek7.style.opacity = "0.40000000596046";
border_ek7.style.filter = "alpha(opacity='40.000000596046')";
border_ek7.style.top = "0px";
border_ek7.style.width = "25px";
border_ek7.style.height = "11.5px";
border_ek7.src = "skins/border_ek7.png";

battery_ek7.appendChild(border_ek7);

var nub_ek7 = document.createElement("img");
nub_ek7.id = "nub_ek7";
nub_ek7.style.left = "26px";
nub_ek7.style.opacity = "0.40000000596046";
nub_ek7.style.filter = "alpha(opacity='40.000000596046')";
nub_ek7.style.top = "4px";
nub_ek7.style.width = "1.56px";
nub_ek7.style.height = "3.87px";
nub_ek7.src = "skins/nub_ek7.png";

battery_ek7.appendChild(nub_ek7);

var charge_ek7 = document.createElement("img");
charge_ek7.id = "charge_ek7";
charge_ek7.style.left = "2px";
charge_ek7.style.top = "2px";
charge_ek7.style.width = "20.83px";
charge_ek7.style.height = "7.5px";
charge_ek7.src = "skins/charge_ek7.png";

battery_ek7.appendChild(charge_ek7);

var mobile_signal_ek7 = document.createElement("img");
mobile_signal_ek7.id = "mobile_signal_ek7";
mobile_signal_ek7.style.left = "325px";
mobile_signal_ek7.style.top = "4px";
mobile_signal_ek7.style.width = "17.19px";
mobile_signal_ek7.style.height = "10px";
mobile_signal_ek7.src = "skins/mobile_signal_ek7.png";

status_bar_ek7.appendChild(mobile_signal_ek7);


