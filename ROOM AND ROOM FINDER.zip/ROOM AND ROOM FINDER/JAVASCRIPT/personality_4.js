/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);


var page_personality_4_ek1 = document.createElement("div");
page_personality_4_ek1.id = "page_personality_4_ek1";
page_personality_4_ek1.style.width = "428px";
page_personality_4_ek1.style.height = "826px";
page_personality_4_ek1.style.left = "0px";
page_personality_4_ek1.style.top = "0px";
page_personality_4_ek1.style.position = "absolute";
content_container.appendChild(page_personality_4_ek1);

var _bg__personality_4_ek2 = document.createElement("div");
_bg__personality_4_ek2.id = "_bg__personality_4_ek2";
_bg__personality_4_ek2.style.left = "0px";
_bg__personality_4_ek2.style.top = "0px";
_bg__personality_4_ek2.style.width = "428px";
_bg__personality_4_ek2.style.height = "826px";
_bg__personality_4_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_personality_4_ek1.appendChild(_bg__personality_4_ek2);

var rectangle_13_ek3 = document.createElement("div");
rectangle_13_ek3.id = "rectangle_13_ek3";
rectangle_13_ek3.style.left = "22px";
rectangle_13_ek3.style.top = "43px";
rectangle_13_ek3.style.width = "385px";
rectangle_13_ek3.style.height = "7px";
rectangle_13_ek3.style.borderRadius = "7px";
rectangle_13_ek3.style.background = 'rgba(205.2,205.2,205.2,1)';

page_personality_4_ek1.appendChild(rectangle_13_ek3);

var rectangle_14_ek3 = document.createElement("div");
rectangle_14_ek3.id = "rectangle_14_ek3";
rectangle_14_ek3.style.left = "22px";
rectangle_14_ek3.style.top = "43px";
rectangle_14_ek3.style.width = "385px";
rectangle_14_ek3.style.height = "7px";
rectangle_14_ek3.style.borderRadius = "7px";
rectangle_14_ek3.style.background = 'rgba(203,90,122,1)';

page_personality_4_ek1.appendChild(rectangle_14_ek3);

var steps_4_4_personality = document.createElement("div");
steps_4_4_personality.innerHTML = "Steps 4/4 Personality";
steps_4_4_personality.style.textAlign = "left";
steps_4_4_personality.id = "steps_4_4_personality";
steps_4_4_personality.style.left = "22px";
steps_4_4_personality.style.top = "22px";
steps_4_4_personality.style.width = "167px";
steps_4_4_personality.style.height = "31px";
steps_4_4_personality.style.fontFamily = "Poppins";
steps_4_4_personality.style.fontSize = "14px";
steps_4_4_personality.style.overflow = "hidden";
steps_4_4_personality.style.color = "#000000";

page_personality_4_ek1.appendChild(steps_4_4_personality);

var how_ofthen_can_someone_visit_ = document.createElement("div");
how_ofthen_can_someone_visit_.innerHTML = "How ofthen can someone visit?";
how_ofthen_can_someone_visit_.style.fontWeight = "bold";
how_ofthen_can_someone_visit_.style.textAlign = "left";
how_ofthen_can_someone_visit_.id = "how_ofthen_can_someone_visit_";
how_ofthen_can_someone_visit_.style.left = "30px";
how_ofthen_can_someone_visit_.style.top = "75px";
how_ofthen_can_someone_visit_.style.width = "257.5px";
how_ofthen_can_someone_visit_.style.height = "33.5px";
how_ofthen_can_someone_visit_.style.fontFamily = "Poppins";
how_ofthen_can_someone_visit_.style.fontSize = "15px";
how_ofthen_can_someone_visit_.style.overflow = "hidden";
how_ofthen_can_someone_visit_.style.color = "#000000";

page_personality_4_ek1.appendChild(how_ofthen_can_someone_visit_);

var religion = document.createElement("div");
religion.innerHTML = "Religion";
religion.style.fontWeight = "bold";
religion.style.textAlign = "left";
religion.id = "religion";
religion.style.left = "32px";
religion.style.top = "311px";
religion.style.width = "82.5px";
religion.style.height = "33.5px";
religion.style.fontFamily = "Poppins";
religion.style.fontSize = "15px";
religion.style.overflow = "hidden";
religion.style.color = "#000000";

page_personality_4_ek1.appendChild(religion);

var rectangle_51 = document.createElement("div");
rectangle_51.id = "rectangle_51";
rectangle_51.style.left = "31px";
rectangle_51.style.top = "105px";
rectangle_51.style.width = "378px";
rectangle_51.style.height = "192px";
rectangle_51.style.borderRadius = "5px";
rectangle_51.style.border = "1px solid #000000";
rectangle_51.style.background = 'rgba(255,255,255,0)';

page_personality_4_ek1.appendChild(rectangle_51);

var rectangle_53 = document.createElement("div");
rectangle_53.id = "rectangle_53";
rectangle_53.style.left = "33px";
rectangle_53.style.top = "341px";
rectangle_53.style.width = "378px";
rectangle_53.style.height = "89px";
rectangle_53.style.borderRadius = "5px";
rectangle_53.style.border = "1px solid #000000";
rectangle_53.style.background = 'rgba(255,255,255,0)';

page_personality_4_ek1.appendChild(rectangle_53);

var radio_off_single_line = document.createElement("div");
radio_off_single_line.id = "radio_off_single_line";
radio_off_single_line.style.width = "220px";
radio_off_single_line.style.height = "48px";
radio_off_single_line.style.left = "32px";
radio_off_single_line.style.top = "144px";
radio_off_single_line.style.position = "absolute";
page_personality_4_ek1.appendChild(radio_off_single_line);

var selector__single = document.createElement("div");
selector__single.id = "selector__single";
selector__single.style.width = "220px";
selector__single.style.height = "48px";
selector__single.style.left = "0px";
selector__single.style.top = "0px";
selector__single.style.position = "absolute";
radio_off_single_line.appendChild(selector__single);

var radio_off = document.createElement("div");
radio_off.id = "radio_off";
radio_off.style.width = "40px";
radio_off.style.height = "40px";
radio_off.style.left = "8px";
radio_off.style.top = "4px";
radio_off.style.position = "absolute";
selector__single.appendChild(radio_off);

var misc___icons_background = document.createElement("div");
misc___icons_background.id = "misc___icons_background";
misc___icons_background.style.width = "40px";
misc___icons_background.style.height = "40px";
misc___icons_background.style.left = "0px";
misc___icons_background.style.top = "0px";
misc___icons_background.style.position = "absolute";
radio_off.appendChild(misc___icons_background);

var shape = document.createElement("img");
shape.id = "shape";
shape.style.left = "10px";
shape.style.top = "10px";
shape.style.width = "20px";
shape.style.height = "20px";
shape.src = "skins/shape.png";

radio_off.appendChild(shape);

var value = document.createElement("div");
value.innerHTML = "Twice a month";
value.style.textAlign = "left";
value.id = "value";
value.style.left = "72px";
value.style.top = "14px";
value.style.width = "161px";
value.style.height = "31px";
value.style.fontFamily = "Inter";
value.style.fontSize = "16px";
value.style.lineHeight = "24px";
value.style.overflow = "hidden";
value.style.color = "#263238";

selector__single.appendChild(value);

var radio_off_single_line_ek1 = document.createElement("div");
radio_off_single_line_ek1.id = "radio_off_single_line_ek1";
radio_off_single_line_ek1.style.width = "220px";
radio_off_single_line_ek1.style.height = "48px";
radio_off_single_line_ek1.style.left = "34px";
radio_off_single_line_ek1.style.top = "380px";
radio_off_single_line_ek1.style.position = "absolute";
page_personality_4_ek1.appendChild(radio_off_single_line_ek1);

var selector__single_ek1 = document.createElement("div");
selector__single_ek1.id = "selector__single_ek1";
selector__single_ek1.style.width = "220px";
selector__single_ek1.style.height = "48px";
selector__single_ek1.style.left = "0px";
selector__single_ek1.style.top = "0px";
selector__single_ek1.style.position = "absolute";
radio_off_single_line_ek1.appendChild(selector__single_ek1);

var radio_off_ek1 = document.createElement("div");
radio_off_ek1.id = "radio_off_ek1";
radio_off_ek1.style.width = "40px";
radio_off_ek1.style.height = "40px";
radio_off_ek1.style.left = "8px";
radio_off_ek1.style.top = "4px";
radio_off_ek1.style.position = "absolute";
selector__single_ek1.appendChild(radio_off_ek1);

var misc___icons_background_ek1 = document.createElement("div");
misc___icons_background_ek1.id = "misc___icons_background_ek1";
misc___icons_background_ek1.style.width = "40px";
misc___icons_background_ek1.style.height = "40px";
misc___icons_background_ek1.style.left = "0px";
misc___icons_background_ek1.style.top = "0px";
misc___icons_background_ek1.style.position = "absolute";
radio_off_ek1.appendChild(misc___icons_background_ek1);

var shape_ek1 = document.createElement("img");
shape_ek1.id = "shape_ek1";
shape_ek1.style.left = "10px";
shape_ek1.style.top = "10px";
shape_ek1.style.width = "20px";
shape_ek1.style.height = "20px";
shape_ek1.src = "skins/shape_ek1.png";

radio_off_ek1.appendChild(shape_ek1);

var value_ek1 = document.createElement("div");
value_ek1.innerHTML = "Moslim";
value_ek1.style.textAlign = "left";
value_ek1.id = "value_ek1";
value_ek1.style.left = "72px";
value_ek1.style.top = "14px";
value_ek1.style.width = "161px";
value_ek1.style.height = "31px";
value_ek1.style.fontFamily = "Inter";
value_ek1.style.fontSize = "16px";
value_ek1.style.lineHeight = "24px";
value_ek1.style.overflow = "hidden";
value_ek1.style.color = "#263238";

selector__single_ek1.appendChild(value_ek1);

var radio_off_single_line_ek2 = document.createElement("div");
radio_off_single_line_ek2.id = "radio_off_single_line_ek2";
radio_off_single_line_ek2.style.width = "220px";
radio_off_single_line_ek2.style.height = "48px";
radio_off_single_line_ek2.style.left = "32px";
radio_off_single_line_ek2.style.top = "227px";
radio_off_single_line_ek2.style.position = "absolute";
page_personality_4_ek1.appendChild(radio_off_single_line_ek2);

var selector__single_ek2 = document.createElement("div");
selector__single_ek2.id = "selector__single_ek2";
selector__single_ek2.style.width = "220px";
selector__single_ek2.style.height = "48px";
selector__single_ek2.style.left = "0px";
selector__single_ek2.style.top = "0px";
selector__single_ek2.style.position = "absolute";
radio_off_single_line_ek2.appendChild(selector__single_ek2);

var radio_off_ek2 = document.createElement("div");
radio_off_ek2.id = "radio_off_ek2";
radio_off_ek2.style.width = "40px";
radio_off_ek2.style.height = "40px";
radio_off_ek2.style.left = "8px";
radio_off_ek2.style.top = "4px";
radio_off_ek2.style.position = "absolute";
selector__single_ek2.appendChild(radio_off_ek2);

var misc___icons_background_ek2 = document.createElement("div");
misc___icons_background_ek2.id = "misc___icons_background_ek2";
misc___icons_background_ek2.style.width = "40px";
misc___icons_background_ek2.style.height = "40px";
misc___icons_background_ek2.style.left = "0px";
misc___icons_background_ek2.style.top = "0px";
misc___icons_background_ek2.style.position = "absolute";
radio_off_ek2.appendChild(misc___icons_background_ek2);

var shape_ek2 = document.createElement("img");
shape_ek2.id = "shape_ek2";
shape_ek2.style.left = "10px";
shape_ek2.style.top = "10px";
shape_ek2.style.width = "20px";
shape_ek2.style.height = "20px";
shape_ek2.src = "skins/shape_ek2.png";

radio_off_ek2.appendChild(shape_ek2);

var value_ek2 = document.createElement("div");
value_ek2.innerHTML = "Doesn\'t matter";
value_ek2.style.textAlign = "left";
value_ek2.id = "value_ek2";
value_ek2.style.left = "72px";
value_ek2.style.top = "14px";
value_ek2.style.width = "161px";
value_ek2.style.height = "31px";
value_ek2.style.fontFamily = "Inter";
value_ek2.style.fontSize = "16px";
value_ek2.style.lineHeight = "24px";
value_ek2.style.overflow = "hidden";
value_ek2.style.color = "#263238";

selector__single_ek2.appendChild(value_ek2);

var radio_off_single_line_ek3 = document.createElement("div");
radio_off_single_line_ek3.id = "radio_off_single_line_ek3";
radio_off_single_line_ek3.style.width = "220px";
radio_off_single_line_ek3.style.height = "48px";
radio_off_single_line_ek3.style.left = "70px";
radio_off_single_line_ek3.style.top = "527px";
radio_off_single_line_ek3.style.position = "absolute";
page_personality_4_ek1.appendChild(radio_off_single_line_ek3);

var selector__single_ek3 = document.createElement("div");
selector__single_ek3.id = "selector__single_ek3";
selector__single_ek3.style.width = "220px";
selector__single_ek3.style.height = "48px";
selector__single_ek3.style.left = "0px";
selector__single_ek3.style.top = "0px";
selector__single_ek3.style.position = "absolute";
radio_off_single_line_ek3.appendChild(selector__single_ek3);

var radio_off_ek3 = document.createElement("div");
radio_off_ek3.id = "radio_off_ek3";
radio_off_ek3.style.width = "40px";
radio_off_ek3.style.height = "40px";
radio_off_ek3.style.left = "8px";
radio_off_ek3.style.top = "4px";
radio_off_ek3.style.position = "absolute";
selector__single_ek3.appendChild(radio_off_ek3);

var misc___icons_background_ek3 = document.createElement("div");
misc___icons_background_ek3.id = "misc___icons_background_ek3";
misc___icons_background_ek3.style.width = "40px";
misc___icons_background_ek3.style.height = "40px";
misc___icons_background_ek3.style.left = "0px";
misc___icons_background_ek3.style.top = "0px";
misc___icons_background_ek3.style.position = "absolute";
radio_off_ek3.appendChild(misc___icons_background_ek3);

var shape_ek3 = document.createElement("img");
shape_ek3.id = "shape_ek3";
shape_ek3.style.left = "10px";
shape_ek3.style.top = "10px";
shape_ek3.style.width = "20px";
shape_ek3.style.height = "20px";
shape_ek3.src = "skins/shape_ek3.png";

radio_off_ek3.appendChild(shape_ek3);

var value_ek3 = document.createElement("div");
value_ek3.innerHTML = "Oberon";
value_ek3.style.textAlign = "left";
value_ek3.id = "value_ek3";
value_ek3.style.left = "72px";
value_ek3.style.top = "14px";
value_ek3.style.width = "161px";
value_ek3.style.height = "31px";
value_ek3.style.fontFamily = "Inter";
value_ek3.style.fontSize = "16px";
value_ek3.style.lineHeight = "24px";
value_ek3.style.overflow = "hidden";
value_ek3.style.color = "#263238";

selector__single_ek3.appendChild(value_ek3);

var radio_single_off = document.createElement("div");
radio_single_off.id = "radio_single_off";
radio_single_off.style.width = "220px";
radio_single_off.style.height = "48px";
radio_single_off.style.left = "32px";
radio_single_off.style.top = "105px";
radio_single_off.style.position = "absolute";
page_personality_4_ek1.appendChild(radio_single_off);

var selector__single_ek4 = document.createElement("div");
selector__single_ek4.id = "selector__single_ek4";
selector__single_ek4.style.width = "220px";
selector__single_ek4.style.height = "48px";
selector__single_ek4.style.left = "0px";
selector__single_ek4.style.top = "0px";
selector__single_ek4.style.position = "absolute";
radio_single_off.appendChild(selector__single_ek4);

var radio_off_ek4 = document.createElement("div");
radio_off_ek4.id = "radio_off_ek4";
radio_off_ek4.style.width = "40px";
radio_off_ek4.style.height = "40px";
radio_off_ek4.style.left = "8px";
radio_off_ek4.style.top = "4px";
radio_off_ek4.style.position = "absolute";
selector__single_ek4.appendChild(radio_off_ek4);

var misc___icons_background_ek4 = document.createElement("div");
misc___icons_background_ek4.id = "misc___icons_background_ek4";
misc___icons_background_ek4.style.width = "40px";
misc___icons_background_ek4.style.height = "40px";
misc___icons_background_ek4.style.left = "0px";
misc___icons_background_ek4.style.top = "0px";
misc___icons_background_ek4.style.position = "absolute";
radio_off_ek4.appendChild(misc___icons_background_ek4);

var shape_ek4 = document.createElement("img");
shape_ek4.id = "shape_ek4";
shape_ek4.style.left = "10px";
shape_ek4.style.top = "10px";
shape_ek4.style.width = "20px";
shape_ek4.style.height = "20px";
shape_ek4.src = "skins/shape_ek4.png";

radio_off_ek4.appendChild(shape_ek4);

var value_ek4 = document.createElement("div");
value_ek4.innerHTML = "No guest please!";
value_ek4.style.textAlign = "left";
value_ek4.id = "value_ek4";
value_ek4.style.left = "72px";
value_ek4.style.top = "14px";
value_ek4.style.width = "161px";
value_ek4.style.height = "31px";
value_ek4.style.fontFamily = "Inter";
value_ek4.style.fontSize = "16px";
value_ek4.style.lineHeight = "24px";
value_ek4.style.overflow = "hidden";
value_ek4.style.color = "#263238";

selector__single_ek4.appendChild(value_ek4);

var radio_single_off_ek1 = document.createElement("div");
radio_single_off_ek1.id = "radio_single_off_ek1";
radio_single_off_ek1.style.width = "220px";
radio_single_off_ek1.style.height = "48px";
radio_single_off_ek1.style.left = "34px";
radio_single_off_ek1.style.top = "341px";
radio_single_off_ek1.style.position = "absolute";
page_personality_4_ek1.appendChild(radio_single_off_ek1);

var selector__single_ek5 = document.createElement("div");
selector__single_ek5.id = "selector__single_ek5";
selector__single_ek5.style.width = "220px";
selector__single_ek5.style.height = "48px";
selector__single_ek5.style.left = "0px";
selector__single_ek5.style.top = "0px";
selector__single_ek5.style.position = "absolute";
radio_single_off_ek1.appendChild(selector__single_ek5);

var radio_off_ek5 = document.createElement("div");
radio_off_ek5.id = "radio_off_ek5";
radio_off_ek5.style.width = "40px";
radio_off_ek5.style.height = "40px";
radio_off_ek5.style.left = "8px";
radio_off_ek5.style.top = "4px";
radio_off_ek5.style.position = "absolute";
selector__single_ek5.appendChild(radio_off_ek5);

var misc___icons_background_ek5 = document.createElement("div");
misc___icons_background_ek5.id = "misc___icons_background_ek5";
misc___icons_background_ek5.style.width = "40px";
misc___icons_background_ek5.style.height = "40px";
misc___icons_background_ek5.style.left = "0px";
misc___icons_background_ek5.style.top = "0px";
misc___icons_background_ek5.style.position = "absolute";
radio_off_ek5.appendChild(misc___icons_background_ek5);

var shape_ek5 = document.createElement("img");
shape_ek5.id = "shape_ek5";
shape_ek5.style.left = "10px";
shape_ek5.style.top = "10px";
shape_ek5.style.width = "20px";
shape_ek5.style.height = "20px";
shape_ek5.src = "skins/shape_ek5.png";

radio_off_ek5.appendChild(shape_ek5);

var value_ek5 = document.createElement("div");
value_ek5.innerHTML = "Christain";
value_ek5.style.textAlign = "left";
value_ek5.id = "value_ek5";
value_ek5.style.left = "72px";
value_ek5.style.top = "14px";
value_ek5.style.width = "161px";
value_ek5.style.height = "31px";
value_ek5.style.fontFamily = "Inter";
value_ek5.style.fontSize = "16px";
value_ek5.style.lineHeight = "24px";
value_ek5.style.overflow = "hidden";
value_ek5.style.color = "#263238";

selector__single_ek5.appendChild(value_ek5);

var value_ek6 = document.createElement("div");
value_ek6.innerHTML = "Once a Month";
value_ek6.style.fontWeight = "bold";
value_ek6.style.textAlign = "left";
value_ek6.id = "value_ek6";
value_ek6.style.left = "104px";
value_ek6.style.top = "197px";
value_ek6.style.width = "161px";
value_ek6.style.height = "31px";
value_ek6.style.fontFamily = "Inter";
value_ek6.style.fontSize = "16px";
value_ek6.style.lineHeight = "24px";
value_ek6.style.overflow = "hidden";
value_ek6.style.color = "#CB5A7A";

page_personality_4_ek1.appendChild(value_ek6);

var tell_us_about_yourself = document.createElement("div");
tell_us_about_yourself.innerHTML = "Tell us about yourself";
tell_us_about_yourself.style.fontWeight = "bold";
tell_us_about_yourself.style.textAlign = "left";
tell_us_about_yourself.id = "tell_us_about_yourself";
tell_us_about_yourself.style.left = "34px";
tell_us_about_yourself.style.top = "444px";
tell_us_about_yourself.style.width = "183.5px";
tell_us_about_yourself.style.height = "33.5px";
tell_us_about_yourself.style.fontFamily = "Poppins";
tell_us_about_yourself.style.fontSize = "15px";
tell_us_about_yourself.style.overflow = "hidden";
tell_us_about_yourself.style.color = "#000000";

page_personality_4_ek1.appendChild(tell_us_about_yourself);

var complete_your_bio_by_ading_a_little_description_of_yourself = document.createElement("div");
complete_your_bio_by_ading_a_little_description_of_yourself.innerHTML = "Complete your bio by ading a little  description<br/>of yourself";
complete_your_bio_by_ading_a_little_description_of_yourself.style.textAlign = "left";
complete_your_bio_by_ading_a_little_description_of_yourself.id = "complete_your_bio_by_ading_a_little_description_of_yourself";
complete_your_bio_by_ading_a_little_description_of_yourself.style.left = "31px";
complete_your_bio_by_ading_a_little_description_of_yourself.style.top = "467px";
complete_your_bio_by_ading_a_little_description_of_yourself.style.width = "362.5px";
complete_your_bio_by_ading_a_little_description_of_yourself.style.height = "56.5px";
complete_your_bio_by_ading_a_little_description_of_yourself.style.fontFamily = "Poppins";
complete_your_bio_by_ading_a_little_description_of_yourself.style.fontSize = "15px";
complete_your_bio_by_ading_a_little_description_of_yourself.style.overflow = "hidden";
complete_your_bio_by_ading_a_little_description_of_yourself.style.color = "#000000";

page_personality_4_ek1.appendChild(complete_your_bio_by_ading_a_little_description_of_yourself);

var rectangle_52 = document.createElement("div");
rectangle_52.id = "rectangle_52";
rectangle_52.style.left = "34px";
rectangle_52.style.top = "518px";
rectangle_52.style.width = "346px";
rectangle_52.style.height = "196px";
rectangle_52.style.borderRadius = "5px";
rectangle_52.style.border = "1px solid #000000";
rectangle_52.style.background = 'rgba(255,255,255,0)';

page_personality_4_ek1.appendChild(rectangle_52);

var done = document.createElement("div");
done.innerHTML = "Done";
done.style.fontWeight = "bold";
done.style.textAlign = "center";
done.id = "done";
done.style.left = "181px";
done.style.top = "757px";
done.style.width = "56px";
done.style.height = "35px";
done.style.fontFamily = "Poppins";
done.style.fontSize = "16px";
done.style.overflow = "hidden";
done.style.color = "#FFFFFF";

page_personality_4_ek1.appendChild(done);

var ellipse_7 = document.createElement("div");
ellipse_7.id = "ellipse_7";
ellipse_7.style.left = "52px";
ellipse_7.style.top = "200px";
ellipse_7.style.width = "20px";
ellipse_7.style.height = "20px";
ellipse_7.style.borderRadius = "8px / 8px";
ellipse_7.style.border = "2px solid #000000";
ellipse_7.style.background = 'rgba(203,90,122,1)';

page_personality_4_ek1.appendChild(ellipse_7);

var _rectangle_5 = document.createElement("div");
_rectangle_5.id = "_rectangle_5";
_rectangle_5.style.left = "82px";
_rectangle_5.style.top = "751px";
_rectangle_5.style.width = "260px";
_rectangle_5.style.height = "51px";
_rectangle_5.style.borderRadius = "15px";
_rectangle_5.style.background = 'rgba(203,90,122,1)';

page_personality_4_ek1.appendChild(_rectangle_5);

_rectangle_5.style.cursor = "pointer";
_rectangle_5.onclick = (e) => {
	@page_view("home");
}

var done_ek1 = document.createElement("div");
done_ek1.innerHTML = "Done";
done_ek1.style.fontWeight = "bold";
done_ek1.style.textAlign = "center";
done_ek1.id = "done_ek1";
done_ek1.style.left = "183px";
done_ek1.style.top = "763px";
done_ek1.style.width = "62px";
done_ek1.style.height = "40px";
done_ek1.style.fontFamily = "Poppins";
done_ek1.style.fontSize = "18px";
done_ek1.style.overflow = "hidden";
done_ek1.style.color = "#FFFFFF";

page_personality_4_ek1.appendChild(done_ek1);












