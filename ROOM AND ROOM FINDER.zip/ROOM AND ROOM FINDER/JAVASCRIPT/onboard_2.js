/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);






var page_onboard_2_ek1 = document.createElement("div");
page_onboard_2_ek1.id = "page_onboard_2_ek1";
page_onboard_2_ek1.style.width = "428px";
page_onboard_2_ek1.style.height = "826px";
page_onboard_2_ek1.style.left = "0px";
page_onboard_2_ek1.style.top = "0px";
page_onboard_2_ek1.style.position = "absolute";
content_container.appendChild(page_onboard_2_ek1);

var _bg__onboard_2_ek2 = document.createElement("div");
_bg__onboard_2_ek2.id = "_bg__onboard_2_ek2";
_bg__onboard_2_ek2.style.left = "0px";
_bg__onboard_2_ek2.style.top = "0px";
_bg__onboard_2_ek2.style.width = "428px";
_bg__onboard_2_ek2.style.height = "826px";
_bg__onboard_2_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_onboard_2_ek1.appendChild(_bg__onboard_2_ek2);

var connect_each_other = document.createElement("div");
connect_each_other.innerHTML = "CONNECT EACH OTHER";
connect_each_other.style.fontWeight = "bold";
connect_each_other.style.textAlign = "left";
connect_each_other.id = "connect_each_other";
connect_each_other.style.left = "23px";
connect_each_other.style.top = "508px";
connect_each_other.style.width = "482px";
connect_each_other.style.height = "82px";
connect_each_other.style.fontFamily = "Poppins";
connect_each_other.style.fontSize = "34px";
connect_each_other.style.overflow = "hidden";
connect_each_other.style.color = "#000000";

page_onboard_2_ek1.appendChild(connect_each_other);

var communicate_with_people_similar_to_you_and_make_them_your_roomate = document.createElement("div");
communicate_with_people_similar_to_you_and_make_them_your_roomate.innerHTML = "Communicate with people similar to you and<br/>make them your roomate";
communicate_with_people_similar_to_you_and_make_them_your_roomate.style.fontWeight = "bold";
communicate_with_people_similar_to_you_and_make_them_your_roomate.style.textAlign = "center";
communicate_with_people_similar_to_you_and_make_them_your_roomate.id = "communicate_with_people_similar_to_you_and_make_them_your_roomate";
communicate_with_people_similar_to_you_and_make_them_your_roomate.style.left = "50px";
communicate_with_people_similar_to_you_and_make_them_your_roomate.style.top = "566px";
communicate_with_people_similar_to_you_and_make_them_your_roomate.style.width = "336px";
communicate_with_people_similar_to_you_and_make_them_your_roomate.style.height = "52px";
communicate_with_people_similar_to_you_and_make_them_your_roomate.style.fontFamily = "Poppins";
communicate_with_people_similar_to_you_and_make_them_your_roomate.style.fontSize = "14px";
communicate_with_people_similar_to_you_and_make_them_your_roomate.style.overflow = "hidden";
communicate_with_people_similar_to_you_and_make_them_your_roomate.style.color = "#000000";

page_onboard_2_ek1.appendChild(communicate_with_people_similar_to_you_and_make_them_your_roomate);

var _skip = document.createElement("div");
_skip.innerHTML = "SKIP";
_skip.style.fontWeight = "bold";
_skip.style.textAlign = "center";
_skip.id = "_skip";
_skip.style.left = "369px";
_skip.style.top = "50px";
_skip.style.width = "44px";
_skip.style.height = "31px";
_skip.style.fontFamily = "Poppins";
_skip.style.fontSize = "14px";
_skip.style.overflow = "hidden";
_skip.style.color = "#000000";

page_onboard_2_ek1.appendChild(_skip);

_skip.style.cursor = "pointer";
_skip.onclick = (e) => {
	@page_view("sign_in");
}

var _next_ek3 = document.createElement("div");
_next_ek3.innerHTML = "NEXT";
_next_ek3.style.fontWeight = "bold";
_next_ek3.style.textAlign = "center";
_next_ek3.id = "_next_ek3";
_next_ek3.style.left = "356px";
_next_ek3.style.top = "786px";
_next_ek3.style.width = "49px";
_next_ek3.style.height = "31px";
_next_ek3.style.fontFamily = "Poppins";
_next_ek3.style.fontSize = "14px";
_next_ek3.style.overflow = "hidden";
_next_ek3.style.color = "#000000";

page_onboard_2_ek1.appendChild(_next_ek3);

_next_ek3.style.cursor = "pointer";
_next_ek3.onclick = (e) => {
	@page_view("onboard_3_3");
}

var rectangle_1 = document.createElement("div");
rectangle_1.id = "rectangle_1";
rectangle_1.style.left = "201px";
rectangle_1.style.top = "658px";
rectangle_1.style.width = "26px";
rectangle_1.style.height = "12px";
rectangle_1.style.borderRadius = "5px";
rectangle_1.style.background = 'rgba(203,90,122,1)';

page_onboard_2_ek1.appendChild(rectangle_1);

var _rectangle_2 = document.createElement("div");
_rectangle_2.id = "_rectangle_2";
_rectangle_2.style.left = "163px";
_rectangle_2.style.top = "658px";
_rectangle_2.style.width = "14px";
_rectangle_2.style.height = "12px";
_rectangle_2.style.borderRadius = "5px";
_rectangle_2.style.background = 'rgba(217,217,217,1)';

page_onboard_2_ek1.appendChild(_rectangle_2);

_rectangle_2.style.cursor = "pointer";
_rectangle_2.onclick = (e) => {
	@page_view("onboard_1");
}

var _rectangle_3_ek1 = document.createElement("div");
_rectangle_3_ek1.id = "_rectangle_3_ek1";
_rectangle_3_ek1.style.left = "251px";
_rectangle_3_ek1.style.top = "658px";
_rectangle_3_ek1.style.width = "14px";
_rectangle_3_ek1.style.height = "12px";
_rectangle_3_ek1.style.borderRadius = "5px";
_rectangle_3_ek1.style.background = 'rgba(217,217,217,1)';

page_onboard_2_ek1.appendChild(_rectangle_3_ek1);

_rectangle_3_ek1.style.cursor = "pointer";
_rectangle_3_ek1.onclick = (e) => {
	@page_view("onboard_3_3");
}

var three_girlfriends_drink_tea_at_home_and_talk = document.createElement("img");
three_girlfriends_drink_tea_at_home_and_talk.id = "three_girlfriends_drink_tea_at_home_and_talk";
three_girlfriends_drink_tea_at_home_and_talk.style.left = "-56px";
three_girlfriends_drink_tea_at_home_and_talk.style.top = "30px";
three_girlfriends_drink_tea_at_home_and_talk.style.width = "515px";
three_girlfriends_drink_tea_at_home_and_talk.style.height = "515px";
three_girlfriends_drink_tea_at_home_and_talk.src = "skins/three_girlfriends_drink_tea_at_home_and_talk.png";

page_onboard_2_ek1.appendChild(three_girlfriends_drink_tea_at_home_and_talk);

var status_bar = document.createElement("div");
status_bar.id = "status_bar";
status_bar.style.width = "380px";
status_bar.style.height = "18px";
status_bar.style.left = "23px";
status_bar.style.top = "15px";
status_bar.style.position = "absolute";
page_onboard_2_ek1.appendChild(status_bar);

var wifi_ek3 = document.createElement("img");
wifi_ek3.id = "wifi_ek3";
wifi_ek3.style.left = "287px";
wifi_ek3.style.top = "4px";
wifi_ek3.style.width = "14.94px";
wifi_ek3.style.height = "10px";
wifi_ek3.src = "skins/wifi_ek3.png";

status_bar.appendChild(wifi_ek3);

var time = document.createElement("div");
time.innerHTML = "9:41 AM";
time.style.textAlign = "center";
time.id = "time";
time.style.left = "-2px";
time.style.top = "0px";
time.style.width = "62px";
time.style.height = "26px";
time.style.fontFamily = "Poppins";
time.style.fontSize = "12px";
time.style.overflow = "hidden";
time.style.color = "#030303";

status_bar.appendChild(time);

var battery = document.createElement("div");
battery.id = "battery";
battery.style.width = "27.61px";
battery.style.height = "11.5px";
battery.style.left = "352px";
battery.style.top = "4px";
battery.style.position = "absolute";
status_bar.appendChild(battery);

var border = document.createElement("img");
border.id = "border";
border.style.left = "0px";
border.style.opacity = "0.40000000596046";
border.style.filter = "alpha(opacity='40.000000596046')";
border.style.top = "0px";
border.style.width = "25px";
border.style.height = "11.5px";
border.src = "skins/border.png";

battery.appendChild(border);

var nub = document.createElement("img");
nub.id = "nub";
nub.style.left = "26px";
nub.style.opacity = "0.40000000596046";
nub.style.filter = "alpha(opacity='40.000000596046')";
nub.style.top = "4px";
nub.style.width = "1.56px";
nub.style.height = "3.87px";
nub.src = "skins/nub.png";

battery.appendChild(nub);

var charge = document.createElement("img");
charge.id = "charge";
charge.style.left = "2px";
charge.style.top = "2px";
charge.style.width = "20.83px";
charge.style.height = "7.5px";
charge.src = "skins/charge.png";

battery.appendChild(charge);

var mobile_signal = document.createElement("img");
mobile_signal.id = "mobile_signal";
mobile_signal.style.left = "318px";
mobile_signal.style.top = "3px";
mobile_signal.style.width = "17.19px";
mobile_signal.style.height = "10px";
mobile_signal.src = "skins/mobile_signal.png";

status_bar.appendChild(mobile_signal);










