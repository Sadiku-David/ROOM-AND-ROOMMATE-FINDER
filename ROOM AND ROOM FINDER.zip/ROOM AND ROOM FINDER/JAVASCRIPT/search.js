/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);




var page_search_ek1 = document.createElement("div");
page_search_ek1.id = "page_search_ek1";
page_search_ek1.style.width = "428px";
page_search_ek1.style.height = "826px";
page_search_ek1.style.left = "0px";
page_search_ek1.style.top = "0px";
page_search_ek1.style.position = "absolute";
content_container.appendChild(page_search_ek1);

var _bg__search_ek2 = document.createElement("div");
_bg__search_ek2.id = "_bg__search_ek2";
_bg__search_ek2.style.left = "0px";
_bg__search_ek2.style.top = "0px";
_bg__search_ek2.style.width = "428px";
_bg__search_ek2.style.height = "826px";
_bg__search_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_search_ek1.appendChild(_bg__search_ek2);

var rectangle_53_ek1 = document.createElement("div");
rectangle_53_ek1.id = "rectangle_53_ek1";
rectangle_53_ek1.style.left = "0px";
rectangle_53_ek1.style.top = "0px";
rectangle_53_ek1.style.width = "428px";
rectangle_53_ek1.style.height = "89px";
rectangle_53_ek1.style.background = 'rgba(203,90,122,1)';

page_search_ek1.appendChild(rectangle_53_ek1);

var x = document.createElement("div");
x.innerHTML = "X";
x.style.textAlign = "left";
x.id = "x";
x.style.left = "24px";
x.style.top = "36px";
x.style.width = "42px";
x.style.height = "48px";
x.style.fontFamily = "Poppins";
x.style.fontSize = "22px";
x.style.overflow = "hidden";
x.style.color = "#FFFFFF";

page_search_ek1.appendChild(x);

var search_ek3 = document.createElement("div");
search_ek3.innerHTML = "Search";
search_ek3.style.textAlign = "left";
search_ek3.id = "search_ek3";
search_ek3.style.left = "70px";
search_ek3.style.top = "36px";
search_ek3.style.width = "105px";
search_ek3.style.height = "48px";
search_ek3.style.fontFamily = "Poppins";
search_ek3.style.fontSize = "22px";
search_ek3.style.overflow = "hidden";
search_ek3.style.color = "#FFFFFF";

page_search_ek1.appendChild(search_ek3);

var which_list_do_you_want_to_search_ = document.createElement("div");
which_list_do_you_want_to_search_.innerHTML = "Which list do you want <br/>to search?";
which_list_do_you_want_to_search_.style.textAlign = "left";
which_list_do_you_want_to_search_.id = "which_list_do_you_want_to_search_";
which_list_do_you_want_to_search_.style.left = "24px";
which_list_do_you_want_to_search_.style.top = "124px";
which_list_do_you_want_to_search_.style.width = "308px";
which_list_do_you_want_to_search_.style.height = "89px";
which_list_do_you_want_to_search_.style.fontFamily = "Poppins";
which_list_do_you_want_to_search_.style.fontSize = "24px";
which_list_do_you_want_to_search_.style.overflow = "hidden";
which_list_do_you_want_to_search_.style.color = "#000000";

page_search_ek1.appendChild(which_list_do_you_want_to_search_);

var _rectangle_54 = document.createElement("div");
_rectangle_54.id = "_rectangle_54";
_rectangle_54.style.left = "24px";
_rectangle_54.style.top = "207px";
_rectangle_54.style.width = "369px";
_rectangle_54.style.height = "103px";
_rectangle_54.style.borderRadius = "16px";
_rectangle_54.style.background = 'rgba(255,255,255,1)';

page_search_ek1.appendChild(_rectangle_54);

_rectangle_54.style.cursor = "pointer";
_rectangle_54.onclick = (e) => {
	@page_view("room_search");
}

var _rectangle_55 = document.createElement("div");
_rectangle_55.id = "_rectangle_55";
_rectangle_55.style.left = "24px";
_rectangle_55.style.top = "350px";
_rectangle_55.style.width = "369px";
_rectangle_55.style.height = "103px";
_rectangle_55.style.borderRadius = "16px";
_rectangle_55.style.background = 'rgba(255,255,255,1)';

page_search_ek1.appendChild(_rectangle_55);

_rectangle_55.style.cursor = "pointer";
_rectangle_55.onclick = (e) => {
	@page_view("roommate_search");
}

var fluent_bed_24_regular = document.createElement("div");
fluent_bed_24_regular.id = "fluent_bed_24_regular";
fluent_bed_24_regular.style.width = "39px";
fluent_bed_24_regular.style.height = "39px";
fluent_bed_24_regular.style.left = "50px";
fluent_bed_24_regular.style.top = "239px";
fluent_bed_24_regular.style.position = "absolute";
page_search_ek1.appendChild(fluent_bed_24_regular);

var vector = document.createElement("img");
vector.id = "vector";
vector.style.left = "3.25px";
vector.style.top = "6.5px";
vector.style.width = "32.5px";
vector.style.height = "27.63px";
vector.src = "skins/vector.png";

fluent_bed_24_regular.appendChild(vector);

var search_for_rooms = document.createElement("div");
search_for_rooms.innerHTML = "Search for rooms";
search_for_rooms.style.textAlign = "left";
search_for_rooms.id = "search_for_rooms";
search_for_rooms.style.left = "109px";
search_for_rooms.style.top = "246px";
search_for_rooms.style.width = "160px";
search_for_rooms.style.height = "35px";
search_for_rooms.style.fontFamily = "Poppins";
search_for_rooms.style.fontSize = "16px";
search_for_rooms.style.overflow = "hidden";
search_for_rooms.style.color = "#000000";

page_search_ek1.appendChild(search_for_rooms);

var search_for_roommates = document.createElement("div");
search_for_roommates.innerHTML = "Search for roommates";
search_for_roommates.style.textAlign = "left";
search_for_roommates.id = "search_for_roommates";
search_for_roommates.style.left = "109px";
search_for_roommates.style.top = "389px";
search_for_roommates.style.width = "203px";
search_for_roommates.style.height = "35px";
search_for_roommates.style.fontFamily = "Poppins";
search_for_roommates.style.fontSize = "16px";
search_for_roommates.style.overflow = "hidden";
search_for_roommates.style.color = "#000000";

page_search_ek1.appendChild(search_for_roommates);

var group = document.createElement("div");
group.id = "group";
group.style.width = "39px";
group.style.height = "39px";
group.style.left = "50px";
group.style.top = "381px";
group.style.position = "absolute";
page_search_ek1.appendChild(group);

var group_ek1 = document.createElement("div");
group_ek1.id = "group_ek1";
group_ek1.style.width = "39px";
group_ek1.style.height = "39px";
group_ek1.style.left = "0px";
group_ek1.style.top = "0px";
group_ek1.style.position = "absolute";
group.appendChild(group_ek1);

var vector_ek1 = document.createElement("img");
vector_ek1.id = "vector_ek1";
vector_ek1.style.left = "0px";
vector_ek1.style.top = "18px";
vector_ek1.style.width = "6.46px";
vector_ek1.style.height = "13.54px";
vector_ek1.src = "skins/vector_ek1.png";

group_ek1.appendChild(vector_ek1);

var vector_ek2 = document.createElement("img");
vector_ek2.id = "vector_ek2";
vector_ek2.style.left = "3px";
vector_ek2.style.top = "13px";
vector_ek2.style.width = "19.8px";
vector_ek2.style.height = "18.28px";
vector_ek2.src = "skins/vector_ek2.png";

group_ek1.appendChild(vector_ek2);

var vector_ek3 = document.createElement("img");
vector_ek3.id = "vector_ek3";
vector_ek3.style.left = "9px";
vector_ek3.style.top = "13px";
vector_ek3.style.width = "11.02px";
vector_ek3.style.height = "7.45px";
vector_ek3.src = "skins/vector_ek3.png";

group_ek1.appendChild(vector_ek3);

var vector_ek4 = document.createElement("img");
vector_ek4.id = "vector_ek4";
vector_ek4.style.left = "4px";
vector_ek4.style.top = "0px";
vector_ek4.style.width = "35.36px";
vector_ek4.style.height = "39px";
vector_ek4.src = "skins/vector_ek4.png";

group_ek1.appendChild(vector_ek4);

var vector_ek5 = document.createElement("img");
vector_ek5.id = "vector_ek5";
vector_ek5.style.left = "25px";
vector_ek5.style.top = "21px";
vector_ek5.style.width = "11.02px";
vector_ek5.style.height = "7.45px";
vector_ek5.src = "skins/vector_ek5.png";

group_ek1.appendChild(vector_ek5);

var vector_ek6 = document.createElement("img");
vector_ek6.id = "vector_ek6";
vector_ek6.style.left = "20px";
vector_ek6.style.top = "8px";
vector_ek6.style.width = "14.83px";
vector_ek6.style.height = "15.84px";
vector_ek6.src = "skins/vector_ek6.png";

group_ek1.appendChild(vector_ek6);

var vector_ek7 = document.createElement("img");
vector_ek7.id = "vector_ek7";
vector_ek7.style.left = "368px";
vector_ek7.style.top = "252px";
vector_ek7.style.width = "7px";
vector_ek7.style.height = "14px";
vector_ek7.src = "skins/vector_ek7.png";

page_search_ek1.appendChild(vector_ek7);

var vector_ek8 = document.createElement("img");
vector_ek8.id = "vector_ek8";
vector_ek8.style.left = "368px";
vector_ek8.style.top = "395px";
vector_ek8.style.width = "7px";
vector_ek8.style.height = "14px";
vector_ek8.src = "skins/vector_ek8.png";

page_search_ek1.appendChild(vector_ek8);

var down = document.createElement("div");
down.id = "down";
down.style.width = "428px";
down.style.height = "105px";
down.style.left = "0px";
down.style.top = "714px";
down.style.position = "absolute";
page_search_ek1.appendChild(down);

var rectangle_3 = document.createElement("div");
rectangle_3.id = "rectangle_3";
rectangle_3.style.left = "0px";
rectangle_3.style.opacity = "0.75999999046326";
rectangle_3.style.filter = "alpha(opacity='75.999999046326')";
rectangle_3.style.top = "0px";
rectangle_3.style.width = "428px";
rectangle_3.style.height = "105px";
rectangle_3.style.borderRadius = "10px";
rectangle_3.style.background = 'rgba(253.94,253.94,253.94,0.76)';

down.appendChild(rectangle_3);

var vector_ek9 = document.createElement("img");
vector_ek9.id = "vector_ek9";
vector_ek9.style.left = "30.64px";
vector_ek9.style.top = "38px";
vector_ek9.style.width = "29.62px";
vector_ek9.style.height = "29px";
vector_ek9.src = "skins/vector_ek9.png";

down.appendChild(vector_ek9);

var vector_ek10 = document.createElement("img");
vector_ek10.id = "vector_ek10";
vector_ek10.style.left = "147.09px";
vector_ek10.style.top = "38px";
vector_ek10.style.width = "29.62px";
vector_ek10.style.height = "29px";
vector_ek10.src = "skins/vector_ek10.png";

down.appendChild(vector_ek10);

var vector_ek11 = document.createElement("img");
vector_ek11.id = "vector_ek11";
vector_ek11.style.left = "260.48px";
vector_ek11.style.top = "43px";
vector_ek11.style.width = "29.62px";
vector_ek11.style.height = "29px";
vector_ek11.src = "skins/vector_ek11.png";

down.appendChild(vector_ek11);

var group_ek2 = document.createElement("div");
group_ek2.id = "group_ek2";
group_ek2.style.width = "29.62px";
group_ek2.style.height = "29px";
group_ek2.style.left = "375px";
group_ek2.style.top = "9px";
group_ek2.style.position = "absolute";
down.appendChild(group_ek2);

var vector_ek12 = document.createElement("img");
vector_ek12.id = "vector_ek12";
vector_ek12.style.left = "0px";
vector_ek12.style.top = "0px";
vector_ek12.style.width = "29.62px";
vector_ek12.style.height = "29px";
vector_ek12.src = "skins/vector_ek12.png";

group_ek2.appendChild(vector_ek12);

var home = document.createElement("div");
home.innerHTML = "Home";
home.style.textAlign = "left";
home.id = "home";
home.style.left = "26.56px";
home.style.top = "72px";
home.style.width = "61.9px";
home.style.height = "31px";
home.style.fontFamily = "Poppins";
home.style.fontSize = "14px";
home.style.overflow = "hidden";
home.style.color = "#000000";

down.appendChild(home);

var search_ek4 = document.createElement("div");
search_ek4.innerHTML = "Search";
search_ek4.style.textAlign = "left";
search_ek4.id = "search_ek4";
search_ek4.style.left = "138.92px";
search_ek4.style.top = "72px";
search_ek4.style.width = "70.07px";
search_ek4.style.height = "31px";
search_ek4.style.fontFamily = "Poppins";
search_ek4.style.fontSize = "14px";
search_ek4.style.overflow = "hidden";
search_ek4.style.color = "#CB5A7A";

down.appendChild(search_ek4);

var saved = document.createElement("div");
saved.innerHTML = "Saved";
saved.style.textAlign = "left";
saved.id = "saved";
saved.style.left = "253.33px";
saved.style.top = "72px";
saved.style.width = "63.95px";
saved.style.height = "31px";
saved.style.fontFamily = "Poppins";
saved.style.fontSize = "14px";
saved.style.overflow = "hidden";
saved.style.color = "#000000";

down.appendChild(saved);

var account = document.createElement("div");
account.innerHTML = "Account";
account.style.textAlign = "left";
account.id = "account";
account.style.left = "359.56px";
account.style.top = "72px";
account.style.width = "79.27px";
account.style.height = "31px";
account.style.fontFamily = "Poppins";
account.style.fontSize = "14px";
account.style.overflow = "hidden";
account.style.color = "#07132A";

down.appendChild(account);







var page_search_ek7 = document.createElement("div");
page_search_ek7.id = "page_search_ek7";
page_search_ek7.style.width = "428px";
page_search_ek7.style.height = "826px";
page_search_ek7.style.left = "0px";
page_search_ek7.style.top = "0px";
page_search_ek7.style.position = "absolute";
content_container.appendChild(page_search_ek7);

var _bg__search_ek8 = document.createElement("div");
_bg__search_ek8.id = "_bg__search_ek8";
_bg__search_ek8.style.left = "0px";
_bg__search_ek8.style.top = "0px";
_bg__search_ek8.style.width = "428px";
_bg__search_ek8.style.height = "826px";
_bg__search_ek8.style.background = 'rgba(234.81,234.81,234.81,1)';

page_search_ek7.appendChild(_bg__search_ek8);

var rectangle_53_ek3 = document.createElement("div");
rectangle_53_ek3.id = "rectangle_53_ek3";
rectangle_53_ek3.style.left = "0px";
rectangle_53_ek3.style.top = "0px";
rectangle_53_ek3.style.width = "428px";
rectangle_53_ek3.style.height = "89px";
rectangle_53_ek3.style.background = 'rgba(203,90,122,1)';

page_search_ek7.appendChild(rectangle_53_ek3);

var messages_ek3 = document.createElement("div");
messages_ek3.innerHTML = "Messages";
messages_ek3.style.textAlign = "left";
messages_ek3.id = "messages_ek3";
messages_ek3.style.left = "158px";
messages_ek3.style.top = "41px";
messages_ek3.style.width = "139px";
messages_ek3.style.height = "48px";
messages_ek3.style.fontFamily = "Poppins";
messages_ek3.style.fontSize = "22px";
messages_ek3.style.overflow = "hidden";
messages_ek3.style.color = "#FFFFFF";

page_search_ek7.appendChild(messages_ek3);

var ellipse_15 = document.createElement("img");
ellipse_15.id = "ellipse_15";
ellipse_15.style.left = "13px";
ellipse_15.style.top = "135px";
ellipse_15.style.width = "65px";
ellipse_15.style.height = "65px";
ellipse_15.src = "skins/ellipse_15.png";

page_search_ek7.appendChild(ellipse_15);

var ellipse_17 = document.createElement("img");
ellipse_17.id = "ellipse_17";
ellipse_17.style.left = "13px";
ellipse_17.style.top = "211px";
ellipse_17.style.width = "65px";
ellipse_17.style.height = "65px";
ellipse_17.src = "skins/ellipse_17.png";

page_search_ek7.appendChild(ellipse_17);

var chris_walker_ek1 = document.createElement("div");
chris_walker_ek1.innerHTML = "Chris Walker";
chris_walker_ek1.style.fontWeight = "bold";
chris_walker_ek1.style.textAlign = "left";
chris_walker_ek1.id = "chris_walker_ek1";
chris_walker_ek1.style.left = "95px";
chris_walker_ek1.style.top = "144px";
chris_walker_ek1.style.width = "125px";
chris_walker_ek1.style.height = "35px";
chris_walker_ek1.style.fontFamily = "Poppins";
chris_walker_ek1.style.fontSize = "16px";
chris_walker_ek1.style.overflow = "hidden";
chris_walker_ek1.style.color = "#000000";

page_search_ek7.appendChild(chris_walker_ek1);

var ellipse_18 = document.createElement("img");
ellipse_18.id = "ellipse_18";
ellipse_18.style.left = "13px";
ellipse_18.style.top = "287px";
ellipse_18.style.width = "65px";
ellipse_18.style.height = "65px";
ellipse_18.src = "skins/ellipse_18.png";

page_search_ek7.appendChild(ellipse_18);

var ellipse_19 = document.createElement("img");
ellipse_19.id = "ellipse_19";
ellipse_19.style.left = "13px";
ellipse_19.style.top = "363px";
ellipse_19.style.width = "65px";
ellipse_19.style.height = "65px";
ellipse_19.src = "skins/ellipse_19.png";

page_search_ek7.appendChild(ellipse_19);

var ellipse_20 = document.createElement("img");
ellipse_20.id = "ellipse_20";
ellipse_20.style.left = "13px";
ellipse_20.style.top = "439px";
ellipse_20.style.width = "65px";
ellipse_20.style.height = "65px";
ellipse_20.src = "skins/ellipse_20.png";

page_search_ek7.appendChild(ellipse_20);

var ellipse_21 = document.createElement("img");
ellipse_21.id = "ellipse_21";
ellipse_21.style.left = "13px";
ellipse_21.style.top = "515px";
ellipse_21.style.width = "65px";
ellipse_21.style.height = "65px";
ellipse_21.src = "skins/ellipse_21.png";

page_search_ek7.appendChild(ellipse_21);

var ellipse_22 = document.createElement("img");
ellipse_22.id = "ellipse_22";
ellipse_22.style.left = "13px";
ellipse_22.style.top = "591px";
ellipse_22.style.width = "65px";
ellipse_22.style.height = "65px";
ellipse_22.src = "skins/ellipse_22.png";

page_search_ek7.appendChild(ellipse_22);

var johnson_princess = document.createElement("div");
johnson_princess.innerHTML = "Johnson Princess";
johnson_princess.style.fontWeight = "bold";
johnson_princess.style.textAlign = "left";
johnson_princess.id = "johnson_princess";
johnson_princess.style.left = "95px";
johnson_princess.style.top = "220px";
johnson_princess.style.width = "163px";
johnson_princess.style.height = "35px";
johnson_princess.style.fontFamily = "Poppins";
johnson_princess.style.fontSize = "16px";
johnson_princess.style.overflow = "hidden";
johnson_princess.style.color = "#000000";

page_search_ek7.appendChild(johnson_princess);

var cathrine_momo = document.createElement("div");
cathrine_momo.innerHTML = "Cathrine Momo";
cathrine_momo.style.fontWeight = "bold";
cathrine_momo.style.textAlign = "left";
cathrine_momo.id = "cathrine_momo";
cathrine_momo.style.left = "95px";
cathrine_momo.style.top = "296px";
cathrine_momo.style.width = "148px";
cathrine_momo.style.height = "35px";
cathrine_momo.style.fontFamily = "Poppins";
cathrine_momo.style.fontSize = "16px";
cathrine_momo.style.overflow = "hidden";
cathrine_momo.style.color = "#000000";

page_search_ek7.appendChild(cathrine_momo);

var hey__saw_your_request_to_be_my_roommate__do_you_____ = document.createElement("div");
hey__saw_your_request_to_be_my_roommate__do_you_____.innerHTML = "Hey, saw your request to be my roommate, do you ....";
hey__saw_your_request_to_be_my_roommate__do_you_____.style.textAlign = "left";
hey__saw_your_request_to_be_my_roommate__do_you_____.id = "hey__saw_your_request_to_be_my_roommate__do_you_____";
hey__saw_your_request_to_be_my_roommate__do_you_____.style.left = "95px";
hey__saw_your_request_to_be_my_roommate__do_you_____.style.top = "168px";
hey__saw_your_request_to_be_my_roommate__do_you_____.style.width = "302.5px";
hey__saw_your_request_to_be_my_roommate__do_you_____.style.height = "24.5px";
hey__saw_your_request_to_be_my_roommate__do_you_____.style.fontFamily = "Poppins";
hey__saw_your_request_to_be_my_roommate__do_you_____.style.fontSize = "11px";
hey__saw_your_request_to_be_my_roommate__do_you_____.style.overflow = "hidden";
hey__saw_your_request_to_be_my_roommate__do_you_____.style.color = "#000000";

page_search_ek7.appendChild(hey__saw_your_request_to_be_my_roommate__do_you_____);

var daniel_adeleke = document.createElement("div");
daniel_adeleke.innerHTML = "Daniel Adeleke";
daniel_adeleke.style.fontWeight = "bold";
daniel_adeleke.style.textAlign = "left";
daniel_adeleke.id = "daniel_adeleke";
daniel_adeleke.style.left = "95px";
daniel_adeleke.style.top = "372px";
daniel_adeleke.style.width = "143px";
daniel_adeleke.style.height = "35px";
daniel_adeleke.style.fontFamily = "Poppins";
daniel_adeleke.style.fontSize = "16px";
daniel_adeleke.style.overflow = "hidden";
daniel_adeleke.style.color = "#000000";

page_search_ek7.appendChild(daniel_adeleke);

var evans = document.createElement("div");
evans.innerHTML = "Evans ";
evans.style.fontWeight = "bold";
evans.style.textAlign = "left";
evans.id = "evans";
evans.style.left = "95px";
evans.style.top = "448px";
evans.style.width = "70px";
evans.style.height = "35px";
evans.style.fontFamily = "Poppins";
evans.style.fontSize = "16px";
evans.style.overflow = "hidden";
evans.style.color = "#000000";

page_search_ek7.appendChild(evans);

var ruth_alexia = document.createElement("div");
ruth_alexia.innerHTML = "Ruth Alexia";
ruth_alexia.style.fontWeight = "bold";
ruth_alexia.style.textAlign = "left";
ruth_alexia.id = "ruth_alexia";
ruth_alexia.style.left = "95px";
ruth_alexia.style.top = "524px";
ruth_alexia.style.width = "113px";
ruth_alexia.style.height = "35px";
ruth_alexia.style.fontFamily = "Poppins";
ruth_alexia.style.fontSize = "16px";
ruth_alexia.style.overflow = "hidden";
ruth_alexia.style.color = "#000000";

page_search_ek7.appendChild(ruth_alexia);

var somto_nwafor = document.createElement("div");
somto_nwafor.innerHTML = "Somto Nwafor";
somto_nwafor.style.fontWeight = "bold";
somto_nwafor.style.textAlign = "left";
somto_nwafor.id = "somto_nwafor";
somto_nwafor.style.left = "95px";
somto_nwafor.style.top = "600px";
somto_nwafor.style.width = "137px";
somto_nwafor.style.height = "35px";
somto_nwafor.style.fontFamily = "Poppins";
somto_nwafor.style.fontSize = "16px";
somto_nwafor.style.overflow = "hidden";
somto_nwafor.style.color = "#000000";

page_search_ek7.appendChild(somto_nwafor);

var hey__saw_your_request_to_be_my_roommate__do_you______ek1 = document.createElement("div");
hey__saw_your_request_to_be_my_roommate__do_you______ek1.innerHTML = "Hey, saw your request to be my roommate, do you ....";
hey__saw_your_request_to_be_my_roommate__do_you______ek1.style.textAlign = "left";
hey__saw_your_request_to_be_my_roommate__do_you______ek1.id = "hey__saw_your_request_to_be_my_roommate__do_you______ek1";
hey__saw_your_request_to_be_my_roommate__do_you______ek1.style.left = "95px";
hey__saw_your_request_to_be_my_roommate__do_you______ek1.style.top = "244px";
hey__saw_your_request_to_be_my_roommate__do_you______ek1.style.width = "302.5px";
hey__saw_your_request_to_be_my_roommate__do_you______ek1.style.height = "24.5px";
hey__saw_your_request_to_be_my_roommate__do_you______ek1.style.fontFamily = "Poppins";
hey__saw_your_request_to_be_my_roommate__do_you______ek1.style.fontSize = "11px";
hey__saw_your_request_to_be_my_roommate__do_you______ek1.style.overflow = "hidden";
hey__saw_your_request_to_be_my_roommate__do_you______ek1.style.color = "#000000";

page_search_ek7.appendChild(hey__saw_your_request_to_be_my_roommate__do_you______ek1);

var _7_23pm = document.createElement("div");
_7_23pm.innerHTML = "7:23PM";
_7_23pm.style.textAlign = "left";
_7_23pm.id = "_7_23pm";
_7_23pm.style.left = "369px";
_7_23pm.style.top = "145px";
_7_23pm.style.width = "53.5px";
_7_23pm.style.height = "24.5px";
_7_23pm.style.fontFamily = "Poppins";
_7_23pm.style.fontSize = "11px";
_7_23pm.style.overflow = "hidden";
_7_23pm.style.color = "#000000";

page_search_ek7.appendChild(_7_23pm);

var hey__saw_your_request_to_be_my_roommate__do_you______ek2 = document.createElement("div");
hey__saw_your_request_to_be_my_roommate__do_you______ek2.innerHTML = "Hey, saw your request to be my roommate, do you ....";
hey__saw_your_request_to_be_my_roommate__do_you______ek2.style.textAlign = "left";
hey__saw_your_request_to_be_my_roommate__do_you______ek2.id = "hey__saw_your_request_to_be_my_roommate__do_you______ek2";
hey__saw_your_request_to_be_my_roommate__do_you______ek2.style.left = "95px";
hey__saw_your_request_to_be_my_roommate__do_you______ek2.style.top = "320px";
hey__saw_your_request_to_be_my_roommate__do_you______ek2.style.width = "302.5px";
hey__saw_your_request_to_be_my_roommate__do_you______ek2.style.height = "24.5px";
hey__saw_your_request_to_be_my_roommate__do_you______ek2.style.fontFamily = "Poppins";
hey__saw_your_request_to_be_my_roommate__do_you______ek2.style.fontSize = "11px";
hey__saw_your_request_to_be_my_roommate__do_you______ek2.style.overflow = "hidden";
hey__saw_your_request_to_be_my_roommate__do_you______ek2.style.color = "#000000";

page_search_ek7.appendChild(hey__saw_your_request_to_be_my_roommate__do_you______ek2);

var hey__saw_your_request_to_be_my_roommate__do_you______ek3 = document.createElement("div");
hey__saw_your_request_to_be_my_roommate__do_you______ek3.innerHTML = "Hey, saw your request to be my roommate, do you ....";
hey__saw_your_request_to_be_my_roommate__do_you______ek3.style.textAlign = "left";
hey__saw_your_request_to_be_my_roommate__do_you______ek3.id = "hey__saw_your_request_to_be_my_roommate__do_you______ek3";
hey__saw_your_request_to_be_my_roommate__do_you______ek3.style.left = "95px";
hey__saw_your_request_to_be_my_roommate__do_you______ek3.style.top = "396px";
hey__saw_your_request_to_be_my_roommate__do_you______ek3.style.width = "302.5px";
hey__saw_your_request_to_be_my_roommate__do_you______ek3.style.height = "24.5px";
hey__saw_your_request_to_be_my_roommate__do_you______ek3.style.fontFamily = "Poppins";
hey__saw_your_request_to_be_my_roommate__do_you______ek3.style.fontSize = "11px";
hey__saw_your_request_to_be_my_roommate__do_you______ek3.style.overflow = "hidden";
hey__saw_your_request_to_be_my_roommate__do_you______ek3.style.color = "#000000";

page_search_ek7.appendChild(hey__saw_your_request_to_be_my_roommate__do_you______ek3);

var hey__saw_your_request_to_be_my_roommate__do_you______ek4 = document.createElement("div");
hey__saw_your_request_to_be_my_roommate__do_you______ek4.innerHTML = "Hey, saw your request to be my roommate, do you ....";
hey__saw_your_request_to_be_my_roommate__do_you______ek4.style.textAlign = "left";
hey__saw_your_request_to_be_my_roommate__do_you______ek4.id = "hey__saw_your_request_to_be_my_roommate__do_you______ek4";
hey__saw_your_request_to_be_my_roommate__do_you______ek4.style.left = "95px";
hey__saw_your_request_to_be_my_roommate__do_you______ek4.style.top = "472px";
hey__saw_your_request_to_be_my_roommate__do_you______ek4.style.width = "302.5px";
hey__saw_your_request_to_be_my_roommate__do_you______ek4.style.height = "24.5px";
hey__saw_your_request_to_be_my_roommate__do_you______ek4.style.fontFamily = "Poppins";
hey__saw_your_request_to_be_my_roommate__do_you______ek4.style.fontSize = "11px";
hey__saw_your_request_to_be_my_roommate__do_you______ek4.style.overflow = "hidden";
hey__saw_your_request_to_be_my_roommate__do_you______ek4.style.color = "#000000";

page_search_ek7.appendChild(hey__saw_your_request_to_be_my_roommate__do_you______ek4);

var hey__saw_your_request_to_be_my_roommate__do_you______ek5 = document.createElement("div");
hey__saw_your_request_to_be_my_roommate__do_you______ek5.innerHTML = "Hey, saw your request to be my roommate, do you ....";
hey__saw_your_request_to_be_my_roommate__do_you______ek5.style.textAlign = "left";
hey__saw_your_request_to_be_my_roommate__do_you______ek5.id = "hey__saw_your_request_to_be_my_roommate__do_you______ek5";
hey__saw_your_request_to_be_my_roommate__do_you______ek5.style.left = "95px";
hey__saw_your_request_to_be_my_roommate__do_you______ek5.style.top = "548px";
hey__saw_your_request_to_be_my_roommate__do_you______ek5.style.width = "302.5px";
hey__saw_your_request_to_be_my_roommate__do_you______ek5.style.height = "24.5px";
hey__saw_your_request_to_be_my_roommate__do_you______ek5.style.fontFamily = "Poppins";
hey__saw_your_request_to_be_my_roommate__do_you______ek5.style.fontSize = "11px";
hey__saw_your_request_to_be_my_roommate__do_you______ek5.style.overflow = "hidden";
hey__saw_your_request_to_be_my_roommate__do_you______ek5.style.color = "#000000";

page_search_ek7.appendChild(hey__saw_your_request_to_be_my_roommate__do_you______ek5);

var hey__saw_your_request_to_be_my_roommate__do_you______ek6 = document.createElement("div");
hey__saw_your_request_to_be_my_roommate__do_you______ek6.innerHTML = "Hey, saw your request to be my roommate, do you ....";
hey__saw_your_request_to_be_my_roommate__do_you______ek6.style.textAlign = "left";
hey__saw_your_request_to_be_my_roommate__do_you______ek6.id = "hey__saw_your_request_to_be_my_roommate__do_you______ek6";
hey__saw_your_request_to_be_my_roommate__do_you______ek6.style.left = "95px";
hey__saw_your_request_to_be_my_roommate__do_you______ek6.style.top = "624px";
hey__saw_your_request_to_be_my_roommate__do_you______ek6.style.width = "302.5px";
hey__saw_your_request_to_be_my_roommate__do_you______ek6.style.height = "24.5px";
hey__saw_your_request_to_be_my_roommate__do_you______ek6.style.fontFamily = "Poppins";
hey__saw_your_request_to_be_my_roommate__do_you______ek6.style.fontSize = "11px";
hey__saw_your_request_to_be_my_roommate__do_you______ek6.style.overflow = "hidden";
hey__saw_your_request_to_be_my_roommate__do_you______ek6.style.color = "#000000";

page_search_ek7.appendChild(hey__saw_your_request_to_be_my_roommate__do_you______ek6);

var ellipse_16 = document.createElement("div");
ellipse_16.id = "ellipse_16";
ellipse_16.style.left = "401px";
ellipse_16.style.top = "168px";
ellipse_16.style.width = "9px";
ellipse_16.style.height = "9px";
ellipse_16.style.borderRadius = "4.5px / 4.5px";
ellipse_16.style.background = 'rgba(203,90,122,1)';

page_search_ek7.appendChild(ellipse_16);

var _rectangle_63_ek1 = document.createElement("div");
_rectangle_63_ek1.id = "_rectangle_63_ek1";
_rectangle_63_ek1.style.left = "0px";
_rectangle_63_ek1.style.opacity = "0.25";
_rectangle_63_ek1.style.filter = "alpha(opacity='25')";
_rectangle_63_ek1.style.top = "133px";
_rectangle_63_ek1.style.width = "428px";
_rectangle_63_ek1.style.height = "75px";
_rectangle_63_ek1.style.background = 'rgba(217,217,217,0.25)';

page_search_ek7.appendChild(_rectangle_63_ek1);

_rectangle_63_ek1.style.cursor = "pointer";
_rectangle_63_ek1.onclick = (e) => {
	@page_view("messages");
}

var rectangle_64 = document.createElement("div");
rectangle_64.id = "rectangle_64";
rectangle_64.style.left = "3px";
rectangle_64.style.opacity = "0.25";
rectangle_64.style.filter = "alpha(opacity='25')";
rectangle_64.style.top = "208px";
rectangle_64.style.width = "428px";
rectangle_64.style.height = "75px";
rectangle_64.style.background = 'rgba(217,217,217,0.25)';

page_search_ek7.appendChild(rectangle_64);

var rectangle_65 = document.createElement("div");
rectangle_65.id = "rectangle_65";
rectangle_65.style.left = "0px";
rectangle_65.style.opacity = "0.25";
rectangle_65.style.filter = "alpha(opacity='25')";
rectangle_65.style.top = "286px";
rectangle_65.style.width = "428px";
rectangle_65.style.height = "75px";
rectangle_65.style.background = 'rgba(217,217,217,0.25)';

page_search_ek7.appendChild(rectangle_65);

var rectangle_66 = document.createElement("div");
rectangle_66.id = "rectangle_66";
rectangle_66.style.left = "0px";
rectangle_66.style.opacity = "0.25";
rectangle_66.style.filter = "alpha(opacity='25')";
rectangle_66.style.top = "364px";
rectangle_66.style.width = "428px";
rectangle_66.style.height = "75px";
rectangle_66.style.background = 'rgba(217,217,217,0.25)';

page_search_ek7.appendChild(rectangle_66);

var rectangle_67 = document.createElement("div");
rectangle_67.id = "rectangle_67";
rectangle_67.style.left = "3px";
rectangle_67.style.opacity = "0.25";
rectangle_67.style.filter = "alpha(opacity='25')";
rectangle_67.style.top = "435px";
rectangle_67.style.width = "428px";
rectangle_67.style.height = "75px";
rectangle_67.style.background = 'rgba(217,217,217,0.25)';

page_search_ek7.appendChild(rectangle_67);

var rectangle_68 = document.createElement("div");
rectangle_68.id = "rectangle_68";
rectangle_68.style.left = "0px";
rectangle_68.style.opacity = "0.25";
rectangle_68.style.filter = "alpha(opacity='25')";
rectangle_68.style.top = "516px";
rectangle_68.style.width = "428px";
rectangle_68.style.height = "75px";
rectangle_68.style.background = 'rgba(217,217,217,0.25)';

page_search_ek7.appendChild(rectangle_68);

var rectangle_69_ek1 = document.createElement("div");
rectangle_69_ek1.id = "rectangle_69_ek1";
rectangle_69_ek1.style.left = "0px";
rectangle_69_ek1.style.opacity = "0.25";
rectangle_69_ek1.style.filter = "alpha(opacity='25')";
rectangle_69_ek1.style.top = "593px";
rectangle_69_ek1.style.width = "428px";
rectangle_69_ek1.style.height = "75px";
rectangle_69_ek1.style.background = 'rgba(217,217,217,0.25)';

page_search_ek7.appendChild(rectangle_69_ek1);




