/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);








var page_sign_up_ek1 = document.createElement("div");
page_sign_up_ek1.id = "page_sign_up_ek1";
page_sign_up_ek1.style.width = "414px";
page_sign_up_ek1.style.height = "826px";
page_sign_up_ek1.style.left = "0px";
page_sign_up_ek1.style.top = "0px";
page_sign_up_ek1.style.position = "absolute";
content_container.appendChild(page_sign_up_ek1);

var _bg__sign_up_ek2 = document.createElement("div");
_bg__sign_up_ek2.id = "_bg__sign_up_ek2";
_bg__sign_up_ek2.style.left = "0px";
_bg__sign_up_ek2.style.top = "0px";
_bg__sign_up_ek2.style.width = "414px";
_bg__sign_up_ek2.style.height = "826px";
_bg__sign_up_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_sign_up_ek1.appendChild(_bg__sign_up_ek2);

var already_have_an_account__ = document.createElement("div");
already_have_an_account__.innerHTML = "Already have an account ? ";
already_have_an_account__.style.textAlign = "left";
already_have_an_account__.id = "already_have_an_account__";
already_have_an_account__.style.left = "87px";
already_have_an_account__.style.top = "709px";
already_have_an_account__.style.width = "207px";
already_have_an_account__.style.height = "31px";
already_have_an_account__.style.fontFamily = "Poppins";
already_have_an_account__.style.fontSize = "14px";
already_have_an_account__.style.overflow = "hidden";
already_have_an_account__.style.color = "#000000";

page_sign_up_ek1.appendChild(already_have_an_account__);

var _sign_in = document.createElement("div");
_sign_in.innerHTML = "Sign in";
_sign_in.style.textAlign = "left";
_sign_in.id = "_sign_in";
_sign_in.style.left = "280px";
_sign_in.style.top = "709px";
_sign_in.style.width = "66px";
_sign_in.style.height = "31px";
_sign_in.style.fontFamily = "Poppins";
_sign_in.style.fontSize = "14px";
_sign_in.style.overflow = "hidden";
_sign_in.style.color = "#CB5A7A";

page_sign_up_ek1.appendChild(_sign_in);

_sign_in.style.cursor = "pointer";
_sign_in.onclick = (e) => {
	@page_view("sign_in");
}

var _rectangle_1_ek2 = document.createElement("div");
_rectangle_1_ek2.id = "_rectangle_1_ek2";
_rectangle_1_ek2.style.left = "93px";
_rectangle_1_ek2.style.top = "633px";
_rectangle_1_ek2.style.width = "225px";
_rectangle_1_ek2.style.height = "52px";
_rectangle_1_ek2.style.borderRadius = "20px";
_rectangle_1_ek2.style.background = 'rgba(203,90,122,1)';

page_sign_up_ek1.appendChild(_rectangle_1_ek2);

_rectangle_1_ek2.style.cursor = "pointer";
_rectangle_1_ek2.onclick = (e) => {
	@page_view("email_verification");
}

var email = document.createElement("div");
email.innerHTML = "Email";
email.style.textAlign = "center";
email.id = "email";
email.style.left = "23px";
email.style.top = "297px";
email.style.width = "51px";
email.style.height = "31px";
email.style.fontFamily = "Poppins";
email.style.fontSize = "14px";
email.style.overflow = "hidden";
email.style.color = "#000000";

page_sign_up_ek1.appendChild(email);

var username = document.createElement("div");
username.innerHTML = "Username";
username.style.textAlign = "center";
username.id = "username";
username.style.left = "23px";
username.style.top = "193px";
username.style.width = "85px";
username.style.height = "31px";
username.style.fontFamily = "Poppins";
username.style.fontSize = "14px";
username.style.overflow = "hidden";
username.style.color = "#000000";

page_sign_up_ek1.appendChild(username);

var password = document.createElement("div");
password.innerHTML = "Password";
password.style.textAlign = "center";
password.id = "password";
password.style.left = "20px";
password.style.top = "403px";
password.style.width = "81px";
password.style.height = "31px";
password.style.fontFamily = "Poppins";
password.style.fontSize = "14px";
password.style.overflow = "hidden";
password.style.color = "#000000";

page_sign_up_ek1.appendChild(password);

var line_1 = document.createElement("div");
line_1.id = "line_1";
line_1.style.left = "25px";
line_1.style.top = "366px";
line_1.style.width = "333px";
line_1.style.height = "1px";
line_1.style.background = "#000000";

page_sign_up_ek1.appendChild(line_1);

var line_3 = document.createElement("div");
line_3.id = "line_3";
line_3.style.left = "25px";
line_3.style.top = "257px";
line_3.style.width = "333px";
line_3.style.height = "1px";
line_3.style.background = "#000000";

page_sign_up_ek1.appendChild(line_3);

var line_2 = document.createElement("div");
line_2.id = "line_2";
line_2.style.left = "25px";
line_2.style.top = "476px";
line_2.style.width = "333px";
line_2.style.height = "1px";
line_2.style.background = "#000000";

page_sign_up_ek1.appendChild(line_2);

var ___ = document.createElement("img");
___.id = "___";
___.style.left = "340px";
___.style.top = "436px";
___.style.width = "18px";
___.style.height = "12px";
___.src = "skins/___.png";

page_sign_up_ek1.appendChild(___);

var sign_up_ek3 = document.createElement("div");
sign_up_ek3.innerHTML = "Sign up";
sign_up_ek3.style.fontWeight = "bold";
sign_up_ek3.style.textAlign = "left";
sign_up_ek3.id = "sign_up_ek3";
sign_up_ek3.style.left = "173px";
sign_up_ek3.style.top = "646px";
sign_up_ek3.style.width = "92px";
sign_up_ek3.style.height = "40px";
sign_up_ek3.style.fontFamily = "Poppins";
sign_up_ek3.style.fontSize = "18px";
sign_up_ek3.style.overflow = "hidden";
sign_up_ek3.style.color = "#FFFFFF";

page_sign_up_ek1.appendChild(sign_up_ek3);

var enter_your_credentials_to_continue = document.createElement("div");
enter_your_credentials_to_continue.innerHTML = "Enter your credentials to continue";
enter_your_credentials_to_continue.style.textAlign = "center";
enter_your_credentials_to_continue.id = "enter_your_credentials_to_continue";
enter_your_credentials_to_continue.style.left = "18px";
enter_your_credentials_to_continue.style.top = "120px";
enter_your_credentials_to_continue.style.width = "223px";
enter_your_credentials_to_continue.style.height = "30px";
enter_your_credentials_to_continue.style.fontFamily = "Coda";
enter_your_credentials_to_continue.style.fontSize = "14px";
enter_your_credentials_to_continue.style.overflow = "hidden";
enter_your_credentials_to_continue.style.color = "#000000";

page_sign_up_ek1.appendChild(enter_your_credentials_to_continue);

var by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy = document.createElement("div");
by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy.innerHTML = "<span style=\"font-style:normal; font-weight:normal; text-decoration:NONE; \">By Continuing you agree to our </span><span style=\"color:#CB5A7A; font-style:normal; font-weight:normal; text-decoration:NONE; \">Terms of Service</span><span style=\"font-style:normal; font-weight:normal; text-decoration:NONE; \"> <br/>and </span><span style=\"color:#CB5A7A; font-style:normal; font-weight:normal; text-decoration:NONE; \">Privacy Polic</span>";
by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy.style.textAlign = "left";
by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy.id = "by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy";
by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy.style.left = "32px";
by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy.style.top = "500px";
by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy.style.width = "368px";
by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy.style.height = "52px";
by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy.style.fontFamily = "Poppins";
by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy.style.fontSize = "14px";
by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy.style.overflow = "hidden";
by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy.style.color = "#000000";

page_sign_up_ek1.appendChild(by_continuing_you_agree_to_our_terms_of_service_and_privacy_policy);

var sign_up_ek4 = document.createElement("div");
sign_up_ek4.innerHTML = "Sign Up";
sign_up_ek4.style.fontWeight = "bold";
sign_up_ek4.style.textAlign = "center";
sign_up_ek4.id = "sign_up_ek4";
sign_up_ek4.style.left = "17px";
sign_up_ek4.style.top = "83px";
sign_up_ek4.style.width = "92px";
sign_up_ek4.style.height = "44px";
sign_up_ek4.style.fontFamily = "Poppins";
sign_up_ek4.style.fontSize = "20px";
sign_up_ek4.style.overflow = "hidden";
sign_up_ek4.style.color = "#000000";

page_sign_up_ek1.appendChild(sign_up_ek4);

var status_bar_ek2 = document.createElement("div");
status_bar_ek2.id = "status_bar_ek2";
status_bar_ek2.style.width = "387px";
status_bar_ek2.style.height = "18px";
status_bar_ek2.style.left = "12px";
status_bar_ek2.style.top = "14px";
status_bar_ek2.style.position = "absolute";
page_sign_up_ek1.appendChild(status_bar_ek2);

var wifi_ek5 = document.createElement("img");
wifi_ek5.id = "wifi_ek5";
wifi_ek5.style.left = "294px";
wifi_ek5.style.top = "5px";
wifi_ek5.style.width = "14.94px";
wifi_ek5.style.height = "10px";
wifi_ek5.src = "skins/wifi_ek5.png";

status_bar_ek2.appendChild(wifi_ek5);

var time_ek2 = document.createElement("div");
time_ek2.innerHTML = "9:41 AM";
time_ek2.style.textAlign = "center";
time_ek2.id = "time_ek2";
time_ek2.style.left = "-2px";
time_ek2.style.top = "0px";
time_ek2.style.width = "62px";
time_ek2.style.height = "26px";
time_ek2.style.fontFamily = "Poppins";
time_ek2.style.fontSize = "12px";
time_ek2.style.overflow = "hidden";
time_ek2.style.color = "#030303";

status_bar_ek2.appendChild(time_ek2);

var battery_ek2 = document.createElement("div");
battery_ek2.id = "battery_ek2";
battery_ek2.style.width = "27.61px";
battery_ek2.style.height = "11.5px";
battery_ek2.style.left = "359px";
battery_ek2.style.top = "5px";
battery_ek2.style.position = "absolute";
status_bar_ek2.appendChild(battery_ek2);

var border_ek2 = document.createElement("img");
border_ek2.id = "border_ek2";
border_ek2.style.left = "0px";
border_ek2.style.opacity = "0.40000000596046";
border_ek2.style.filter = "alpha(opacity='40.000000596046')";
border_ek2.style.top = "0px";
border_ek2.style.width = "25px";
border_ek2.style.height = "11.5px";
border_ek2.src = "skins/border_ek2.png";

battery_ek2.appendChild(border_ek2);

var nub_ek2 = document.createElement("img");
nub_ek2.id = "nub_ek2";
nub_ek2.style.left = "26px";
nub_ek2.style.opacity = "0.40000000596046";
nub_ek2.style.filter = "alpha(opacity='40.000000596046')";
nub_ek2.style.top = "4px";
nub_ek2.style.width = "1.56px";
nub_ek2.style.height = "3.87px";
nub_ek2.src = "skins/nub_ek2.png";

battery_ek2.appendChild(nub_ek2);

var charge_ek2 = document.createElement("img");
charge_ek2.id = "charge_ek2";
charge_ek2.style.left = "2px";
charge_ek2.style.top = "2px";
charge_ek2.style.width = "20.83px";
charge_ek2.style.height = "7.5px";
charge_ek2.src = "skins/charge_ek2.png";

battery_ek2.appendChild(charge_ek2);

var mobile_signal_ek2 = document.createElement("img");
mobile_signal_ek2.id = "mobile_signal_ek2";
mobile_signal_ek2.style.left = "325px";
mobile_signal_ek2.style.top = "4px";
mobile_signal_ek2.style.width = "17.19px";
mobile_signal_ek2.style.height = "10px";
mobile_signal_ek2.src = "skins/mobile_signal_ek2.png";

status_bar_ek2.appendChild(mobile_signal_ek2);








