/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);






var page_onboard_3_3_ek1 = document.createElement("div");
page_onboard_3_3_ek1.id = "page_onboard_3_3_ek1";
page_onboard_3_3_ek1.style.width = "428px";
page_onboard_3_3_ek1.style.height = "826px";
page_onboard_3_3_ek1.style.left = "0px";
page_onboard_3_3_ek1.style.top = "0px";
page_onboard_3_3_ek1.style.position = "absolute";
content_container.appendChild(page_onboard_3_3_ek1);

var _bg__onboard_3_3_ek2 = document.createElement("div");
_bg__onboard_3_3_ek2.id = "_bg__onboard_3_3_ek2";
_bg__onboard_3_3_ek2.style.left = "0px";
_bg__onboard_3_3_ek2.style.top = "0px";
_bg__onboard_3_3_ek2.style.width = "428px";
_bg__onboard_3_3_ek2.style.height = "826px";
_bg__onboard_3_3_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_onboard_3_3_ek1.appendChild(_bg__onboard_3_3_ek2);

var safe_community = document.createElement("div");
safe_community.innerHTML = "SAFE COMMUNITY";
safe_community.style.fontWeight = "bold";
safe_community.style.textAlign = "left";
safe_community.id = "safe_community";
safe_community.style.left = "68px";
safe_community.style.top = "508px";
safe_community.style.width = "482px";
safe_community.style.height = "82px";
safe_community.style.fontFamily = "Poppins";
safe_community.style.fontSize = "34px";
safe_community.style.overflow = "hidden";
safe_community.style.color = "#000000";

page_onboard_3_3_ek1.appendChild(safe_community);

var all_users_are_verified_to_keep_everyone_safe = document.createElement("div");
all_users_are_verified_to_keep_everyone_safe.innerHTML = "All users are verified to keep everyone <br/>safe";
all_users_are_verified_to_keep_everyone_safe.style.fontWeight = "bold";
all_users_are_verified_to_keep_everyone_safe.style.textAlign = "center";
all_users_are_verified_to_keep_everyone_safe.id = "all_users_are_verified_to_keep_everyone_safe";
all_users_are_verified_to_keep_everyone_safe.style.left = "74px";
all_users_are_verified_to_keep_everyone_safe.style.top = "566px";
all_users_are_verified_to_keep_everyone_safe.style.width = "288px";
all_users_are_verified_to_keep_everyone_safe.style.height = "52px";
all_users_are_verified_to_keep_everyone_safe.style.fontFamily = "Poppins";
all_users_are_verified_to_keep_everyone_safe.style.fontSize = "14px";
all_users_are_verified_to_keep_everyone_safe.style.overflow = "hidden";
all_users_are_verified_to_keep_everyone_safe.style.color = "#000000";

page_onboard_3_3_ek1.appendChild(all_users_are_verified_to_keep_everyone_safe);

var _57537_1 = document.createElement("img");
_57537_1.id = "_57537_1";
_57537_1.style.left = "-16px";
_57537_1.style.top = "53px";
_57537_1.style.width = "499px";
_57537_1.style.height = "492px";
_57537_1.src = "skins/_57537_1.png";

page_onboard_3_3_ek1.appendChild(_57537_1);

var rectangle_1_ek1 = document.createElement("div");
rectangle_1_ek1.id = "rectangle_1_ek1";
rectangle_1_ek1.style.left = "239px";
rectangle_1_ek1.style.top = "656px";
rectangle_1_ek1.style.width = "26px";
rectangle_1_ek1.style.height = "12px";
rectangle_1_ek1.style.borderRadius = "5px";
rectangle_1_ek1.style.background = 'rgba(203,90,122,1)';

page_onboard_3_3_ek1.appendChild(rectangle_1_ek1);

var _rectangle_2_ek1 = document.createElement("div");
_rectangle_2_ek1.id = "_rectangle_2_ek1";
_rectangle_2_ek1.style.left = "163px";
_rectangle_2_ek1.style.top = "656px";
_rectangle_2_ek1.style.width = "14px";
_rectangle_2_ek1.style.height = "12px";
_rectangle_2_ek1.style.borderRadius = "5px";
_rectangle_2_ek1.style.background = 'rgba(217,217,217,1)';

page_onboard_3_3_ek1.appendChild(_rectangle_2_ek1);

_rectangle_2_ek1.style.cursor = "pointer";
_rectangle_2_ek1.onclick = (e) => {
	@page_view("onboard_1");
}

var _rectangle_3_ek2 = document.createElement("div");
_rectangle_3_ek2.id = "_rectangle_3_ek2";
_rectangle_3_ek2.style.left = "201px";
_rectangle_3_ek2.style.top = "656px";
_rectangle_3_ek2.style.width = "14px";
_rectangle_3_ek2.style.height = "12px";
_rectangle_3_ek2.style.borderRadius = "5px";
_rectangle_3_ek2.style.background = 'rgba(217,217,217,1)';

page_onboard_3_3_ek1.appendChild(_rectangle_3_ek2);

_rectangle_3_ek2.style.cursor = "pointer";
_rectangle_3_ek2.onclick = (e) => {
	@page_view("onboard_2");
}

var _rectangle_4 = document.createElement("div");
_rectangle_4.id = "_rectangle_4";
_rectangle_4.style.left = "85px";
_rectangle_4.style.top = "741px";
_rectangle_4.style.width = "260px";
_rectangle_4.style.height = "51px";
_rectangle_4.style.borderRadius = "15px";
_rectangle_4.style.background = 'rgba(203,90,122,1)';

page_onboard_3_3_ek1.appendChild(_rectangle_4);

_rectangle_4.style.cursor = "pointer";
_rectangle_4.onclick = (e) => {
	@page_view("sign_in");
}

var get_started = document.createElement("div");
get_started.innerHTML = "Get Started";
get_started.style.fontWeight = "bold";
get_started.style.textAlign = "center";
get_started.id = "get_started";
get_started.style.left = "158px";
get_started.style.top = "753px";
get_started.style.width = "119px";
get_started.style.height = "40px";
get_started.style.fontFamily = "Poppins";
get_started.style.fontSize = "18px";
get_started.style.overflow = "hidden";
get_started.style.color = "#FFFFFF";

page_onboard_3_3_ek1.appendChild(get_started);

var ellipse_2 = document.createElement("div");
ellipse_2.id = "ellipse_2";
ellipse_2.style.left = "-99px";
ellipse_2.style.top = "-306px";
ellipse_2.style.width = "169px";
ellipse_2.style.height = "169px";
ellipse_2.style.borderRadius = "84.5px / 84.5px";
ellipse_2.style.background = 'rgba(196,196,196,1)';

page_onboard_3_3_ek1.appendChild(ellipse_2);

var status_bar_ek1 = document.createElement("div");
status_bar_ek1.id = "status_bar_ek1";
status_bar_ek1.style.width = "387px";
status_bar_ek1.style.height = "18px";
status_bar_ek1.style.left = "21px";
status_bar_ek1.style.top = "16px";
status_bar_ek1.style.position = "absolute";
page_onboard_3_3_ek1.appendChild(status_bar_ek1);

var wifi_ek4 = document.createElement("img");
wifi_ek4.id = "wifi_ek4";
wifi_ek4.style.left = "294px";
wifi_ek4.style.top = "5px";
wifi_ek4.style.width = "14.94px";
wifi_ek4.style.height = "10px";
wifi_ek4.src = "skins/wifi_ek4.png";

status_bar_ek1.appendChild(wifi_ek4);

var time_ek1 = document.createElement("div");
time_ek1.innerHTML = "9:41 AM";
time_ek1.style.textAlign = "center";
time_ek1.id = "time_ek1";
time_ek1.style.left = "-2px";
time_ek1.style.top = "0px";
time_ek1.style.width = "62px";
time_ek1.style.height = "26px";
time_ek1.style.fontFamily = "Poppins";
time_ek1.style.fontSize = "12px";
time_ek1.style.overflow = "hidden";
time_ek1.style.color = "#030303";

status_bar_ek1.appendChild(time_ek1);

var battery_ek1 = document.createElement("div");
battery_ek1.id = "battery_ek1";
battery_ek1.style.width = "27.61px";
battery_ek1.style.height = "11.5px";
battery_ek1.style.left = "359px";
battery_ek1.style.top = "5px";
battery_ek1.style.position = "absolute";
status_bar_ek1.appendChild(battery_ek1);

var border_ek1 = document.createElement("img");
border_ek1.id = "border_ek1";
border_ek1.style.left = "0px";
border_ek1.style.opacity = "0.40000000596046";
border_ek1.style.filter = "alpha(opacity='40.000000596046')";
border_ek1.style.top = "0px";
border_ek1.style.width = "25px";
border_ek1.style.height = "11.5px";
border_ek1.src = "skins/border_ek1.png";

battery_ek1.appendChild(border_ek1);

var nub_ek1 = document.createElement("img");
nub_ek1.id = "nub_ek1";
nub_ek1.style.left = "26px";
nub_ek1.style.opacity = "0.40000000596046";
nub_ek1.style.filter = "alpha(opacity='40.000000596046')";
nub_ek1.style.top = "4px";
nub_ek1.style.width = "1.56px";
nub_ek1.style.height = "3.87px";
nub_ek1.src = "skins/nub_ek1.png";

battery_ek1.appendChild(nub_ek1);

var charge_ek1 = document.createElement("img");
charge_ek1.id = "charge_ek1";
charge_ek1.style.left = "2px";
charge_ek1.style.top = "2px";
charge_ek1.style.width = "20.83px";
charge_ek1.style.height = "7.5px";
charge_ek1.src = "skins/charge_ek1.png";

battery_ek1.appendChild(charge_ek1);

var mobile_signal_ek1 = document.createElement("img");
mobile_signal_ek1.id = "mobile_signal_ek1";
mobile_signal_ek1.style.left = "325px";
mobile_signal_ek1.style.top = "4px";
mobile_signal_ek1.style.width = "17.19px";
mobile_signal_ek1.style.height = "10px";
mobile_signal_ek1.src = "skins/mobile_signal_ek1.png";

status_bar_ek1.appendChild(mobile_signal_ek1);








