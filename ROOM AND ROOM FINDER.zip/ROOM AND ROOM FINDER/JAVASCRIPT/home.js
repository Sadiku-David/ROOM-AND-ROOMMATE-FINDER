/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);










var page_home_ek2 = document.createElement("div");
page_home_ek2.id = "page_home_ek2";
page_home_ek2.style.width = "428px";
page_home_ek2.style.height = "826px";
page_home_ek2.style.left = "0px";
page_home_ek2.style.top = "0px";
page_home_ek2.style.position = "absolute";
content_container.appendChild(page_home_ek2);

var _bg__home_ek3 = document.createElement("div");
_bg__home_ek3.id = "_bg__home_ek3";
_bg__home_ek3.style.left = "0px";
_bg__home_ek3.style.top = "0px";
_bg__home_ek3.style.width = "428px";
_bg__home_ek3.style.height = "826px";
_bg__home_ek3.style.background = 'rgba(234.81,234.81,234.81,1)';

page_home_ek2.appendChild(_bg__home_ek3);

var menu = document.createElement("div");
menu.id = "menu";
menu.style.width = "22px";
menu.style.height = "19px";
menu.style.left = "21px";
menu.style.top = "52px";
menu.style.position = "absolute";
page_home_ek2.appendChild(menu);

var vector_ek42 = document.createElement("img");
vector_ek42.id = "vector_ek42";
vector_ek42.style.left = "0px";
vector_ek42.style.top = "0px";
vector_ek42.style.width = "22px";
vector_ek42.style.height = "19px";
vector_ek42.src = "skins/vector_ek42.png";

menu.appendChild(vector_ek42);

var roomie_ek1 = document.createElement("div");
roomie_ek1.innerHTML = "ROOMIE";
roomie_ek1.style.textAlign = "left";
roomie_ek1.id = "roomie_ek1";
roomie_ek1.style.left = "180px";
roomie_ek1.style.top = "60px";
roomie_ek1.style.width = "93px";
roomie_ek1.style.height = "33px";
roomie_ek1.style.fontFamily = "Level 01 Bold";
roomie_ek1.style.fontSize = "20px";
roomie_ek1.style.overflow = "hidden";
roomie_ek1.style.color = "#1E1E1E";

page_home_ek2.appendChild(roomie_ek1);

var ci_notification = document.createElement("div");
ci_notification.id = "ci_notification";
ci_notification.style.width = "24px";
ci_notification.style.height = "24px";
ci_notification.style.left = "385px";
ci_notification.style.top = "55px";
ci_notification.style.position = "absolute";
page_home_ek2.appendChild(ci_notification);

var vector_ek43 = document.createElement("img");
vector_ek43.id = "vector_ek43";
vector_ek43.style.left = "4px";
vector_ek43.style.top = "2px";
vector_ek43.style.width = "16px";
vector_ek43.style.height = "20px";
vector_ek43.src = "skins/vector_ek43.png";

ci_notification.appendChild(vector_ek43);

var hi_david = document.createElement("div");
hi_david.innerHTML = "Hi,David";
hi_david.style.textAlign = "left";
hi_david.id = "hi_david";
hi_david.style.left = "21px";
hi_david.style.top = "102px";
hi_david.style.width = "118px";
hi_david.style.height = "48px";
hi_david.style.fontFamily = "Poppins";
hi_david.style.fontSize = "22px";
hi_david.style.overflow = "hidden";
hi_david.style.color = "#000000";

page_home_ek2.appendChild(hi_david);

var discover_our_recommendations = document.createElement("div");
discover_our_recommendations.innerHTML = "Discover Our Recommendations";
discover_our_recommendations.style.textAlign = "left";
discover_our_recommendations.id = "discover_our_recommendations";
discover_our_recommendations.style.left = "21px";
discover_our_recommendations.style.top = "135px";
discover_our_recommendations.style.width = "242px";
discover_our_recommendations.style.height = "31px";
discover_our_recommendations.style.fontFamily = "Poppins";
discover_our_recommendations.style.fontSize = "14px";
discover_our_recommendations.style.overflow = "hidden";
discover_our_recommendations.style.color = "#000000";

page_home_ek2.appendChild(discover_our_recommendations);

var rectangle_26_ek2 = document.createElement("div");
rectangle_26_ek2.id = "rectangle_26_ek2";
rectangle_26_ek2.style.left = "21px";
rectangle_26_ek2.style.top = "171px";
rectangle_26_ek2.style.width = "336px";
rectangle_26_ek2.style.height = "35px";
rectangle_26_ek2.style.borderRadius = "22px";
rectangle_26_ek2.style.background = 'rgba(248,248,248,1)';

page_home_ek2.appendChild(rectangle_26_ek2);

var bx_search = document.createElement("div");
bx_search.id = "bx_search";
bx_search.style.width = "24px";
bx_search.style.height = "24px";
bx_search.style.left = "321px";
bx_search.style.top = "176px";
bx_search.style.position = "absolute";
page_home_ek2.appendChild(bx_search);

var vector_ek44 = document.createElement("img");
vector_ek44.id = "vector_ek44";
vector_ek44.style.left = "2px";
vector_ek44.style.top = "2px";
vector_ek44.style.width = "18.71px";
vector_ek44.style.height = "18.71px";
vector_ek44.src = "skins/vector_ek44.png";

bx_search.appendChild(vector_ek44);

var frame_1 = document.createElement("div");
frame_1.id = "frame_1";
frame_1.style.width = "415px";
frame_1.style.height = "514px";
frame_1.style.left = "9px";
frame_1.style.top = "221px";
frame_1.style.position = "absolute";
page_home_ek2.appendChild(frame_1);

var similar_personality = document.createElement("div");
similar_personality.innerHTML = "Similar Personality";
similar_personality.style.textAlign = "left";
similar_personality.id = "similar_personality";
similar_personality.style.left = "14px";
similar_personality.style.top = "0px";
similar_personality.style.width = "137px";
similar_personality.style.height = "30px";
similar_personality.style.fontFamily = "Coda";
similar_personality.style.fontSize = "14px";
similar_personality.style.overflow = "hidden";
similar_personality.style.color = "#000000";

frame_1.appendChild(similar_personality);

var component_1 = document.createElement("div");
component_1.id = "component_1";
component_1.style.width = "411px";
component_1.style.height = "431px";
component_1.style.left = "4px";
component_1.style.top = "19px";
component_1.style.position = "absolute";
frame_1.appendChild(component_1);

var card_1 = document.createElement("div");
card_1.id = "card_1";
card_1.style.width = "296px";
card_1.style.height = "431px";
card_1.style.left = "0px";
card_1.style.top = "0px";
card_1.style.position = "absolute";
component_1.appendChild(card_1);

var pizza_photo_ek1 = document.createElement("div");
pizza_photo_ek1.id = "pizza_photo_ek1";
pizza_photo_ek1.style.left = "0px";
pizza_photo_ek1.style.top = "86px";
pizza_photo_ek1.style.width = "296px";
pizza_photo_ek1.style.height = "216px";
pizza_photo_ek1.style.background = 'rgba(196,196,196,1)';

card_1.appendChild(pizza_photo_ek1);

var ellipse_8 = document.createElement("img");
ellipse_8.id = "ellipse_8";
ellipse_8.style.left = "17px";
ellipse_8.style.top = "22px";
ellipse_8.style.width = "54px";
ellipse_8.style.height = "54px";
ellipse_8.src = "skins/ellipse_8.png";

card_1.appendChild(ellipse_8);

var katharine_momo = document.createElement("div");
katharine_momo.innerHTML = "Katharine Momo";
katharine_momo.style.textAlign = "left";
katharine_momo.id = "katharine_momo";
katharine_momo.style.left = "82px";
katharine_momo.style.top = "38px";
katharine_momo.style.width = "147px";
katharine_momo.style.height = "33px";
katharine_momo.style.fontFamily = "Open Sans";
katharine_momo.style.fontSize = "16px";
katharine_momo.style.overflow = "hidden";
katharine_momo.style.color = "#000000";

card_1.appendChild(katharine_momo);

var compactible = document.createElement("div");
compactible.id = "compactible";
compactible.style.width = "48px";
compactible.style.height = "48px";
compactible.style.left = "235px";
compactible.style.top = "232px";
compactible.style.position = "absolute";
card_1.appendChild(compactible);

var ellipse_12 = document.createElement("div");
ellipse_12.id = "ellipse_12";
ellipse_12.style.left = "0px";
ellipse_12.style.top = "0px";
ellipse_12.style.width = "48px";
ellipse_12.style.height = "48px";
ellipse_12.style.borderRadius = "24px / 24px";
ellipse_12.style.background = 'rgba(217,217,217,1)';

compactible.appendChild(ellipse_12);

var ellipse_13 = document.createElement("img");
ellipse_13.id = "ellipse_13";
ellipse_13.style.left = "0px";
ellipse_13.style.top = "0px";
ellipse_13.style.width = "48px";
ellipse_13.style.height = "48px";
ellipse_13.src = "skins/ellipse_13.png";

compactible.appendChild(ellipse_13);

var _80_ = document.createElement("div");
_80_.innerHTML = "80%";
_80_.style.textAlign = "left";
_80_.id = "_80_";
_80_.style.left = "13px";
_80_.style.top = "17px";
_80_.style.width = "52px";
_80_.style.height = "23px";
_80_.style.fontFamily = "Poppins";
_80_.style.fontSize = "12px";
_80_.style.overflow = "hidden";
_80_.style.color = "#CB5A7A";

compactible.appendChild(_80_);

var katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month = document.createElement("div");
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month.innerHTML = "Katharine Momo    Female    29<br/>Plot 45, Herbert Macaulay way, Wuse<br/><br/>Budget <br/>#350,000/Month";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month.style.textAlign = "left";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month.id = "katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month.style.left = "17px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month.style.top = "309px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month.style.width = "231px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month.style.height = "98px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month.style.fontFamily = "Poppins";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month.style.fontSize = "12px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month.style.overflow = "hidden";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month.style.color = "#000000";

card_1.appendChild(katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month);

var akar_icons_heart = document.createElement("div");
akar_icons_heart.id = "akar_icons_heart";
akar_icons_heart.style.width = "24px";
akar_icons_heart.style.height = "24px";
akar_icons_heart.style.left = "261px";
akar_icons_heart.style.top = "307px";
akar_icons_heart.style.position = "absolute";
card_1.appendChild(akar_icons_heart);

var vector_ek45 = document.createElement("img");
vector_ek45.id = "vector_ek45";
vector_ek45.style.left = "2px";
vector_ek45.style.top = "3px";
vector_ek45.style.width = "20px";
vector_ek45.style.height = "17.83px";
vector_ek45.src = "skins/vector_ek45.png";

akar_icons_heart.appendChild(vector_ek45);

var ic_round_verified_user = document.createElement("div");
ic_round_verified_user.id = "ic_round_verified_user";
ic_round_verified_user.style.width = "24px";
ic_round_verified_user.style.height = "24px";
ic_round_verified_user.style.left = "10px";
ic_round_verified_user.style.top = "402px";
ic_round_verified_user.style.position = "absolute";
card_1.appendChild(ic_round_verified_user);

var vector_ek46 = document.createElement("img");
vector_ek46.id = "vector_ek46";
vector_ek46.style.left = "3px";
vector_ek46.style.top = "1.19px";
vector_ek46.style.width = "18px";
vector_ek46.style.height = "21.81px";
vector_ek46.src = "skins/vector_ek46.png";

ic_round_verified_user.appendChild(vector_ek46);

var verified_user = document.createElement("div");
verified_user.innerHTML = "Verified User";
verified_user.style.textAlign = "left";
verified_user.id = "verified_user";
verified_user.style.left = "41px";
verified_user.style.top = "405px";
verified_user.style.width = "90px";
verified_user.style.height = "26px";
verified_user.style.fontFamily = "Poppins";
verified_user.style.fontSize = "12px";
verified_user.style.overflow = "hidden";
verified_user.style.color = "#000000";

card_1.appendChild(verified_user);

var card_2 = document.createElement("div");
card_2.id = "card_2";
card_2.style.width = "296px";
card_2.style.height = "431px";
card_2.style.left = "340px";
card_2.style.top = "0px";
card_2.style.position = "absolute";
component_1.appendChild(card_2);

var pizza_photo_ek2 = document.createElement("img");
pizza_photo_ek2.id = "pizza_photo_ek2";
pizza_photo_ek2.style.left = "0px";
pizza_photo_ek2.style.top = "86px";
pizza_photo_ek2.style.width = "296px";
pizza_photo_ek2.style.height = "216px";
pizza_photo_ek2.src = "skins/pizza_photo_ek2.png";

card_2.appendChild(pizza_photo_ek2);

var ellipse_8_ek1 = document.createElement("img");
ellipse_8_ek1.id = "ellipse_8_ek1";
ellipse_8_ek1.style.left = "17px";
ellipse_8_ek1.style.top = "22px";
ellipse_8_ek1.style.width = "54px";
ellipse_8_ek1.style.height = "54px";
ellipse_8_ek1.src = "skins/ellipse_8_ek1.png";

card_2.appendChild(ellipse_8_ek1);

var katharine_momo_ek1 = document.createElement("div");
katharine_momo_ek1.innerHTML = "Moses Simon";
katharine_momo_ek1.style.textAlign = "left";
katharine_momo_ek1.id = "katharine_momo_ek1";
katharine_momo_ek1.style.left = "82px";
katharine_momo_ek1.style.top = "38px";
katharine_momo_ek1.style.width = "121px";
katharine_momo_ek1.style.height = "33px";
katharine_momo_ek1.style.fontFamily = "Open Sans";
katharine_momo_ek1.style.fontSize = "16px";
katharine_momo_ek1.style.overflow = "hidden";
katharine_momo_ek1.style.color = "#000000";

card_2.appendChild(katharine_momo_ek1);

var compactible_ek1 = document.createElement("div");
compactible_ek1.id = "compactible_ek1";
compactible_ek1.style.width = "48px";
compactible_ek1.style.height = "48px";
compactible_ek1.style.left = "235px";
compactible_ek1.style.top = "232px";
compactible_ek1.style.position = "absolute";
card_2.appendChild(compactible_ek1);

var ellipse_12_ek1 = document.createElement("div");
ellipse_12_ek1.id = "ellipse_12_ek1";
ellipse_12_ek1.style.left = "0px";
ellipse_12_ek1.style.top = "0px";
ellipse_12_ek1.style.width = "48px";
ellipse_12_ek1.style.height = "48px";
ellipse_12_ek1.style.borderRadius = "24px / 24px";
ellipse_12_ek1.style.background = 'rgba(217,217,217,1)';

compactible_ek1.appendChild(ellipse_12_ek1);

var ellipse_13_ek1 = document.createElement("img");
ellipse_13_ek1.id = "ellipse_13_ek1";
ellipse_13_ek1.style.left = "0px";
ellipse_13_ek1.style.top = "0px";
ellipse_13_ek1.style.width = "48px";
ellipse_13_ek1.style.height = "48px";
ellipse_13_ek1.src = "skins/ellipse_13_ek1.png";

compactible_ek1.appendChild(ellipse_13_ek1);

var _80__ek1 = document.createElement("div");
_80__ek1.innerHTML = "70%";
_80__ek1.style.textAlign = "left";
_80__ek1.id = "_80__ek1";
_80__ek1.style.left = "13px";
_80__ek1.style.top = "17px";
_80__ek1.style.width = "52px";
_80__ek1.style.height = "23px";
_80__ek1.style.fontFamily = "Poppins";
_80__ek1.style.fontSize = "12px";
_80__ek1.style.overflow = "hidden";
_80__ek1.style.color = "#CB5A7A";

compactible_ek1.appendChild(_80__ek1);

var katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1 = document.createElement("div");
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1.innerHTML = "Moses Simon    male    23<br/>KM 63 Lagos Ibadan Expressway,Mowe<br/><br/>Budget <br/>#250,000/Month";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1.style.textAlign = "left";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1.id = "katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1.style.left = "17px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1.style.top = "309px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1.style.width = "242px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1.style.height = "98px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1.style.fontFamily = "Poppins";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1.style.fontSize = "12px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1.style.overflow = "hidden";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1.style.color = "#000000";

card_2.appendChild(katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek1);

var akar_icons_heart_ek1 = document.createElement("div");
akar_icons_heart_ek1.id = "akar_icons_heart_ek1";
akar_icons_heart_ek1.style.width = "24px";
akar_icons_heart_ek1.style.height = "24px";
akar_icons_heart_ek1.style.left = "261px";
akar_icons_heart_ek1.style.top = "307px";
akar_icons_heart_ek1.style.position = "absolute";
card_2.appendChild(akar_icons_heart_ek1);

var vector_ek47 = document.createElement("img");
vector_ek47.id = "vector_ek47";
vector_ek47.style.left = "2px";
vector_ek47.style.top = "3px";
vector_ek47.style.width = "20px";
vector_ek47.style.height = "17.83px";
vector_ek47.src = "skins/vector_ek47.png";

akar_icons_heart_ek1.appendChild(vector_ek47);

var ic_round_verified_user_ek1 = document.createElement("div");
ic_round_verified_user_ek1.id = "ic_round_verified_user_ek1";
ic_round_verified_user_ek1.style.width = "24px";
ic_round_verified_user_ek1.style.height = "24px";
ic_round_verified_user_ek1.style.left = "10px";
ic_round_verified_user_ek1.style.top = "402px";
ic_round_verified_user_ek1.style.position = "absolute";
card_2.appendChild(ic_round_verified_user_ek1);

var vector_ek48 = document.createElement("img");
vector_ek48.id = "vector_ek48";
vector_ek48.style.left = "3px";
vector_ek48.style.top = "1.19px";
vector_ek48.style.width = "18px";
vector_ek48.style.height = "21.81px";
vector_ek48.src = "skins/vector_ek48.png";

ic_round_verified_user_ek1.appendChild(vector_ek48);

var verified_user_ek1 = document.createElement("div");
verified_user_ek1.innerHTML = "Verified User";
verified_user_ek1.style.textAlign = "left";
verified_user_ek1.id = "verified_user_ek1";
verified_user_ek1.style.left = "41px";
verified_user_ek1.style.top = "405px";
verified_user_ek1.style.width = "90px";
verified_user_ek1.style.height = "26px";
verified_user_ek1.style.fontFamily = "Poppins";
verified_user_ek1.style.fontSize = "12px";
verified_user_ek1.style.overflow = "hidden";
verified_user_ek1.style.color = "#000000";

card_2.appendChild(verified_user_ek1);

var card_3 = document.createElement("div");
card_3.id = "card_3";
card_3.style.width = "296px";
card_3.style.height = "431px";
card_3.style.left = "680px";
card_3.style.top = "0px";
card_3.style.position = "absolute";
component_1.appendChild(card_3);

var pizza_photo_ek3 = document.createElement("img");
pizza_photo_ek3.id = "pizza_photo_ek3";
pizza_photo_ek3.style.left = "0px";
pizza_photo_ek3.style.top = "86px";
pizza_photo_ek3.style.width = "296px";
pizza_photo_ek3.style.height = "216px";
pizza_photo_ek3.src = "skins/pizza_photo_ek3.png";

card_3.appendChild(pizza_photo_ek3);

var ellipse_8_ek2 = document.createElement("img");
ellipse_8_ek2.id = "ellipse_8_ek2";
ellipse_8_ek2.style.left = "17px";
ellipse_8_ek2.style.top = "22px";
ellipse_8_ek2.style.width = "54px";
ellipse_8_ek2.style.height = "54px";
ellipse_8_ek2.src = "skins/ellipse_8_ek2.png";

card_3.appendChild(ellipse_8_ek2);

var katharine_momo_ek2 = document.createElement("div");
katharine_momo_ek2.innerHTML = "Francis Akpofure";
katharine_momo_ek2.style.textAlign = "left";
katharine_momo_ek2.id = "katharine_momo_ek2";
katharine_momo_ek2.style.left = "82px";
katharine_momo_ek2.style.top = "38px";
katharine_momo_ek2.style.width = "147px";
katharine_momo_ek2.style.height = "33px";
katharine_momo_ek2.style.fontFamily = "Open Sans";
katharine_momo_ek2.style.fontSize = "16px";
katharine_momo_ek2.style.overflow = "hidden";
katharine_momo_ek2.style.color = "#000000";

card_3.appendChild(katharine_momo_ek2);

var compactible_ek2 = document.createElement("div");
compactible_ek2.id = "compactible_ek2";
compactible_ek2.style.width = "48px";
compactible_ek2.style.height = "48px";
compactible_ek2.style.left = "235px";
compactible_ek2.style.top = "232px";
compactible_ek2.style.position = "absolute";
card_3.appendChild(compactible_ek2);

var ellipse_12_ek2 = document.createElement("div");
ellipse_12_ek2.id = "ellipse_12_ek2";
ellipse_12_ek2.style.left = "0px";
ellipse_12_ek2.style.top = "0px";
ellipse_12_ek2.style.width = "48px";
ellipse_12_ek2.style.height = "48px";
ellipse_12_ek2.style.borderRadius = "24px / 24px";
ellipse_12_ek2.style.background = 'rgba(217,217,217,1)';

compactible_ek2.appendChild(ellipse_12_ek2);

var ellipse_13_ek2 = document.createElement("img");
ellipse_13_ek2.id = "ellipse_13_ek2";
ellipse_13_ek2.style.left = "0px";
ellipse_13_ek2.style.top = "0px";
ellipse_13_ek2.style.width = "48px";
ellipse_13_ek2.style.height = "48px";
ellipse_13_ek2.src = "skins/ellipse_13_ek2.png";

compactible_ek2.appendChild(ellipse_13_ek2);

var _80__ek2 = document.createElement("div");
_80__ek2.innerHTML = "90%";
_80__ek2.style.textAlign = "left";
_80__ek2.id = "_80__ek2";
_80__ek2.style.left = "13px";
_80__ek2.style.top = "17px";
_80__ek2.style.width = "52px";
_80__ek2.style.height = "23px";
_80__ek2.style.fontFamily = "Poppins";
_80__ek2.style.fontSize = "12px";
_80__ek2.style.overflow = "hidden";
_80__ek2.style.color = "#CB5A7A";

compactible_ek2.appendChild(_80__ek2);

var katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2 = document.createElement("div");
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2.innerHTML = "Francis Akpofure    male    27<br/>Plot 42 Phase 2 Site 2 Kubwa<br/><br/>Budget <br/>#650,000/Month";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2.style.textAlign = "left";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2.id = "katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2.style.left = "17px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2.style.top = "309px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2.style.width = "189px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2.style.height = "98px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2.style.fontFamily = "Poppins";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2.style.fontSize = "12px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2.style.overflow = "hidden";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2.style.color = "#000000";

card_3.appendChild(katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek2);

var akar_icons_heart_ek2 = document.createElement("div");
akar_icons_heart_ek2.id = "akar_icons_heart_ek2";
akar_icons_heart_ek2.style.width = "24px";
akar_icons_heart_ek2.style.height = "24px";
akar_icons_heart_ek2.style.left = "261px";
akar_icons_heart_ek2.style.top = "307px";
akar_icons_heart_ek2.style.position = "absolute";
card_3.appendChild(akar_icons_heart_ek2);

var vector_ek49 = document.createElement("img");
vector_ek49.id = "vector_ek49";
vector_ek49.style.left = "2px";
vector_ek49.style.top = "3px";
vector_ek49.style.width = "20px";
vector_ek49.style.height = "17.83px";
vector_ek49.src = "skins/vector_ek49.png";

akar_icons_heart_ek2.appendChild(vector_ek49);

var ic_round_verified_user_ek2 = document.createElement("div");
ic_round_verified_user_ek2.id = "ic_round_verified_user_ek2";
ic_round_verified_user_ek2.style.width = "24px";
ic_round_verified_user_ek2.style.height = "24px";
ic_round_verified_user_ek2.style.left = "10px";
ic_round_verified_user_ek2.style.top = "402px";
ic_round_verified_user_ek2.style.position = "absolute";
card_3.appendChild(ic_round_verified_user_ek2);

var vector_ek50 = document.createElement("img");
vector_ek50.id = "vector_ek50";
vector_ek50.style.left = "3px";
vector_ek50.style.top = "1.19px";
vector_ek50.style.width = "18px";
vector_ek50.style.height = "21.81px";
vector_ek50.src = "skins/vector_ek50.png";

ic_round_verified_user_ek2.appendChild(vector_ek50);

var verified_user_ek2 = document.createElement("div");
verified_user_ek2.innerHTML = "Verified User";
verified_user_ek2.style.textAlign = "left";
verified_user_ek2.id = "verified_user_ek2";
verified_user_ek2.style.left = "41px";
verified_user_ek2.style.top = "405px";
verified_user_ek2.style.width = "90px";
verified_user_ek2.style.height = "26px";
verified_user_ek2.style.fontFamily = "Poppins";
verified_user_ek2.style.fontSize = "12px";
verified_user_ek2.style.overflow = "hidden";
verified_user_ek2.style.color = "#000000";

card_3.appendChild(verified_user_ek2);

var similar_hobbies = document.createElement("div");
similar_hobbies.innerHTML = "Similar Hobbies";
similar_hobbies.style.textAlign = "left";
similar_hobbies.id = "similar_hobbies";
similar_hobbies.style.left = "15px";
similar_hobbies.style.top = "450px";
similar_hobbies.style.width = "118px";
similar_hobbies.style.height = "30px";
similar_hobbies.style.fontFamily = "Coda";
similar_hobbies.style.fontSize = "14px";
similar_hobbies.style.overflow = "hidden";
similar_hobbies.style.color = "#000000";

frame_1.appendChild(similar_hobbies);

var component_2 = document.createElement("div");
component_2.id = "component_2";
component_2.style.width = "411px";
component_2.style.height = "51px";
component_2.style.left = "0px";
component_2.style.top = "465px";
component_2.style.position = "absolute";
frame_1.appendChild(component_2);

var card_1_ek1 = document.createElement("div");
card_1_ek1.id = "card_1_ek1";
card_1_ek1.style.width = "296px";
card_1_ek1.style.height = "431px";
card_1_ek1.style.left = "0px";
card_1_ek1.style.top = "0px";
card_1_ek1.style.position = "absolute";
component_2.appendChild(card_1_ek1);

var pizza_photo_ek4 = document.createElement("img");
pizza_photo_ek4.id = "pizza_photo_ek4";
pizza_photo_ek4.style.left = "0px";
pizza_photo_ek4.style.top = "86px";
pizza_photo_ek4.style.width = "296px";
pizza_photo_ek4.style.height = "216px";
pizza_photo_ek4.src = "skins/pizza_photo_ek4.png";

card_1_ek1.appendChild(pizza_photo_ek4);

var ellipse_8_ek3 = document.createElement("img");
ellipse_8_ek3.id = "ellipse_8_ek3";
ellipse_8_ek3.style.left = "17px";
ellipse_8_ek3.style.top = "22px";
ellipse_8_ek3.style.width = "54px";
ellipse_8_ek3.style.height = "54px";
ellipse_8_ek3.src = "skins/ellipse_8_ek3.png";

card_1_ek1.appendChild(ellipse_8_ek3);

var katharine_momo_ek3 = document.createElement("div");
katharine_momo_ek3.innerHTML = "Asuquo Blessing";
katharine_momo_ek3.style.textAlign = "left";
katharine_momo_ek3.id = "katharine_momo_ek3";
katharine_momo_ek3.style.left = "82px";
katharine_momo_ek3.style.top = "38px";
katharine_momo_ek3.style.width = "144px";
katharine_momo_ek3.style.height = "33px";
katharine_momo_ek3.style.fontFamily = "Open Sans";
katharine_momo_ek3.style.fontSize = "16px";
katharine_momo_ek3.style.overflow = "hidden";
katharine_momo_ek3.style.color = "#000000";

card_1_ek1.appendChild(katharine_momo_ek3);

var compactible_ek3 = document.createElement("div");
compactible_ek3.id = "compactible_ek3";
compactible_ek3.style.width = "48px";
compactible_ek3.style.height = "48px";
compactible_ek3.style.left = "235px";
compactible_ek3.style.top = "232px";
compactible_ek3.style.position = "absolute";
card_1_ek1.appendChild(compactible_ek3);

var ellipse_12_ek3 = document.createElement("div");
ellipse_12_ek3.id = "ellipse_12_ek3";
ellipse_12_ek3.style.left = "0px";
ellipse_12_ek3.style.top = "0px";
ellipse_12_ek3.style.width = "48px";
ellipse_12_ek3.style.height = "48px";
ellipse_12_ek3.style.borderRadius = "24px / 24px";
ellipse_12_ek3.style.background = 'rgba(217,217,217,1)';

compactible_ek3.appendChild(ellipse_12_ek3);

var ellipse_13_ek3 = document.createElement("img");
ellipse_13_ek3.id = "ellipse_13_ek3";
ellipse_13_ek3.style.left = "0px";
ellipse_13_ek3.style.top = "0px";
ellipse_13_ek3.style.width = "48px";
ellipse_13_ek3.style.height = "48px";
ellipse_13_ek3.src = "skins/ellipse_13_ek3.png";

compactible_ek3.appendChild(ellipse_13_ek3);

var _80__ek3 = document.createElement("div");
_80__ek3.innerHTML = "80%";
_80__ek3.style.textAlign = "left";
_80__ek3.id = "_80__ek3";
_80__ek3.style.left = "13px";
_80__ek3.style.top = "17px";
_80__ek3.style.width = "52px";
_80__ek3.style.height = "23px";
_80__ek3.style.fontFamily = "Poppins";
_80__ek3.style.fontSize = "12px";
_80__ek3.style.overflow = "hidden";
_80__ek3.style.color = "#CB5A7A";

compactible_ek3.appendChild(_80__ek3);

var katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3 = document.createElement("div");
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3.innerHTML = "Asuquo Blessing    Female    26<br/>Block 2 Flat 7 Gwadalada, Abuja<br/><br/>Budget <br/>#550,000/Month";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3.style.textAlign = "left";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3.id = "katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3.style.left = "17px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3.style.top = "309px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3.style.width = "203px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3.style.height = "98px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3.style.fontFamily = "Poppins";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3.style.fontSize = "12px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3.style.overflow = "hidden";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3.style.color = "#000000";

card_1_ek1.appendChild(katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek3);

var akar_icons_heart_ek3 = document.createElement("div");
akar_icons_heart_ek3.id = "akar_icons_heart_ek3";
akar_icons_heart_ek3.style.width = "24px";
akar_icons_heart_ek3.style.height = "24px";
akar_icons_heart_ek3.style.left = "261px";
akar_icons_heart_ek3.style.top = "307px";
akar_icons_heart_ek3.style.position = "absolute";
card_1_ek1.appendChild(akar_icons_heart_ek3);

var vector_ek51 = document.createElement("img");
vector_ek51.id = "vector_ek51";
vector_ek51.style.left = "2px";
vector_ek51.style.top = "3px";
vector_ek51.style.width = "20px";
vector_ek51.style.height = "17.83px";
vector_ek51.src = "skins/vector_ek51.png";

akar_icons_heart_ek3.appendChild(vector_ek51);

var ic_round_verified_user_ek3 = document.createElement("div");
ic_round_verified_user_ek3.id = "ic_round_verified_user_ek3";
ic_round_verified_user_ek3.style.width = "24px";
ic_round_verified_user_ek3.style.height = "24px";
ic_round_verified_user_ek3.style.left = "10px";
ic_round_verified_user_ek3.style.top = "402px";
ic_round_verified_user_ek3.style.position = "absolute";
card_1_ek1.appendChild(ic_round_verified_user_ek3);

var vector_ek52 = document.createElement("img");
vector_ek52.id = "vector_ek52";
vector_ek52.style.left = "3px";
vector_ek52.style.top = "1.19px";
vector_ek52.style.width = "18px";
vector_ek52.style.height = "21.81px";
vector_ek52.src = "skins/vector_ek52.png";

ic_round_verified_user_ek3.appendChild(vector_ek52);

var verified_user_ek3 = document.createElement("div");
verified_user_ek3.innerHTML = "Verified User";
verified_user_ek3.style.textAlign = "left";
verified_user_ek3.id = "verified_user_ek3";
verified_user_ek3.style.left = "41px";
verified_user_ek3.style.top = "405px";
verified_user_ek3.style.width = "90px";
verified_user_ek3.style.height = "26px";
verified_user_ek3.style.fontFamily = "Poppins";
verified_user_ek3.style.fontSize = "12px";
verified_user_ek3.style.overflow = "hidden";
verified_user_ek3.style.color = "#000000";

card_1_ek1.appendChild(verified_user_ek3);

var card_2_ek1 = document.createElement("div");
card_2_ek1.id = "card_2_ek1";
card_2_ek1.style.width = "296px";
card_2_ek1.style.height = "431px";
card_2_ek1.style.left = "340px";
card_2_ek1.style.top = "0px";
card_2_ek1.style.position = "absolute";
component_2.appendChild(card_2_ek1);

var pizza_photo_ek5 = document.createElement("img");
pizza_photo_ek5.id = "pizza_photo_ek5";
pizza_photo_ek5.style.left = "0px";
pizza_photo_ek5.style.top = "86px";
pizza_photo_ek5.style.width = "296px";
pizza_photo_ek5.style.height = "216px";
pizza_photo_ek5.src = "skins/pizza_photo_ek5.png";

card_2_ek1.appendChild(pizza_photo_ek5);

var ellipse_8_ek4 = document.createElement("img");
ellipse_8_ek4.id = "ellipse_8_ek4";
ellipse_8_ek4.style.left = "17px";
ellipse_8_ek4.style.top = "22px";
ellipse_8_ek4.style.width = "54px";
ellipse_8_ek4.style.height = "54px";
ellipse_8_ek4.src = "skins/ellipse_8_ek4.png";

card_2_ek1.appendChild(ellipse_8_ek4);

var katharine_momo_ek4 = document.createElement("div");
katharine_momo_ek4.innerHTML = "Samantha";
katharine_momo_ek4.style.textAlign = "left";
katharine_momo_ek4.id = "katharine_momo_ek4";
katharine_momo_ek4.style.left = "82px";
katharine_momo_ek4.style.top = "38px";
katharine_momo_ek4.style.width = "97px";
katharine_momo_ek4.style.height = "33px";
katharine_momo_ek4.style.fontFamily = "Open Sans";
katharine_momo_ek4.style.fontSize = "16px";
katharine_momo_ek4.style.overflow = "hidden";
katharine_momo_ek4.style.color = "#000000";

card_2_ek1.appendChild(katharine_momo_ek4);

var compactible_ek4 = document.createElement("div");
compactible_ek4.id = "compactible_ek4";
compactible_ek4.style.width = "48px";
compactible_ek4.style.height = "48px";
compactible_ek4.style.left = "235px";
compactible_ek4.style.top = "232px";
compactible_ek4.style.position = "absolute";
card_2_ek1.appendChild(compactible_ek4);

var ellipse_12_ek4 = document.createElement("div");
ellipse_12_ek4.id = "ellipse_12_ek4";
ellipse_12_ek4.style.left = "0px";
ellipse_12_ek4.style.top = "0px";
ellipse_12_ek4.style.width = "48px";
ellipse_12_ek4.style.height = "48px";
ellipse_12_ek4.style.borderRadius = "24px / 24px";
ellipse_12_ek4.style.background = 'rgba(217,217,217,1)';

compactible_ek4.appendChild(ellipse_12_ek4);

var ellipse_13_ek4 = document.createElement("img");
ellipse_13_ek4.id = "ellipse_13_ek4";
ellipse_13_ek4.style.left = "0px";
ellipse_13_ek4.style.top = "0px";
ellipse_13_ek4.style.width = "48px";
ellipse_13_ek4.style.height = "48px";
ellipse_13_ek4.src = "skins/ellipse_13_ek4.png";

compactible_ek4.appendChild(ellipse_13_ek4);

var _80__ek4 = document.createElement("div");
_80__ek4.innerHTML = "70%";
_80__ek4.style.textAlign = "left";
_80__ek4.id = "_80__ek4";
_80__ek4.style.left = "13px";
_80__ek4.style.top = "17px";
_80__ek4.style.width = "52px";
_80__ek4.style.height = "23px";
_80__ek4.style.fontFamily = "Poppins";
_80__ek4.style.fontSize = "12px";
_80__ek4.style.overflow = "hidden";
_80__ek4.style.color = "#CB5A7A";

compactible_ek4.appendChild(_80__ek4);

var katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4 = document.createElement("div");
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4.innerHTML = "Samantha   Female    23<br/>6th Avenue Gwarimpa Estate<br/><br/>Budget <br/>#750,000/Month";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4.style.textAlign = "left";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4.id = "katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4.style.left = "17px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4.style.top = "309px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4.style.width = "189px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4.style.height = "98px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4.style.fontFamily = "Poppins";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4.style.fontSize = "12px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4.style.overflow = "hidden";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4.style.color = "#000000";

card_2_ek1.appendChild(katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek4);

var akar_icons_heart_ek4 = document.createElement("div");
akar_icons_heart_ek4.id = "akar_icons_heart_ek4";
akar_icons_heart_ek4.style.width = "24px";
akar_icons_heart_ek4.style.height = "24px";
akar_icons_heart_ek4.style.left = "261px";
akar_icons_heart_ek4.style.top = "307px";
akar_icons_heart_ek4.style.position = "absolute";
card_2_ek1.appendChild(akar_icons_heart_ek4);

var vector_ek53 = document.createElement("img");
vector_ek53.id = "vector_ek53";
vector_ek53.style.left = "2px";
vector_ek53.style.top = "3px";
vector_ek53.style.width = "20px";
vector_ek53.style.height = "17.83px";
vector_ek53.src = "skins/vector_ek53.png";

akar_icons_heart_ek4.appendChild(vector_ek53);

var ic_round_verified_user_ek4 = document.createElement("div");
ic_round_verified_user_ek4.id = "ic_round_verified_user_ek4";
ic_round_verified_user_ek4.style.width = "24px";
ic_round_verified_user_ek4.style.height = "24px";
ic_round_verified_user_ek4.style.left = "10px";
ic_round_verified_user_ek4.style.top = "402px";
ic_round_verified_user_ek4.style.position = "absolute";
card_2_ek1.appendChild(ic_round_verified_user_ek4);

var vector_ek54 = document.createElement("img");
vector_ek54.id = "vector_ek54";
vector_ek54.style.left = "3px";
vector_ek54.style.top = "1.19px";
vector_ek54.style.width = "18px";
vector_ek54.style.height = "21.81px";
vector_ek54.src = "skins/vector_ek54.png";

ic_round_verified_user_ek4.appendChild(vector_ek54);

var verified_user_ek4 = document.createElement("div");
verified_user_ek4.innerHTML = "Verified User";
verified_user_ek4.style.textAlign = "left";
verified_user_ek4.id = "verified_user_ek4";
verified_user_ek4.style.left = "41px";
verified_user_ek4.style.top = "405px";
verified_user_ek4.style.width = "90px";
verified_user_ek4.style.height = "26px";
verified_user_ek4.style.fontFamily = "Poppins";
verified_user_ek4.style.fontSize = "12px";
verified_user_ek4.style.overflow = "hidden";
verified_user_ek4.style.color = "#000000";

card_2_ek1.appendChild(verified_user_ek4);

var card_3_ek1 = document.createElement("div");
card_3_ek1.id = "card_3_ek1";
card_3_ek1.style.width = "296px";
card_3_ek1.style.height = "431px";
card_3_ek1.style.left = "680px";
card_3_ek1.style.top = "0px";
card_3_ek1.style.position = "absolute";
component_2.appendChild(card_3_ek1);

var pizza_photo_ek6 = document.createElement("img");
pizza_photo_ek6.id = "pizza_photo_ek6";
pizza_photo_ek6.style.left = "0px";
pizza_photo_ek6.style.top = "86px";
pizza_photo_ek6.style.width = "296px";
pizza_photo_ek6.style.height = "216px";
pizza_photo_ek6.src = "skins/pizza_photo_ek6.png";

card_3_ek1.appendChild(pizza_photo_ek6);

var ellipse_8_ek5 = document.createElement("img");
ellipse_8_ek5.id = "ellipse_8_ek5";
ellipse_8_ek5.style.left = "17px";
ellipse_8_ek5.style.top = "22px";
ellipse_8_ek5.style.width = "54px";
ellipse_8_ek5.style.height = "54px";
ellipse_8_ek5.src = "skins/ellipse_8_ek5.png";

card_3_ek1.appendChild(ellipse_8_ek5);

var katharine_momo_ek5 = document.createElement("div");
katharine_momo_ek5.innerHTML = "Ahmed Usman";
katharine_momo_ek5.style.textAlign = "left";
katharine_momo_ek5.id = "katharine_momo_ek5";
katharine_momo_ek5.style.left = "82px";
katharine_momo_ek5.style.top = "38px";
katharine_momo_ek5.style.width = "132px";
katharine_momo_ek5.style.height = "33px";
katharine_momo_ek5.style.fontFamily = "Open Sans";
katharine_momo_ek5.style.fontSize = "16px";
katharine_momo_ek5.style.overflow = "hidden";
katharine_momo_ek5.style.color = "#000000";

card_3_ek1.appendChild(katharine_momo_ek5);

var compactible_ek5 = document.createElement("div");
compactible_ek5.id = "compactible_ek5";
compactible_ek5.style.width = "48px";
compactible_ek5.style.height = "48px";
compactible_ek5.style.left = "235px";
compactible_ek5.style.top = "232px";
compactible_ek5.style.position = "absolute";
card_3_ek1.appendChild(compactible_ek5);

var ellipse_12_ek5 = document.createElement("div");
ellipse_12_ek5.id = "ellipse_12_ek5";
ellipse_12_ek5.style.left = "0px";
ellipse_12_ek5.style.top = "0px";
ellipse_12_ek5.style.width = "48px";
ellipse_12_ek5.style.height = "48px";
ellipse_12_ek5.style.borderRadius = "24px / 24px";
ellipse_12_ek5.style.background = 'rgba(217,217,217,1)';

compactible_ek5.appendChild(ellipse_12_ek5);

var ellipse_13_ek5 = document.createElement("img");
ellipse_13_ek5.id = "ellipse_13_ek5";
ellipse_13_ek5.style.left = "0px";
ellipse_13_ek5.style.top = "0px";
ellipse_13_ek5.style.width = "48px";
ellipse_13_ek5.style.height = "48px";
ellipse_13_ek5.src = "skins/ellipse_13_ek5.png";

compactible_ek5.appendChild(ellipse_13_ek5);

var _80__ek5 = document.createElement("div");
_80__ek5.innerHTML = "90%";
_80__ek5.style.textAlign = "left";
_80__ek5.id = "_80__ek5";
_80__ek5.style.left = "13px";
_80__ek5.style.top = "17px";
_80__ek5.style.width = "52px";
_80__ek5.style.height = "23px";
_80__ek5.style.fontFamily = "Poppins";
_80__ek5.style.fontSize = "12px";
_80__ek5.style.overflow = "hidden";
_80__ek5.style.color = "#CB5A7A";

compactible_ek5.appendChild(_80__ek5);

var katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5 = document.createElement("div");
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5.innerHTML = "Ahmed Usman    male    27<br/>Plot 12 Phase 2 Site 1 Kubwa<br/><br/>Budget <br/>#150,000/Month";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5.style.textAlign = "left";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5.id = "katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5.style.left = "17px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5.style.top = "309px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5.style.width = "177px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5.style.height = "98px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5.style.fontFamily = "Poppins";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5.style.fontSize = "12px";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5.style.overflow = "hidden";
katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5.style.color = "#000000";

card_3_ek1.appendChild(katharine_momo_female_29_plot_45__herbert_macaulay_way__wuse_budget__350_000_month_ek5);

var akar_icons_heart_ek5 = document.createElement("div");
akar_icons_heart_ek5.id = "akar_icons_heart_ek5";
akar_icons_heart_ek5.style.width = "24px";
akar_icons_heart_ek5.style.height = "24px";
akar_icons_heart_ek5.style.left = "261px";
akar_icons_heart_ek5.style.top = "307px";
akar_icons_heart_ek5.style.position = "absolute";
card_3_ek1.appendChild(akar_icons_heart_ek5);

var vector_ek55 = document.createElement("img");
vector_ek55.id = "vector_ek55";
vector_ek55.style.left = "2px";
vector_ek55.style.top = "3px";
vector_ek55.style.width = "20px";
vector_ek55.style.height = "17.83px";
vector_ek55.src = "skins/vector_ek55.png";

akar_icons_heart_ek5.appendChild(vector_ek55);

var ic_round_verified_user_ek5 = document.createElement("div");
ic_round_verified_user_ek5.id = "ic_round_verified_user_ek5";
ic_round_verified_user_ek5.style.width = "24px";
ic_round_verified_user_ek5.style.height = "24px";
ic_round_verified_user_ek5.style.left = "10px";
ic_round_verified_user_ek5.style.top = "402px";
ic_round_verified_user_ek5.style.position = "absolute";
card_3_ek1.appendChild(ic_round_verified_user_ek5);

var vector_ek56 = document.createElement("img");
vector_ek56.id = "vector_ek56";
vector_ek56.style.left = "3px";
vector_ek56.style.top = "1.19px";
vector_ek56.style.width = "18px";
vector_ek56.style.height = "21.81px";
vector_ek56.src = "skins/vector_ek56.png";

ic_round_verified_user_ek5.appendChild(vector_ek56);

var verified_user_ek5 = document.createElement("div");
verified_user_ek5.innerHTML = "Verified User";
verified_user_ek5.style.textAlign = "left";
verified_user_ek5.id = "verified_user_ek5";
verified_user_ek5.style.left = "41px";
verified_user_ek5.style.top = "405px";
verified_user_ek5.style.width = "90px";
verified_user_ek5.style.height = "26px";
verified_user_ek5.style.fontFamily = "Poppins";
verified_user_ek5.style.fontSize = "12px";
verified_user_ek5.style.overflow = "hidden";
verified_user_ek5.style.color = "#000000";

card_3_ek1.appendChild(verified_user_ek5);

var down_ek1 = document.createElement("div");
down_ek1.id = "down_ek1";
down_ek1.style.width = "428px";
down_ek1.style.height = "105px";
down_ek1.style.left = "4px";
down_ek1.style.top = "721px";
down_ek1.style.position = "absolute";
page_home_ek2.appendChild(down_ek1);

var rectangle_3_ek3 = document.createElement("div");
rectangle_3_ek3.id = "rectangle_3_ek3";
rectangle_3_ek3.style.left = "0px";
rectangle_3_ek3.style.opacity = "0.75999999046326";
rectangle_3_ek3.style.filter = "alpha(opacity='75.999999046326')";
rectangle_3_ek3.style.top = "0px";
rectangle_3_ek3.style.width = "428px";
rectangle_3_ek3.style.height = "105px";
rectangle_3_ek3.style.borderRadius = "10px";
rectangle_3_ek3.style.background = 'rgba(253.94,253.94,253.94,0.76)';

down_ek1.appendChild(rectangle_3_ek3);

var vector_ek57 = document.createElement("img");
vector_ek57.id = "vector_ek57";
vector_ek57.style.left = "30.64px";
vector_ek57.style.top = "38px";
vector_ek57.style.width = "29.62px";
vector_ek57.style.height = "29px";
vector_ek57.src = "skins/vector_ek57.png";

down_ek1.appendChild(vector_ek57);

var _vector_ek58 = document.createElement("img");
_vector_ek58.id = "_vector_ek58";
_vector_ek58.style.left = "147.09px";
_vector_ek58.style.top = "38px";
_vector_ek58.style.width = "29.62px";
_vector_ek58.style.height = "29px";
_vector_ek58.src = "skins/_vector_ek58.png";

down_ek1.appendChild(_vector_ek58);

_vector_ek58.style.cursor = "pointer";
_vector_ek58.onclick = (e) => {
	@page_view("search");
}

var vector_ek59 = document.createElement("img");
vector_ek59.id = "vector_ek59";
vector_ek59.style.left = "260.48px";
vector_ek59.style.top = "43px";
vector_ek59.style.width = "29.62px";
vector_ek59.style.height = "29px";
vector_ek59.src = "skins/vector_ek59.png";

down_ek1.appendChild(vector_ek59);

var group_ek8 = document.createElement("div");
group_ek8.id = "group_ek8";
group_ek8.style.width = "29.62px";
group_ek8.style.height = "29px";
group_ek8.style.left = "375px";
group_ek8.style.top = "9px";
group_ek8.style.position = "absolute";
down_ek1.appendChild(group_ek8);

var vector_ek60 = document.createElement("img");
vector_ek60.id = "vector_ek60";
vector_ek60.style.left = "0px";
vector_ek60.style.top = "0px";
vector_ek60.style.width = "29.62px";
vector_ek60.style.height = "29px";
vector_ek60.src = "skins/vector_ek60.png";

group_ek8.appendChild(vector_ek60);

var home_ek4 = document.createElement("div");
home_ek4.innerHTML = "Home";
home_ek4.style.textAlign = "left";
home_ek4.id = "home_ek4";
home_ek4.style.left = "26.56px";
home_ek4.style.top = "72px";
home_ek4.style.width = "61.9px";
home_ek4.style.height = "31px";
home_ek4.style.fontFamily = "Poppins";
home_ek4.style.fontSize = "14px";
home_ek4.style.overflow = "hidden";
home_ek4.style.color = "#CB5A7A";

down_ek1.appendChild(home_ek4);

var search_ek5 = document.createElement("div");
search_ek5.innerHTML = "Search";
search_ek5.style.textAlign = "left";
search_ek5.id = "search_ek5";
search_ek5.style.left = "138.92px";
search_ek5.style.top = "72px";
search_ek5.style.width = "70.07px";
search_ek5.style.height = "31px";
search_ek5.style.fontFamily = "Poppins";
search_ek5.style.fontSize = "14px";
search_ek5.style.overflow = "hidden";
search_ek5.style.color = "#000000";

down_ek1.appendChild(search_ek5);

var saved_ek1 = document.createElement("div");
saved_ek1.innerHTML = "Saved";
saved_ek1.style.textAlign = "left";
saved_ek1.id = "saved_ek1";
saved_ek1.style.left = "253.33px";
saved_ek1.style.top = "72px";
saved_ek1.style.width = "63.95px";
saved_ek1.style.height = "31px";
saved_ek1.style.fontFamily = "Poppins";
saved_ek1.style.fontSize = "14px";
saved_ek1.style.overflow = "hidden";
saved_ek1.style.color = "#000000";

down_ek1.appendChild(saved_ek1);

var account_ek1 = document.createElement("div");
account_ek1.innerHTML = "Account";
account_ek1.style.textAlign = "left";
account_ek1.id = "account_ek1";
account_ek1.style.left = "359.56px";
account_ek1.style.top = "72px";
account_ek1.style.width = "79.27px";
account_ek1.style.height = "31px";
account_ek1.style.fontFamily = "Poppins";
account_ek1.style.fontSize = "14px";
account_ek1.style.overflow = "hidden";
account_ek1.style.color = "#07132A";

down_ek1.appendChild(account_ek1);






