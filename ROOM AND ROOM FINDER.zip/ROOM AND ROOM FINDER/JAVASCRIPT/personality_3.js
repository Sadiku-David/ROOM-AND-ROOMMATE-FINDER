/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);


var page_personality_3_ek1 = document.createElement("div");
page_personality_3_ek1.id = "page_personality_3_ek1";
page_personality_3_ek1.style.width = "428px";
page_personality_3_ek1.style.height = "826px";
page_personality_3_ek1.style.left = "0px";
page_personality_3_ek1.style.top = "0px";
page_personality_3_ek1.style.position = "absolute";
content_container.appendChild(page_personality_3_ek1);

var _bg__personality_3_ek2 = document.createElement("div");
_bg__personality_3_ek2.id = "_bg__personality_3_ek2";
_bg__personality_3_ek2.style.left = "0px";
_bg__personality_3_ek2.style.top = "0px";
_bg__personality_3_ek2.style.width = "428px";
_bg__personality_3_ek2.style.height = "826px";
_bg__personality_3_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_personality_3_ek1.appendChild(_bg__personality_3_ek2);

var rectangle_13_ek2 = document.createElement("div");
rectangle_13_ek2.id = "rectangle_13_ek2";
rectangle_13_ek2.style.left = "22px";
rectangle_13_ek2.style.top = "43px";
rectangle_13_ek2.style.width = "385px";
rectangle_13_ek2.style.height = "7px";
rectangle_13_ek2.style.borderRadius = "7px";
rectangle_13_ek2.style.background = 'rgba(205.2,205.2,205.2,1)';

page_personality_3_ek1.appendChild(rectangle_13_ek2);

var rectangle_14_ek2 = document.createElement("div");
rectangle_14_ek2.id = "rectangle_14_ek2";
rectangle_14_ek2.style.left = "22px";
rectangle_14_ek2.style.top = "43px";
rectangle_14_ek2.style.width = "261px";
rectangle_14_ek2.style.height = "7px";
rectangle_14_ek2.style.borderRadius = "7px";
rectangle_14_ek2.style.background = 'rgba(203,90,122,1)';

page_personality_3_ek1.appendChild(rectangle_14_ek2);

var steps_3_4_personality = document.createElement("div");
steps_3_4_personality.innerHTML = "Steps 3/4 Personality";
steps_3_4_personality.style.textAlign = "left";
steps_3_4_personality.id = "steps_3_4_personality";
steps_3_4_personality.style.left = "22px";
steps_3_4_personality.style.top = "22px";
steps_3_4_personality.style.width = "166px";
steps_3_4_personality.style.height = "31px";
steps_3_4_personality.style.fontFamily = "Poppins";
steps_3_4_personality.style.fontSize = "14px";
steps_3_4_personality.style.overflow = "hidden";
steps_3_4_personality.style.color = "#000000";

page_personality_3_ek1.appendChild(steps_3_4_personality);

var music_ek1 = document.createElement("div");
music_ek1.innerHTML = "Music";
music_ek1.style.textAlign = "left";
music_ek1.id = "music_ek1";
music_ek1.style.left = "51px";
music_ek1.style.top = "125px";
music_ek1.style.width = "45px";
music_ek1.style.height = "22px";
music_ek1.style.fontFamily = "Poppins";
music_ek1.style.fontSize = "10px";
music_ek1.style.overflow = "hidden";
music_ek1.style.color = "#FFFFFF";

page_personality_3_ek1.appendChild(music_ek1);

var music_ek2 = document.createElement("div");
music_ek2.innerHTML = "Music";
music_ek2.style.textAlign = "left";
music_ek2.id = "music_ek2";
music_ek2.style.left = "50px";
music_ek2.style.top = "220px";
music_ek2.style.width = "45px";
music_ek2.style.height = "22px";
music_ek2.style.fontFamily = "Poppins";
music_ek2.style.fontSize = "10px";
music_ek2.style.overflow = "hidden";
music_ek2.style.color = "#FFFFFF";

page_personality_3_ek1.appendChild(music_ek2);

var music_ek3 = document.createElement("div");
music_ek3.innerHTML = "Music";
music_ek3.style.textAlign = "left";
music_ek3.id = "music_ek3";
music_ek3.style.left = "50px";
music_ek3.style.top = "329px";
music_ek3.style.width = "45px";
music_ek3.style.height = "22px";
music_ek3.style.fontFamily = "Poppins";
music_ek3.style.fontSize = "10px";
music_ek3.style.overflow = "hidden";
music_ek3.style.color = "#FFFFFF";

page_personality_3_ek1.appendChild(music_ek3);

var music_ek4 = document.createElement("div");
music_ek4.innerHTML = "Music";
music_ek4.style.textAlign = "left";
music_ek4.id = "music_ek4";
music_ek4.style.left = "50px";
music_ek4.style.top = "431px";
music_ek4.style.width = "45px";
music_ek4.style.height = "22px";
music_ek4.style.fontFamily = "Poppins";
music_ek4.style.fontSize = "10px";
music_ek4.style.overflow = "hidden";
music_ek4.style.color = "#FFFFFF";

page_personality_3_ek1.appendChild(music_ek4);

var music_ek5 = document.createElement("div");
music_ek5.innerHTML = "Music";
music_ek5.style.textAlign = "left";
music_ek5.id = "music_ek5";
music_ek5.style.left = "50px";
music_ek5.style.top = "533px";
music_ek5.style.width = "45px";
music_ek5.style.height = "22px";
music_ek5.style.fontFamily = "Poppins";
music_ek5.style.fontSize = "10px";
music_ek5.style.overflow = "hidden";
music_ek5.style.color = "#FFFFFF";

page_personality_3_ek1.appendChild(music_ek5);

var music_ek6 = document.createElement("div");
music_ek6.innerHTML = "Music";
music_ek6.style.textAlign = "left";
music_ek6.id = "music_ek6";
music_ek6.style.left = "50px";
music_ek6.style.top = "635px";
music_ek6.style.width = "45px";
music_ek6.style.height = "22px";
music_ek6.style.fontFamily = "Poppins";
music_ek6.style.fontSize = "10px";
music_ek6.style.overflow = "hidden";
music_ek6.style.color = "#FFFFFF";

page_personality_3_ek1.appendChild(music_ek6);

var music_ek7 = document.createElement("div");
music_ek7.innerHTML = "Music";
music_ek7.style.textAlign = "left";
music_ek7.id = "music_ek7";
music_ek7.style.left = "50px";
music_ek7.style.top = "737px";
music_ek7.style.width = "45px";
music_ek7.style.height = "22px";
music_ek7.style.fontFamily = "Poppins";
music_ek7.style.fontSize = "10px";
music_ek7.style.overflow = "hidden";
music_ek7.style.color = "#FFFFFF";

page_personality_3_ek1.appendChild(music_ek7);

var do_you_smoke_ = document.createElement("div");
do_you_smoke_.innerHTML = "Do you Smoke?";
do_you_smoke_.style.fontWeight = "bold";
do_you_smoke_.style.textAlign = "left";
do_you_smoke_.id = "do_you_smoke_";
do_you_smoke_.style.left = "23px";
do_you_smoke_.style.top = "70px";
do_you_smoke_.style.width = "137.5px";
do_you_smoke_.style.height = "33.5px";
do_you_smoke_.style.fontFamily = "Poppins";
do_you_smoke_.style.fontSize = "15px";
do_you_smoke_.style.overflow = "hidden";
do_you_smoke_.style.color = "#000000";

page_personality_3_ek1.appendChild(do_you_smoke_);

var do_you_drink_ = document.createElement("div");
do_you_drink_.innerHTML = "Do you Drink?";
do_you_drink_.style.fontWeight = "bold";
do_you_drink_.style.textAlign = "left";
do_you_drink_.id = "do_you_drink_";
do_you_drink_.style.left = "22px";
do_you_drink_.style.top = "165px";
do_you_drink_.style.width = "124.5px";
do_you_drink_.style.height = "33.5px";
do_you_drink_.style.fontFamily = "Poppins";
do_you_drink_.style.fontSize = "15px";
do_you_drink_.style.overflow = "hidden";
do_you_drink_.style.color = "#000000";

page_personality_3_ek1.appendChild(do_you_drink_);

var are_you_a_party_person_ = document.createElement("div");
are_you_a_party_person_.innerHTML = "Are you a Party Person?";
are_you_a_party_person_.style.fontWeight = "bold";
are_you_a_party_person_.style.textAlign = "left";
are_you_a_party_person_.id = "are_you_a_party_person_";
are_you_a_party_person_.style.left = "22px";
are_you_a_party_person_.style.top = "274px";
are_you_a_party_person_.style.width = "200.5px";
are_you_a_party_person_.style.height = "33.5px";
are_you_a_party_person_.style.fontFamily = "Poppins";
are_you_a_party_person_.style.fontSize = "15px";
are_you_a_party_person_.style.overflow = "hidden";
are_you_a_party_person_.style.color = "#000000";

page_personality_3_ek1.appendChild(are_you_a_party_person_);

var how_ofthen_do_you_clean_your_room_ = document.createElement("div");
how_ofthen_do_you_clean_your_room_.innerHTML = "How ofthen do you clean your room?";
how_ofthen_do_you_clean_your_room_.style.fontWeight = "bold";
how_ofthen_do_you_clean_your_room_.style.textAlign = "left";
how_ofthen_do_you_clean_your_room_.id = "how_ofthen_do_you_clean_your_room_";
how_ofthen_do_you_clean_your_room_.style.left = "22px";
how_ofthen_do_you_clean_your_room_.style.top = "376px";
how_ofthen_do_you_clean_your_room_.style.width = "299.5px";
how_ofthen_do_you_clean_your_room_.style.height = "33.5px";
how_ofthen_do_you_clean_your_room_.style.fontFamily = "Poppins";
how_ofthen_do_you_clean_your_room_.style.fontSize = "15px";
how_ofthen_do_you_clean_your_room_.style.overflow = "hidden";
how_ofthen_do_you_clean_your_room_.style.color = "#000000";

page_personality_3_ek1.appendChild(how_ofthen_do_you_clean_your_room_);

var how_ofthen_do_you_cook = document.createElement("div");
how_ofthen_do_you_cook.innerHTML = "How ofthen do you cook";
how_ofthen_do_you_cook.style.fontWeight = "bold";
how_ofthen_do_you_cook.style.textAlign = "left";
how_ofthen_do_you_cook.id = "how_ofthen_do_you_cook";
how_ofthen_do_you_cook.style.left = "22px";
how_ofthen_do_you_cook.style.top = "478px";
how_ofthen_do_you_cook.style.width = "203.5px";
how_ofthen_do_you_cook.style.height = "33.5px";
how_ofthen_do_you_cook.style.fontFamily = "Poppins";
how_ofthen_do_you_cook.style.fontSize = "15px";
how_ofthen_do_you_cook.style.overflow = "hidden";
how_ofthen_do_you_cook.style.color = "#000000";

page_personality_3_ek1.appendChild(how_ofthen_do_you_cook);

var do_you_like_pets = document.createElement("div");
do_you_like_pets.innerHTML = "Do you like Pets";
do_you_like_pets.style.fontWeight = "bold";
do_you_like_pets.style.textAlign = "left";
do_you_like_pets.id = "do_you_like_pets";
do_you_like_pets.style.left = "29px";
do_you_like_pets.style.top = "579px";
do_you_like_pets.style.width = "139.5px";
do_you_like_pets.style.height = "33.5px";
do_you_like_pets.style.fontFamily = "Poppins";
do_you_like_pets.style.fontSize = "15px";
do_you_like_pets.style.overflow = "hidden";
do_you_like_pets.style.color = "#000000";

page_personality_3_ek1.appendChild(do_you_like_pets);

var what_are_your_food_choices = document.createElement("div");
what_are_your_food_choices.innerHTML = "What are your food choices";
what_are_your_food_choices.style.fontWeight = "bold";
what_are_your_food_choices.style.textAlign = "left";
what_are_your_food_choices.id = "what_are_your_food_choices";
what_are_your_food_choices.style.left = "22px";
what_are_your_food_choices.style.top = "682px";
what_are_your_food_choices.style.width = "230.5px";
what_are_your_food_choices.style.height = "33.5px";
what_are_your_food_choices.style.fontFamily = "Poppins";
what_are_your_food_choices.style.fontSize = "15px";
what_are_your_food_choices.style.overflow = "hidden";
what_are_your_food_choices.style.color = "#000000";

page_personality_3_ek1.appendChild(what_are_your_food_choices);

var rectangle_30_ek1 = document.createElement("div");
rectangle_30_ek1.id = "rectangle_30_ek1";
rectangle_30_ek1.style.left = "30px";
rectangle_30_ek1.style.top = "111px";
rectangle_30_ek1.style.width = "96px";
rectangle_30_ek1.style.height = "36px";
rectangle_30_ek1.style.borderRadius = "5px";
rectangle_30_ek1.style.background = 'rgba(203,90,122,1)';

page_personality_3_ek1.appendChild(rectangle_30_ek1);

var rectangle_33 = document.createElement("div");
rectangle_33.id = "rectangle_33";
rectangle_33.style.left = "29px";
rectangle_33.style.top = "206px";
rectangle_33.style.width = "98px";
rectangle_33.style.height = "38px";
rectangle_33.style.borderRadius = "5px";
rectangle_33.style.border = "1px solid #cb5a7a";
rectangle_33.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_33);

var rectangle_36 = document.createElement("div");
rectangle_36.id = "rectangle_36";
rectangle_36.style.left = "29px";
rectangle_36.style.top = "315px";
rectangle_36.style.width = "98px";
rectangle_36.style.height = "38px";
rectangle_36.style.borderRadius = "5px";
rectangle_36.style.border = "1px solid #cb5a7a";
rectangle_36.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_36);

var rectangle_39 = document.createElement("div");
rectangle_39.id = "rectangle_39";
rectangle_39.style.left = "29px";
rectangle_39.style.top = "417px";
rectangle_39.style.width = "98px";
rectangle_39.style.height = "38px";
rectangle_39.style.borderRadius = "5px";
rectangle_39.style.border = "1px solid #cb5a7a";
rectangle_39.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_39);

var rectangle_42 = document.createElement("div");
rectangle_42.id = "rectangle_42";
rectangle_42.style.left = "29px";
rectangle_42.style.top = "519px";
rectangle_42.style.width = "98px";
rectangle_42.style.height = "38px";
rectangle_42.style.borderRadius = "5px";
rectangle_42.style.border = "1px solid #cb5a7a";
rectangle_42.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_42);

var rectangle_45 = document.createElement("div");
rectangle_45.id = "rectangle_45";
rectangle_45.style.left = "29px";
rectangle_45.style.top = "621px";
rectangle_45.style.width = "98px";
rectangle_45.style.height = "38px";
rectangle_45.style.borderRadius = "5px";
rectangle_45.style.border = "1px solid #cb5a7a";
rectangle_45.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_45);

var rectangle_48 = document.createElement("div");
rectangle_48.id = "rectangle_48";
rectangle_48.style.left = "29px";
rectangle_48.style.top = "723px";
rectangle_48.style.width = "98px";
rectangle_48.style.height = "38px";
rectangle_48.style.borderRadius = "5px";
rectangle_48.style.border = "1px solid #cb5a7a";
rectangle_48.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_48);

var rectangle_31 = document.createElement("div");
rectangle_31.id = "rectangle_31";
rectangle_31.style.left = "166px";
rectangle_31.style.top = "111px";
rectangle_31.style.width = "98px";
rectangle_31.style.height = "38px";
rectangle_31.style.borderRadius = "5px";
rectangle_31.style.border = "1px solid #cb5a7a";
rectangle_31.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_31);

var rectangle_34 = document.createElement("div");
rectangle_34.id = "rectangle_34";
rectangle_34.style.left = "165px";
rectangle_34.style.top = "206px";
rectangle_34.style.width = "96px";
rectangle_34.style.height = "36px";
rectangle_34.style.borderRadius = "5px";
rectangle_34.style.background = 'rgba(203,90,122,1)';

page_personality_3_ek1.appendChild(rectangle_34);

var rectangle_37 = document.createElement("div");
rectangle_37.id = "rectangle_37";
rectangle_37.style.left = "165px";
rectangle_37.style.top = "315px";
rectangle_37.style.width = "96px";
rectangle_37.style.height = "36px";
rectangle_37.style.borderRadius = "5px";
rectangle_37.style.background = 'rgba(203,90,122,1)';

page_personality_3_ek1.appendChild(rectangle_37);

var rectangle_40 = document.createElement("div");
rectangle_40.id = "rectangle_40";
rectangle_40.style.left = "165px";
rectangle_40.style.top = "417px";
rectangle_40.style.width = "98px";
rectangle_40.style.height = "38px";
rectangle_40.style.borderRadius = "5px";
rectangle_40.style.border = "1px solid #cb5a7a";
rectangle_40.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_40);

var rectangle_43 = document.createElement("div");
rectangle_43.id = "rectangle_43";
rectangle_43.style.left = "165px";
rectangle_43.style.top = "519px";
rectangle_43.style.width = "96px";
rectangle_43.style.height = "36px";
rectangle_43.style.borderRadius = "5px";
rectangle_43.style.background = 'rgba(203,90,122,1)';

page_personality_3_ek1.appendChild(rectangle_43);

var rectangle_46 = document.createElement("div");
rectangle_46.id = "rectangle_46";
rectangle_46.style.left = "165px";
rectangle_46.style.top = "621px";
rectangle_46.style.width = "96px";
rectangle_46.style.height = "36px";
rectangle_46.style.borderRadius = "5px";
rectangle_46.style.background = 'rgba(203,90,122,1)';

page_personality_3_ek1.appendChild(rectangle_46);

var rectangle_49 = document.createElement("div");
rectangle_49.id = "rectangle_49";
rectangle_49.style.left = "165px";
rectangle_49.style.top = "723px";
rectangle_49.style.width = "96px";
rectangle_49.style.height = "36px";
rectangle_49.style.borderRadius = "5px";
rectangle_49.style.background = 'rgba(203,90,122,1)';

page_personality_3_ek1.appendChild(rectangle_49);

var rectangle_32 = document.createElement("div");
rectangle_32.id = "rectangle_32";
rectangle_32.style.left = "302px";
rectangle_32.style.top = "111px";
rectangle_32.style.width = "98px";
rectangle_32.style.height = "38px";
rectangle_32.style.borderRadius = "5px";
rectangle_32.style.border = "1px solid #cb5a7a";
rectangle_32.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_32);

var rectangle_35 = document.createElement("div");
rectangle_35.id = "rectangle_35";
rectangle_35.style.left = "301px";
rectangle_35.style.top = "206px";
rectangle_35.style.width = "98px";
rectangle_35.style.height = "38px";
rectangle_35.style.borderRadius = "5px";
rectangle_35.style.border = "1px solid #cb5a7a";
rectangle_35.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_35);

var rectangle_38 = document.createElement("div");
rectangle_38.id = "rectangle_38";
rectangle_38.style.left = "301px";
rectangle_38.style.top = "315px";
rectangle_38.style.width = "98px";
rectangle_38.style.height = "38px";
rectangle_38.style.borderRadius = "5px";
rectangle_38.style.border = "1px solid #cb5a7a";
rectangle_38.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_38);

var rectangle_41 = document.createElement("div");
rectangle_41.id = "rectangle_41";
rectangle_41.style.left = "301px";
rectangle_41.style.top = "417px";
rectangle_41.style.width = "96px";
rectangle_41.style.height = "36px";
rectangle_41.style.borderRadius = "5px";
rectangle_41.style.background = 'rgba(203,90,122,1)';

page_personality_3_ek1.appendChild(rectangle_41);

var rectangle_44 = document.createElement("div");
rectangle_44.id = "rectangle_44";
rectangle_44.style.left = "301px";
rectangle_44.style.top = "519px";
rectangle_44.style.width = "98px";
rectangle_44.style.height = "38px";
rectangle_44.style.borderRadius = "5px";
rectangle_44.style.border = "1px solid #cb5a7a";
rectangle_44.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_44);

var rectangle_47 = document.createElement("div");
rectangle_47.id = "rectangle_47";
rectangle_47.style.left = "301px";
rectangle_47.style.top = "621px";
rectangle_47.style.width = "98px";
rectangle_47.style.height = "38px";
rectangle_47.style.borderRadius = "5px";
rectangle_47.style.border = "1px solid #cb5a7a";
rectangle_47.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_47);

var rectangle_50 = document.createElement("div");
rectangle_50.id = "rectangle_50";
rectangle_50.style.left = "301px";
rectangle_50.style.top = "723px";
rectangle_50.style.width = "98px";
rectangle_50.style.height = "38px";
rectangle_50.style.borderRadius = "5px";
rectangle_50.style.border = "1px solid #cb5a7a";
rectangle_50.style.background = 'rgba(255,255,255,0)';

page_personality_3_ek1.appendChild(rectangle_50);

var never = document.createElement("div");
never.innerHTML = "Never";
never.style.textAlign = "left";
never.id = "never";
never.style.left = "59px";
never.style.top = "118px";
never.style.width = "56.5px";
never.style.height = "29.5px";
never.style.fontFamily = "Poppins";
never.style.fontSize = "13px";
never.style.overflow = "hidden";
never.style.color = "#FFFFFF";

page_personality_3_ek1.appendChild(never);

var never_ek1 = document.createElement("div");
never_ek1.innerHTML = "Never";
never_ek1.style.textAlign = "left";
never_ek1.id = "never_ek1";
never_ek1.style.left = "58px";
never_ek1.style.top = "213px";
never_ek1.style.width = "56.5px";
never_ek1.style.height = "29.5px";
never_ek1.style.fontFamily = "Poppins";
never_ek1.style.fontSize = "13px";
never_ek1.style.overflow = "hidden";
never_ek1.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(never_ek1);

var never_ek2 = document.createElement("div");
never_ek2.innerHTML = "Never";
never_ek2.style.textAlign = "left";
never_ek2.id = "never_ek2";
never_ek2.style.left = "58px";
never_ek2.style.top = "322px";
never_ek2.style.width = "56.5px";
never_ek2.style.height = "29.5px";
never_ek2.style.fontFamily = "Poppins";
never_ek2.style.fontSize = "13px";
never_ek2.style.overflow = "hidden";
never_ek2.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(never_ek2);

var daily = document.createElement("div");
daily.innerHTML = "Daily";
daily.style.textAlign = "left";
daily.id = "daily";
daily.style.left = "58px";
daily.style.top = "424px";
daily.style.width = "51.5px";
daily.style.height = "29.5px";
daily.style.fontFamily = "Poppins";
daily.style.fontSize = "13px";
daily.style.overflow = "hidden";
daily.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(daily);

var ofthen = document.createElement("div");
ofthen.innerHTML = "Ofthen";
ofthen.style.textAlign = "left";
ofthen.id = "ofthen";
ofthen.style.left = "58px";
ofthen.style.top = "526px";
ofthen.style.width = "63.5px";
ofthen.style.height = "29.5px";
ofthen.style.fontFamily = "Poppins";
ofthen.style.fontSize = "13px";
ofthen.style.overflow = "hidden";
ofthen.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(ofthen);

var no = document.createElement("div");
no.innerHTML = "No";
no.style.textAlign = "left";
no.id = "no";
no.style.left = "68px";
no.style.top = "628px";
no.style.width = "36.5px";
no.style.height = "29.5px";
no.style.fontFamily = "Poppins";
no.style.fontSize = "13px";
no.style.overflow = "hidden";
no.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(no);

var vegetarian = document.createElement("div");
vegetarian.innerHTML = "Vegetarian";
vegetarian.style.textAlign = "left";
vegetarian.id = "vegetarian";
vegetarian.style.left = "43px";
vegetarian.style.top = "731px";
vegetarian.style.width = "92.5px";
vegetarian.style.height = "29.5px";
vegetarian.style.fontFamily = "Poppins";
vegetarian.style.fontSize = "13px";
vegetarian.style.overflow = "hidden";
vegetarian.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(vegetarian);

var occasionally = document.createElement("div");
occasionally.innerHTML = "Occasionally";
occasionally.style.textAlign = "left";
occasionally.id = "occasionally";
occasionally.style.left = "172px";
occasionally.style.top = "118px";
occasionally.style.width = "103.5px";
occasionally.style.height = "29.5px";
occasionally.style.fontFamily = "Poppins";
occasionally.style.fontSize = "13px";
occasionally.style.overflow = "hidden";
occasionally.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(occasionally);

var occasionally_ek1 = document.createElement("div");
occasionally_ek1.innerHTML = "Occasionally";
occasionally_ek1.style.textAlign = "left";
occasionally_ek1.id = "occasionally_ek1";
occasionally_ek1.style.left = "171px";
occasionally_ek1.style.top = "213px";
occasionally_ek1.style.width = "103.5px";
occasionally_ek1.style.height = "29.5px";
occasionally_ek1.style.fontFamily = "Poppins";
occasionally_ek1.style.fontSize = "13px";
occasionally_ek1.style.overflow = "hidden";
occasionally_ek1.style.color = "#FFFFFF";

page_personality_3_ek1.appendChild(occasionally_ek1);

var occasionally_ek2 = document.createElement("div");
occasionally_ek2.innerHTML = "Occasionally";
occasionally_ek2.style.textAlign = "left";
occasionally_ek2.id = "occasionally_ek2";
occasionally_ek2.style.left = "171px";
occasionally_ek2.style.top = "322px";
occasionally_ek2.style.width = "103.5px";
occasionally_ek2.style.height = "29.5px";
occasionally_ek2.style.fontFamily = "Poppins";
occasionally_ek2.style.fontSize = "13px";
occasionally_ek2.style.overflow = "hidden";
occasionally_ek2.style.color = "#FFFFFF";

page_personality_3_ek1.appendChild(occasionally_ek2);

var once_a_week = document.createElement("div");
once_a_week.innerHTML = "Once a week";
once_a_week.style.textAlign = "left";
once_a_week.id = "once_a_week";
once_a_week.style.left = "171px";
once_a_week.style.top = "424px";
once_a_week.style.width = "102.5px";
once_a_week.style.height = "29.5px";
once_a_week.style.fontFamily = "Poppins";
once_a_week.style.fontSize = "13px";
once_a_week.style.overflow = "hidden";
once_a_week.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(once_a_week);

var sometimes = document.createElement("div");
sometimes.innerHTML = "Sometimes";
sometimes.style.textAlign = "left";
sometimes.id = "sometimes";
sometimes.style.left = "176px";
sometimes.style.top = "526px";
sometimes.style.width = "93.5px";
sometimes.style.height = "29.5px";
sometimes.style.fontFamily = "Poppins";
sometimes.style.fontSize = "13px";
sometimes.style.overflow = "hidden";
sometimes.style.color = "#FFFFFF";

page_personality_3_ek1.appendChild(sometimes);

var maybe = document.createElement("div");
maybe.innerHTML = "Maybe";
maybe.style.textAlign = "left";
maybe.id = "maybe";
maybe.style.left = "192px";
maybe.style.top = "628px";
maybe.style.width = "63.5px";
maybe.style.height = "29.5px";
maybe.style.fontFamily = "Poppins";
maybe.style.fontSize = "13px";
maybe.style.overflow = "hidden";
maybe.style.color = "#FFFFFF";

page_personality_3_ek1.appendChild(maybe);

var non_vege = document.createElement("div");
non_vege.innerHTML = "Non-Vege";
non_vege.style.textAlign = "left";
non_vege.id = "non_vege";
non_vege.style.left = "179px";
non_vege.style.top = "731px";
non_vege.style.width = "86.5px";
non_vege.style.height = "29.5px";
non_vege.style.fontFamily = "Poppins";
non_vege.style.fontSize = "13px";
non_vege.style.overflow = "hidden";
non_vege.style.color = "#FFFFFF";

page_personality_3_ek1.appendChild(non_vege);

var regularly = document.createElement("div");
regularly.innerHTML = "Regularly";
regularly.style.textAlign = "left";
regularly.id = "regularly";
regularly.style.left = "319px";
regularly.style.top = "118px";
regularly.style.width = "80.5px";
regularly.style.height = "29.5px";
regularly.style.fontFamily = "Poppins";
regularly.style.fontSize = "13px";
regularly.style.overflow = "hidden";
regularly.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(regularly);

var regularly_ek1 = document.createElement("div");
regularly_ek1.innerHTML = "Regularly";
regularly_ek1.style.textAlign = "left";
regularly_ek1.id = "regularly_ek1";
regularly_ek1.style.left = "318px";
regularly_ek1.style.top = "213px";
regularly_ek1.style.width = "80.5px";
regularly_ek1.style.height = "29.5px";
regularly_ek1.style.fontFamily = "Poppins";
regularly_ek1.style.fontSize = "13px";
regularly_ek1.style.overflow = "hidden";
regularly_ek1.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(regularly_ek1);

var regularly_ek2 = document.createElement("div");
regularly_ek2.innerHTML = "Regularly";
regularly_ek2.style.textAlign = "left";
regularly_ek2.id = "regularly_ek2";
regularly_ek2.style.left = "318px";
regularly_ek2.style.top = "322px";
regularly_ek2.style.width = "80.5px";
regularly_ek2.style.height = "29.5px";
regularly_ek2.style.fontFamily = "Poppins";
regularly_ek2.style.fontSize = "13px";
regularly_ek2.style.overflow = "hidden";
regularly_ek2.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(regularly_ek2);

var twice_a_week = document.createElement("div");
twice_a_week.innerHTML = "Twice a week";
twice_a_week.style.textAlign = "left";
twice_a_week.id = "twice_a_week";
twice_a_week.style.left = "307px";
twice_a_week.style.top = "424px";
twice_a_week.style.width = "105.5px";
twice_a_week.style.height = "29.5px";
twice_a_week.style.fontFamily = "Poppins";
twice_a_week.style.fontSize = "13px";
twice_a_week.style.overflow = "hidden";
twice_a_week.style.color = "#F9FDFF";

page_personality_3_ek1.appendChild(twice_a_week);

var rarely = document.createElement("div");
rarely.innerHTML = "Rarely";
rarely.style.textAlign = "left";
rarely.id = "rarely";
rarely.style.left = "328px";
rarely.style.top = "526px";
rarely.style.width = "60.5px";
rarely.style.height = "29.5px";
rarely.style.fontFamily = "Poppins";
rarely.style.fontSize = "13px";
rarely.style.overflow = "hidden";
rarely.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(rarely);

var yes = document.createElement("div");
yes.innerHTML = "Yes";
yes.style.textAlign = "left";
yes.id = "yes";
yes.style.left = "339px";
yes.style.top = "628px";
yes.style.width = "41.5px";
yes.style.height = "29.5px";
yes.style.fontFamily = "Poppins";
yes.style.fontSize = "13px";
yes.style.overflow = "hidden";
yes.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(yes);

var eggs = document.createElement("div");
eggs.innerHTML = "Eggs";
eggs.style.textAlign = "left";
eggs.id = "eggs";
eggs.style.left = "339px";
eggs.style.top = "730px";
eggs.style.width = "50.5px";
eggs.style.height = "29.5px";
eggs.style.fontFamily = "Poppins";
eggs.style.fontSize = "13px";
eggs.style.overflow = "hidden";
eggs.style.color = "#CB5A7A";

page_personality_3_ek1.appendChild(eggs);

var _next_ek2 = document.createElement("div");
_next_ek2.innerHTML = "Next";
_next_ek2.style.fontWeight = "bold";
_next_ek2.style.textAlign = "center";
_next_ek2.id = "_next_ek2";
_next_ek2.style.left = "356px";
_next_ek2.style.top = "782px";
_next_ek2.style.width = "57px";
_next_ek2.style.height = "40px";
_next_ek2.style.fontFamily = "Poppins";
_next_ek2.style.fontSize = "18px";
_next_ek2.style.overflow = "hidden";
_next_ek2.style.color = "#000000";

page_personality_3_ek1.appendChild(_next_ek2);

_next_ek2.style.cursor = "pointer";
_next_ek2.onclick = (e) => {
	@page_view("personality_4");
}














