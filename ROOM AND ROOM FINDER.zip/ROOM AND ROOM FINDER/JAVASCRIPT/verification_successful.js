/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);














var page_verification_successful_ek1 = document.createElement("div");
page_verification_successful_ek1.id = "page_verification_successful_ek1";
page_verification_successful_ek1.style.width = "414px";
page_verification_successful_ek1.style.height = "826px";
page_verification_successful_ek1.style.left = "0px";
page_verification_successful_ek1.style.top = "0px";
page_verification_successful_ek1.style.position = "absolute";
content_container.appendChild(page_verification_successful_ek1);

var _bg__verification_successful_ek2 = document.createElement("div");
_bg__verification_successful_ek2.id = "_bg__verification_successful_ek2";
_bg__verification_successful_ek2.style.left = "0px";
_bg__verification_successful_ek2.style.top = "0px";
_bg__verification_successful_ek2.style.width = "414px";
_bg__verification_successful_ek2.style.height = "826px";
_bg__verification_successful_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_verification_successful_ek1.appendChild(_bg__verification_successful_ek2);

var i_ek1 = document.createElement("div");
i_ek1.innerHTML = "i";
i_ek1.style.textAlign = "left";
i_ek1.id = "i_ek1";
i_ek1.style.left = "52px";
i_ek1.style.top = "574px";
i_ek1.style.width = "24px";
i_ek1.style.height = "28px";
i_ek1.style.fontFamily = "Morning Signature";
i_ek1.style.fontSize = "16px";
i_ek1.style.overflow = "hidden";
i_ek1.style.color = "#FFFFFF";

page_verification_successful_ek1.appendChild(i_ek1);

var verification_successful_you_are_all_set = document.createElement("div");
verification_successful_you_are_all_set.innerHTML = "Verification Successful <br/>You are all Set";
verification_successful_you_are_all_set.style.fontWeight = "bold";
verification_successful_you_are_all_set.style.textAlign = "center";
verification_successful_you_are_all_set.id = "verification_successful_you_are_all_set";
verification_successful_you_are_all_set.style.left = "97px";
verification_successful_you_are_all_set.style.top = "440px";
verification_successful_you_are_all_set.style.width = "227px";
verification_successful_you_are_all_set.style.height = "67px";
verification_successful_you_are_all_set.style.fontFamily = "Poppins";
verification_successful_you_are_all_set.style.fontSize = "18px";
verification_successful_you_are_all_set.style.overflow = "hidden";
verification_successful_you_are_all_set.style.color = "#000000";

page_verification_successful_ek1.appendChild(verification_successful_you_are_all_set);

var _rectangle_12 = document.createElement("div");
_rectangle_12.id = "_rectangle_12";
_rectangle_12.style.left = "72px";
_rectangle_12.style.top = "695px";
_rectangle_12.style.width = "270px";
_rectangle_12.style.height = "52px";
_rectangle_12.style.borderRadius = "20px";
_rectangle_12.style.background = 'rgba(203,90,122,1)';

page_verification_successful_ek1.appendChild(_rectangle_12);

_rectangle_12.style.cursor = "pointer";
_rectangle_12.onclick = (e) => {
	@page_view("personality_1");
}

var continue_ek1 = document.createElement("div");
continue_ek1.innerHTML = "Continue";
continue_ek1.style.fontWeight = "bold";
continue_ek1.style.textAlign = "left";
continue_ek1.id = "continue_ek1";
continue_ek1.style.left = "164px";
continue_ek1.style.top = "708px";
continue_ek1.style.width = "108px";
continue_ek1.style.height = "40px";
continue_ek1.style.fontFamily = "Poppins";
continue_ek1.style.fontSize = "18px";
continue_ek1.style.overflow = "hidden";
continue_ek1.style.color = "#FFFFFF";

page_verification_successful_ek1.appendChild(continue_ek1);

var success_1 = document.createElement("img");
success_1.id = "success_1";
success_1.style.left = "-54px";
success_1.style.top = "64px";
success_1.style.width = "522px";
success_1.style.height = "415px";
success_1.src = "skins/success_1.png";

page_verification_successful_ek1.appendChild(success_1);

var status_bar_ek8 = document.createElement("div");
status_bar_ek8.id = "status_bar_ek8";
status_bar_ek8.style.width = "387px";
status_bar_ek8.style.height = "18px";
status_bar_ek8.style.left = "13px";
status_bar_ek8.style.top = "19px";
status_bar_ek8.style.position = "absolute";
page_verification_successful_ek1.appendChild(status_bar_ek8);

var wifi_ek11 = document.createElement("img");
wifi_ek11.id = "wifi_ek11";
wifi_ek11.style.left = "294px";
wifi_ek11.style.top = "5px";
wifi_ek11.style.width = "14.94px";
wifi_ek11.style.height = "10px";
wifi_ek11.src = "skins/wifi_ek11.png";

status_bar_ek8.appendChild(wifi_ek11);

var time_ek8 = document.createElement("div");
time_ek8.innerHTML = "9:41 AM";
time_ek8.style.textAlign = "center";
time_ek8.id = "time_ek8";
time_ek8.style.left = "-2px";
time_ek8.style.top = "0px";
time_ek8.style.width = "62px";
time_ek8.style.height = "26px";
time_ek8.style.fontFamily = "Poppins";
time_ek8.style.fontSize = "12px";
time_ek8.style.overflow = "hidden";
time_ek8.style.color = "#030303";

status_bar_ek8.appendChild(time_ek8);

var battery_ek8 = document.createElement("div");
battery_ek8.id = "battery_ek8";
battery_ek8.style.width = "27.61px";
battery_ek8.style.height = "11.5px";
battery_ek8.style.left = "359px";
battery_ek8.style.top = "5px";
battery_ek8.style.position = "absolute";
status_bar_ek8.appendChild(battery_ek8);

var border_ek8 = document.createElement("img");
border_ek8.id = "border_ek8";
border_ek8.style.left = "0px";
border_ek8.style.opacity = "0.40000000596046";
border_ek8.style.filter = "alpha(opacity='40.000000596046')";
border_ek8.style.top = "0px";
border_ek8.style.width = "25px";
border_ek8.style.height = "11.5px";
border_ek8.src = "skins/border_ek8.png";

battery_ek8.appendChild(border_ek8);

var nub_ek8 = document.createElement("img");
nub_ek8.id = "nub_ek8";
nub_ek8.style.left = "26px";
nub_ek8.style.opacity = "0.40000000596046";
nub_ek8.style.filter = "alpha(opacity='40.000000596046')";
nub_ek8.style.top = "4px";
nub_ek8.style.width = "1.56px";
nub_ek8.style.height = "3.87px";
nub_ek8.src = "skins/nub_ek8.png";

battery_ek8.appendChild(nub_ek8);

var charge_ek8 = document.createElement("img");
charge_ek8.id = "charge_ek8";
charge_ek8.style.left = "2px";
charge_ek8.style.top = "2px";
charge_ek8.style.width = "20.83px";
charge_ek8.style.height = "7.5px";
charge_ek8.src = "skins/charge_ek8.png";

battery_ek8.appendChild(charge_ek8);

var mobile_signal_ek8 = document.createElement("img");
mobile_signal_ek8.id = "mobile_signal_ek8";
mobile_signal_ek8.style.left = "325px";
mobile_signal_ek8.style.top = "4px";
mobile_signal_ek8.style.width = "17.19px";
mobile_signal_ek8.style.height = "10px";
mobile_signal_ek8.src = "skins/mobile_signal_ek8.png";

status_bar_ek8.appendChild(mobile_signal_ek8);


