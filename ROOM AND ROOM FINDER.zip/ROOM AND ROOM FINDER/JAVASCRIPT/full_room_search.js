/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);




var page_full_room_search_ek1 = document.createElement("div");
page_full_room_search_ek1.id = "page_full_room_search_ek1";
page_full_room_search_ek1.style.width = "428px";
page_full_room_search_ek1.style.height = "826px";
page_full_room_search_ek1.style.left = "0px";
page_full_room_search_ek1.style.top = "0px";
page_full_room_search_ek1.style.position = "absolute";
content_container.appendChild(page_full_room_search_ek1);

var _bg__full_room_search_ek2 = document.createElement("div");
_bg__full_room_search_ek2.id = "_bg__full_room_search_ek2";
_bg__full_room_search_ek2.style.left = "0px";
_bg__full_room_search_ek2.style.top = "0px";
_bg__full_room_search_ek2.style.width = "428px";
_bg__full_room_search_ek2.style.height = "826px";
_bg__full_room_search_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_full_room_search_ek1.appendChild(_bg__full_room_search_ek2);

var detaiills = document.createElement("div");
detaiills.id = "detaiills";
detaiills.style.width = "428px";
detaiills.style.height = "826px";
detaiills.style.left = "0px";
detaiills.style.top = "0px";
detaiills.style.position = "absolute";
page_full_room_search_ek1.appendChild(detaiills);

var details = document.createElement("div");
details.id = "details";
details.style.width = "428px";
details.style.height = "1438px";
details.style.left = "0px";
details.style.top = "0px";
details.style.position = "absolute";
detaiills.appendChild(details);

var card_background = document.createElement("div");
card_background.id = "card_background";
card_background.style.left = "0px";
card_background.style.top = "0px";
card_background.style.width = "428px";
card_background.style.height = "1438px";
card_background.style.borderRadius = "16px";
card_background.style.background = 'rgba(255,255,255,1)';

details.appendChild(card_background);

var description = document.createElement("div");
description.innerHTML = "Maitama, Abuja";
description.style.textAlign = "left";
description.id = "description";
description.style.left = "8px";
description.style.top = "701px";
description.style.width = "370.57px";
description.style.height = "36px";
description.style.fontFamily = "Poppins";
description.style.fontSize = "16px";
description.style.lineHeight = "25px";
description.style.overflow = "hidden";
description.style.color = "#6E798C";

details.appendChild(description);

var _2_bedroom_beautiful_apartment_near_oando_station = document.createElement("div");
_2_bedroom_beautiful_apartment_near_oando_station.innerHTML = "2 Bedroom Beautiful Apartment<br/>Near Oando Station";
_2_bedroom_beautiful_apartment_near_oando_station.style.textAlign = "left";
_2_bedroom_beautiful_apartment_near_oando_station.id = "_2_bedroom_beautiful_apartment_near_oando_station";
_2_bedroom_beautiful_apartment_near_oando_station.style.left = "10px";
_2_bedroom_beautiful_apartment_near_oando_station.style.top = "247px";
_2_bedroom_beautiful_apartment_near_oando_station.style.width = "413.79px";
_2_bedroom_beautiful_apartment_near_oando_station.style.height = "64px";
_2_bedroom_beautiful_apartment_near_oando_station.style.fontFamily = "Poppins";
_2_bedroom_beautiful_apartment_near_oando_station.style.fontSize = "20px";
_2_bedroom_beautiful_apartment_near_oando_station.style.lineHeight = "25px";
_2_bedroom_beautiful_apartment_near_oando_station.style.overflow = "hidden";
_2_bedroom_beautiful_apartment_near_oando_station.style.color = "#081F32";

details.appendChild(_2_bedroom_beautiful_apartment_near_oando_station);

var pizza_photo = document.createElement("div");
pizza_photo.id = "pizza_photo";
pizza_photo.style.left = "0px";
pizza_photo.style.top = "0px";
pizza_photo.style.width = "428px";
pizza_photo.style.height = "221px";
pizza_photo.style.borderRadius = "16px";
pizza_photo.style.background = 'rgba(196,196,196,1)';

details.appendChild(pizza_photo);

var rent = document.createElement("div");
rent.innerHTML = "Rent";
rent.style.textAlign = "left";
rent.id = "rent";
rent.style.left = "10px";
rent.style.top = "603px";
rent.style.width = "60.21px";
rent.style.height = "36px";
rent.style.fontFamily = "Poppins";
rent.style.fontSize = "16px";
rent.style.lineHeight = "25px";
rent.style.overflow = "hidden";
rent.style.color = "#000000";

details.appendChild(rent);

var price = document.createElement("div");
price.id = "price";
price.style.width = "147.9px";
price.style.height = "21px";
price.style.left = "10px";
price.style.top = "628px";
price.style.position = "absolute";
details.appendChild(price);

var price_ek1 = document.createElement("div");
price_ek1.innerHTML = "500,000/Year";
price_ek1.style.textAlign = "left";
price_ek1.id = "price_ek1";
price_ek1.style.left = "18px";
price_ek1.style.top = "0px";
price_ek1.style.width = "150.97px";
price_ek1.style.height = "32px";
price_ek1.style.fontFamily = "Poppins";
price_ek1.style.fontSize = "16px";
price_ek1.style.lineHeight = "25px";
price_ek1.style.overflow = "hidden";
price_ek1.style.color = "#081F32";

price.appendChild(price_ek1);

var fa6_solid_naira_sign = document.createElement("div");
fa6_solid_naira_sign.id = "fa6_solid_naira_sign";
fa6_solid_naira_sign.style.width = "14.57px";
fa6_solid_naira_sign.style.height = "15px";
fa6_solid_naira_sign.style.left = "0px";
fa6_solid_naira_sign.style.top = "4px";
fa6_solid_naira_sign.style.position = "absolute";
price.appendChild(fa6_solid_naira_sign);

var vector_ek18 = document.createElement("img");
vector_ek18.id = "vector_ek18";
vector_ek18.style.left = "0px";
vector_ek18.style.top = "0.94px";
vector_ek18.style.width = "14.57px";
vector_ek18.style.height = "13.13px";
vector_ek18.src = "skins/vector_ek18.png";

fa6_solid_naira_sign.appendChild(vector_ek18);

var available = document.createElement("div");
available.innerHTML = "Available";
available.style.textAlign = "left";
available.id = "available";
available.style.left = "325px";
available.style.top = "608px";
available.style.width = "100.55px";
available.style.height = "36px";
available.style.fontFamily = "Poppins";
available.style.fontSize = "16px";
available.style.lineHeight = "25px";
available.style.overflow = "hidden";
available.style.color = "#000000";

details.appendChild(available);

var location = document.createElement("div");
location.innerHTML = "Location";
location.style.textAlign = "left";
location.id = "location";
location.style.left = "10px";
location.style.top = "672px";
location.style.width = "79px";
location.style.height = "35px";
location.style.fontFamily = "Poppins";
location.style.fontSize = "14px";
location.style.lineHeight = "25px";
location.style.overflow = "hidden";
location.style.color = "#000000";

details.appendChild(location);

var january_17th = document.createElement("div");
january_17th.innerHTML = "January 17th";
january_17th.style.textAlign = "left";
january_17th.id = "january_17th";
january_17th.style.left = "300px";
january_17th.style.top = "632px";
january_17th.style.width = "133.04px";
january_17th.style.height = "36px";
january_17th.style.fontFamily = "Poppins";
january_17th.style.fontSize = "16px";
january_17th.style.lineHeight = "25px";
january_17th.style.overflow = "hidden";
january_17th.style.color = "#000000";

details.appendChild(january_17th);

var vector_ek19 = document.createElement("img");
vector_ek19.id = "vector_ek19";
vector_ek19.style.left = "10px";
vector_ek19.style.top = "331px";
vector_ek19.style.width = "18px";
vector_ek19.style.height = "18px";
vector_ek19.src = "skins/vector_ek19.png";

details.appendChild(vector_ek19);

var _2_bedroom_apartment = document.createElement("div");
_2_bedroom_apartment.innerHTML = "2 Bedroom Apartment";
_2_bedroom_apartment.style.textAlign = "left";
_2_bedroom_apartment.id = "_2_bedroom_apartment";
_2_bedroom_apartment.style.left = "40px";
_2_bedroom_apartment.style.top = "327px";
_2_bedroom_apartment.style.width = "128px";
_2_bedroom_apartment.style.height = "32px";
_2_bedroom_apartment.style.fontFamily = "Poppins";
_2_bedroom_apartment.style.fontSize = "10px";
_2_bedroom_apartment.style.lineHeight = "25px";
_2_bedroom_apartment.style.overflow = "hidden";
_2_bedroom_apartment.style.color = "#000000";

details.appendChild(_2_bedroom_apartment);

var fluent_bed_24_regular_ek1 = document.createElement("div");
fluent_bed_24_regular_ek1.id = "fluent_bed_24_regular_ek1";
fluent_bed_24_regular_ek1.style.width = "39px";
fluent_bed_24_regular_ek1.style.height = "39px";
fluent_bed_24_regular_ek1.style.left = "231px";
fluent_bed_24_regular_ek1.style.top = "323px";
fluent_bed_24_regular_ek1.style.position = "absolute";
details.appendChild(fluent_bed_24_regular_ek1);

var vector_ek20 = document.createElement("img");
vector_ek20.id = "vector_ek20";
vector_ek20.style.left = "3.25px";
vector_ek20.style.top = "6.5px";
vector_ek20.style.width = "32.5px";
vector_ek20.style.height = "27.63px";
vector_ek20.src = "skins/vector_ek20.png";

fluent_bed_24_regular_ek1.appendChild(vector_ek20);

var up_to_5_people = document.createElement("div");
up_to_5_people.innerHTML = "Up to 5 people";
up_to_5_people.style.textAlign = "left";
up_to_5_people.id = "up_to_5_people";
up_to_5_people.style.left = "282px";
up_to_5_people.style.top = "327px";
up_to_5_people.style.width = "89px";
up_to_5_people.style.height = "32px";
up_to_5_people.style.fontFamily = "Poppins";
up_to_5_people.style.fontSize = "10px";
up_to_5_people.style.lineHeight = "25px";
up_to_5_people.style.overflow = "hidden";
up_to_5_people.style.color = "#000000";

details.appendChild(up_to_5_people);

var vector_ek21 = document.createElement("img");
vector_ek21.id = "vector_ek21";
vector_ek21.style.left = "10px";
vector_ek21.style.top = "383px";
vector_ek21.style.width = "18px";
vector_ek21.style.height = "18px";
vector_ek21.src = "skins/vector_ek21.png";

details.appendChild(vector_ek21);

var _2_bathroom = document.createElement("div");
_2_bathroom.innerHTML = "2 Bathroom";
_2_bathroom.style.textAlign = "left";
_2_bathroom.id = "_2_bathroom";
_2_bathroom.style.left = "40px";
_2_bathroom.style.top = "379px";
_2_bathroom.style.width = "75px";
_2_bathroom.style.height = "32px";
_2_bathroom.style.fontFamily = "Poppins";
_2_bathroom.style.fontSize = "10px";
_2_bathroom.style.lineHeight = "25px";
_2_bathroom.style.overflow = "hidden";
_2_bathroom.style.color = "#000000";

details.appendChild(_2_bathroom);

var description_ek1 = document.createElement("div");
description_ek1.innerHTML = "Description";
description_ek1.style.textAlign = "left";
description_ek1.id = "description_ek1";
description_ek1.style.left = "10px";
description_ek1.style.top = "424px";
description_ek1.style.width = "100px";
description_ek1.style.height = "35px";
description_ek1.style.fontFamily = "Poppins";
description_ek1.style.fontSize = "14px";
description_ek1.style.lineHeight = "25px";
description_ek1.style.overflow = "hidden";
description_ek1.style.color = "#000000";

details.appendChild(description_ek1);

var this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_ = document.createElement("div");
this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_.innerHTML = "This 2 Bedroom W/ 2 Full Bathroom Ranch Home Is Immaculate &amp; Full Of Upgrades!<br/> Enjoy The Open Floor Plan W/ Vaulted 15ft Ceilings&amp; Large Windows Throughout.<br/> The Beautiful Kitchen Is The Heart Of The Home Complete With Large Customized<br/> Granite Island &amp; Stainless Steel Appliances. Updated Lighting Throughout The<br/> Entire Home. ";
this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_.style.textAlign = "left";
this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_.id = "this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_";
this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_.style.left = "8px";
this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_.style.top = "444px";
this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_.style.width = "435px";
this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_.style.height = "132px";
this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_.style.fontFamily = "Poppins";
this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_.style.fontSize = "10px";
this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_.style.lineHeight = "25px";
this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_.style.overflow = "hidden";
this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_.style.color = "#000000";

details.appendChild(this_2_bedroom_w__2_full_bathroom_ranch_home_is_immaculate___full_of_upgrades__enjoy_the_open_floor_plan_w__vaulted_15ft_ceilings__large_windows_throughout__the_beautiful_kitchen_is_the_heart_of_the_home_complete_with_large_customized_granite_island___stainless_steel_appliances__updated_lighting_throughout_the_entire_home_);

var price_ek2 = document.createElement("div");
price_ek2.innerHTML = "Price";
price_ek2.style.textAlign = "left";
price_ek2.id = "price_ek2";
price_ek2.style.left = "10px";
price_ek2.style.top = "576px";
price_ek2.style.width = "54px";
price_ek2.style.height = "35px";
price_ek2.style.fontFamily = "Poppins";
price_ek2.style.fontSize = "14px";
price_ek2.style.lineHeight = "25px";
price_ek2.style.overflow = "hidden";
price_ek2.style.color = "#000000";

details.appendChild(price_ek2);

var rectangle_60 = document.createElement("img");
rectangle_60.id = "rectangle_60";
rectangle_60.style.left = "8px";
rectangle_60.style.top = "733px";
rectangle_60.style.width = "407px";
rectangle_60.style.height = "241px";
rectangle_60.src = "skins/rectangle_60.png";

details.appendChild(rectangle_60);

var home_amentites = document.createElement("div");
home_amentites.innerHTML = "Home Amentites";
home_amentites.style.textAlign = "left";
home_amentites.id = "home_amentites";
home_amentites.style.left = "8px";
home_amentites.style.top = "988px";
home_amentites.style.width = "136px";
home_amentites.style.height = "35px";
home_amentites.style.fontFamily = "Poppins";
home_amentites.style.fontSize = "14px";
home_amentites.style.lineHeight = "25px";
home_amentites.style.overflow = "hidden";
home_amentites.style.color = "#000000";

details.appendChild(home_amentites);

var group_ek3 = document.createElement("div");
group_ek3.id = "group_ek3";
group_ek3.style.width = "27.14px";
group_ek3.style.height = "19px";
group_ek3.style.left = "14px";
group_ek3.style.top = "1032px";
group_ek3.style.position = "absolute";
details.appendChild(group_ek3);

var vector_ek22 = document.createElement("img");
vector_ek22.id = "vector_ek22";
vector_ek22.style.left = "0px";
vector_ek22.style.top = "0px";
vector_ek22.style.width = "27.14px";
vector_ek22.style.height = "12.21px";
vector_ek22.src = "skins/vector_ek22.png";

group_ek3.appendChild(vector_ek22);

var vector_ek23 = document.createElement("img");
vector_ek23.id = "vector_ek23";
vector_ek23.style.left = "12px";
vector_ek23.style.top = "16px";
vector_ek23.style.width = "2.71px";
vector_ek23.style.height = "2.71px";
vector_ek23.src = "skins/vector_ek23.png";

group_ek3.appendChild(vector_ek23);

var vector_ek24 = document.createElement("img");
vector_ek24.id = "vector_ek24";
vector_ek24.style.left = "15px";
vector_ek24.style.top = "1077px";
vector_ek24.style.width = "28px";
vector_ek24.style.height = "27px";
vector_ek24.src = "skins/vector_ek24.png";

details.appendChild(vector_ek24);

var television = document.createElement("div");
television.innerHTML = "Television";
television.style.textAlign = "left";
television.id = "television";
television.style.left = "52px";
television.style.top = "1079px";
television.style.width = "88px";
television.style.height = "35px";
television.style.fontFamily = "Poppins";
television.style.fontSize = "14px";
television.style.lineHeight = "25px";
television.style.overflow = "hidden";
television.style.color = "#868686";

details.appendChild(television);

var vector_ek25 = document.createElement("img");
vector_ek25.id = "vector_ek25";
vector_ek25.style.left = "277px";
vector_ek25.style.top = "1034px";
vector_ek25.style.width = "27px";
vector_ek25.style.height = "19px";
vector_ek25.src = "skins/vector_ek25.png";

details.appendChild(vector_ek25);

var wifi = document.createElement("div");
wifi.innerHTML = "WIFI";
wifi.style.textAlign = "left";
wifi.id = "wifi";
wifi.style.left = "52px";
wifi.style.top = "1031px";
wifi.style.width = "47px";
wifi.style.height = "35px";
wifi.style.fontFamily = "Poppins";
wifi.style.fontSize = "14px";
wifi.style.lineHeight = "25px";
wifi.style.overflow = "hidden";
wifi.style.color = "#868686";

details.appendChild(wifi);

var furnished = document.createElement("div");
furnished.innerHTML = "Furnished";
furnished.style.textAlign = "left";
furnished.id = "furnished";
furnished.style.left = "315px";
furnished.style.top = "1031px";
furnished.style.width = "88px";
furnished.style.height = "35px";
furnished.style.fontFamily = "Poppins";
furnished.style.fontSize = "14px";
furnished.style.lineHeight = "25px";
furnished.style.overflow = "hidden";
furnished.style.color = "#868686";

details.appendChild(furnished);

var suitable_for = document.createElement("div");
suitable_for.innerHTML = "Suitable For";
suitable_for.style.textAlign = "left";
suitable_for.id = "suitable_for";
suitable_for.style.left = "15px";
suitable_for.style.top = "1122px";
suitable_for.style.width = "101px";
suitable_for.style.height = "35px";
suitable_for.style.fontFamily = "Poppins";
suitable_for.style.fontSize = "14px";
suitable_for.style.lineHeight = "25px";
suitable_for.style.overflow = "hidden";
suitable_for.style.color = "#000000";

details.appendChild(suitable_for);

var vector_ek26 = document.createElement("img");
vector_ek26.id = "vector_ek26";
vector_ek26.style.left = "15px";
vector_ek26.style.top = "1161px";
vector_ek26.style.width = "28px";
vector_ek26.style.height = "27px";
vector_ek26.src = "skins/vector_ek26.png";

details.appendChild(vector_ek26);

var ic_twotone_pets = document.createElement("div");
ic_twotone_pets.id = "ic_twotone_pets";
ic_twotone_pets.style.width = "28px";
ic_twotone_pets.style.height = "27px";
ic_twotone_pets.style.left = "277px";
ic_twotone_pets.style.top = "1161px";
ic_twotone_pets.style.position = "absolute";
details.appendChild(ic_twotone_pets);

var vector_ek27 = document.createElement("img");
vector_ek27.id = "vector_ek27";
vector_ek27.style.left = "2.33px";
vector_ek27.style.top = "7.88px";
vector_ek27.style.width = "5.83px";
vector_ek27.style.height = "5.63px";
vector_ek27.src = "skins/vector_ek27.png";

ic_twotone_pets.appendChild(vector_ek27);

var vector_ek28 = document.createElement("img");
vector_ek28.id = "vector_ek28";
vector_ek28.style.left = "7.58px";
vector_ek28.style.top = "3.38px";
vector_ek28.style.width = "5.83px";
vector_ek28.style.height = "5.63px";
vector_ek28.src = "skins/vector_ek28.png";

ic_twotone_pets.appendChild(vector_ek28);

var vector_ek29 = document.createElement("img");
vector_ek29.id = "vector_ek29";
vector_ek29.style.left = "14.58px";
vector_ek29.style.top = "3.38px";
vector_ek29.style.width = "5.83px";
vector_ek29.style.height = "5.63px";
vector_ek29.src = "skins/vector_ek29.png";

ic_twotone_pets.appendChild(vector_ek29);

var vector_ek30 = document.createElement("img");
vector_ek30.id = "vector_ek30";
vector_ek30.style.left = "19.83px";
vector_ek30.style.top = "7.88px";
vector_ek30.style.width = "5.83px";
vector_ek30.style.height = "5.63px";
vector_ek30.src = "skins/vector_ek30.png";

ic_twotone_pets.appendChild(vector_ek30);

var vector_ek31 = document.createElement("img");
vector_ek31.id = "vector_ek31";
vector_ek31.style.left = "4.66px";
vector_ek31.style.top = "11.81px";
vector_ek31.style.width = "18.66px";
vector_ek31.style.height = "12.94px";
vector_ek31.src = "skins/vector_ek31.png";

ic_twotone_pets.appendChild(vector_ek31);

var group_ek4 = document.createElement("div");
group_ek4.id = "group_ek4";
group_ek4.style.width = "28px";
group_ek4.style.height = "27px";
group_ek4.style.left = "17px";
group_ek4.style.top = "1212px";
group_ek4.style.position = "absolute";
details.appendChild(group_ek4);

var vector_ek32 = document.createElement("img");
vector_ek32.id = "vector_ek32";
vector_ek32.style.left = "19px";
vector_ek32.style.top = "12px";
vector_ek32.style.width = "2.69px";
vector_ek32.style.height = "2.96px";
vector_ek32.src = "skins/vector_ek32.png";

group_ek4.appendChild(vector_ek32);

var vector_ek33 = document.createElement("img");
vector_ek33.id = "vector_ek33";
vector_ek33.style.left = "0px";
vector_ek33.style.top = "0px";
vector_ek33.style.width = "28px";
vector_ek33.style.height = "27px";
vector_ek33.src = "skins/vector_ek33.png";

group_ek4.appendChild(vector_ek33);

var vector_ek34 = document.createElement("img");
vector_ek34.id = "vector_ek34";
vector_ek34.style.left = "277px";
vector_ek34.style.top = "1212px";
vector_ek34.style.width = "26px";
vector_ek34.style.height = "28px";
vector_ek34.src = "skins/vector_ek34.png";

details.appendChild(vector_ek34);

var no_smoking = document.createElement("div");
no_smoking.innerHTML = "No Smoking";
no_smoking.style.textAlign = "left";
no_smoking.id = "no_smoking";
no_smoking.style.left = "50px";
no_smoking.style.top = "1215px";
no_smoking.style.width = "103px";
no_smoking.style.height = "35px";
no_smoking.style.fontFamily = "Poppins";
no_smoking.style.fontSize = "14px";
no_smoking.style.lineHeight = "25px";
no_smoking.style.overflow = "hidden";
no_smoking.style.color = "#868686";

details.appendChild(no_smoking);

var vector_ek35 = document.createElement("img");
vector_ek35.id = "vector_ek35";
vector_ek35.style.left = "280px";
vector_ek35.style.top = "1225px";
vector_ek35.style.width = "20px";
vector_ek35.style.height = "12px";
vector_ek35.src = "skins/vector_ek35.png";

details.appendChild(vector_ek35);

var student = document.createElement("div");
student.innerHTML = "Student";
student.style.textAlign = "left";
student.id = "student";
student.style.left = "52px";
student.style.top = "1162px";
student.style.width = "74px";
student.style.height = "35px";
student.style.fontFamily = "Poppins";
student.style.fontSize = "14px";
student.style.lineHeight = "25px";
student.style.overflow = "hidden";
student.style.color = "#868686";

details.appendChild(student);

var pets_allowed = document.createElement("div");
pets_allowed.innerHTML = "Pets Allowed";
pets_allowed.style.textAlign = "left";
pets_allowed.id = "pets_allowed";
pets_allowed.style.left = "312px";
pets_allowed.style.top = "1164px";
pets_allowed.style.width = "107px";
pets_allowed.style.height = "35px";
pets_allowed.style.fontFamily = "Poppins";
pets_allowed.style.fontSize = "14px";
pets_allowed.style.lineHeight = "25px";
pets_allowed.style.overflow = "hidden";
pets_allowed.style.color = "#868686";

details.appendChild(pets_allowed);

var woman = document.createElement("div");
woman.innerHTML = "Woman";
woman.style.textAlign = "left";
woman.id = "woman";
woman.style.left = "315px";
woman.style.top = "1211px";
woman.style.width = "75px";
woman.style.height = "35px";
woman.style.fontFamily = "Poppins";
woman.style.fontSize = "14px";
woman.style.lineHeight = "25px";
woman.style.overflow = "hidden";
woman.style.color = "#868686";

details.appendChild(woman);

var rectangle_61 = document.createElement("div");
rectangle_61.id = "rectangle_61";
rectangle_61.style.left = "37px";
rectangle_61.style.top = "1270px";
rectangle_61.style.width = "360px";
rectangle_61.style.height = "64px";
rectangle_61.style.borderRadius = "15px";
rectangle_61.style.border = "2px solid #cb5a7a";
rectangle_61.style.background = 'rgba(255,255,255,0)';

details.appendChild(rectangle_61);

var _rectangle_62 = document.createElement("div");
_rectangle_62.id = "_rectangle_62";
_rectangle_62.style.left = "36px";
_rectangle_62.style.top = "1347px";
_rectangle_62.style.width = "356px";
_rectangle_62.style.height = "60px";
_rectangle_62.style.borderRadius = "15px";
_rectangle_62.style.background = 'rgba(203,90,122,1)';

details.appendChild(_rectangle_62);

_rectangle_62.style.cursor = "pointer";
_rectangle_62.onclick = (e) => {
	@page_view("search");
}

var send_a_visit_proposal = document.createElement("div");
send_a_visit_proposal.innerHTML = "Send a visit Proposal";
send_a_visit_proposal.style.textAlign = "left";
send_a_visit_proposal.id = "send_a_visit_proposal";
send_a_visit_proposal.style.left = "142px";
send_a_visit_proposal.style.top = "1287px";
send_a_visit_proposal.style.width = "164px";
send_a_visit_proposal.style.height = "35px";
send_a_visit_proposal.style.fontFamily = "Poppins";
send_a_visit_proposal.style.fontSize = "14px";
send_a_visit_proposal.style.lineHeight = "25px";
send_a_visit_proposal.style.overflow = "hidden";
send_a_visit_proposal.style.color = "#CB5A7A";

details.appendChild(send_a_visit_proposal);

var send_a_message = document.createElement("div");
send_a_message.innerHTML = "Send a Message";
send_a_message.style.textAlign = "left";
send_a_message.id = "send_a_message";
send_a_message.style.left = "156px";
send_a_message.style.top = "1364px";
send_a_message.style.width = "135px";
send_a_message.style.height = "35px";
send_a_message.style.fontFamily = "Poppins";
send_a_message.style.fontSize = "14px";
send_a_message.style.lineHeight = "25px";
send_a_message.style.overflow = "hidden";
send_a_message.style.color = "#FFFFFF";

details.appendChild(send_a_message);

var _vector_ek36 = document.createElement("img");
_vector_ek36.id = "_vector_ek36";
_vector_ek36.style.left = "19px";
_vector_ek36.style.top = "22px";
_vector_ek36.style.width = "18.41px";
_vector_ek36.style.height = "15.41px";
_vector_ek36.src = "skins/_vector_ek36.png";

details.appendChild(_vector_ek36);

_vector_ek36.style.cursor = "pointer";
_vector_ek36.onclick = (e) => {
	@page_view("room_search");
}

var vector_ek37 = document.createElement("img");
vector_ek37.id = "vector_ek37";
vector_ek37.style.left = "389px";
vector_ek37.style.top = "26px";
vector_ek37.style.width = "4px";
vector_ek37.style.height = "4px";
vector_ek37.src = "skins/vector_ek37.png";

details.appendChild(vector_ek37);

var vector_ek38 = document.createElement("img");
vector_ek38.id = "vector_ek38";
vector_ek38.style.left = "397px";
vector_ek38.style.top = "26px";
vector_ek38.style.width = "4px";
vector_ek38.style.height = "4px";
vector_ek38.src = "skins/vector_ek38.png";

details.appendChild(vector_ek38);

var vector_ek39 = document.createElement("img");
vector_ek39.id = "vector_ek39";
vector_ek39.style.left = "405px";
vector_ek39.style.top = "26px";
vector_ek39.style.width = "4px";
vector_ek39.style.height = "4px";
vector_ek39.src = "skins/vector_ek39.png";

details.appendChild(vector_ek39);










