/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);












var page_onboard_1_ek1 = document.createElement("div");
page_onboard_1_ek1.id = "page_onboard_1_ek1";
page_onboard_1_ek1.style.width = "428px";
page_onboard_1_ek1.style.height = "826px";
page_onboard_1_ek1.style.left = "0px";
page_onboard_1_ek1.style.top = "0px";
page_onboard_1_ek1.style.position = "absolute";
content_container.appendChild(page_onboard_1_ek1);

var _bg__onboard_1_ek2 = document.createElement("div");
_bg__onboard_1_ek2.id = "_bg__onboard_1_ek2";
_bg__onboard_1_ek2.style.left = "0px";
_bg__onboard_1_ek2.style.top = "0px";
_bg__onboard_1_ek2.style.width = "428px";
_bg__onboard_1_ek2.style.height = "826px";
_bg__onboard_1_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_onboard_1_ek1.appendChild(_bg__onboard_1_ek2);

var all_about_you = document.createElement("div");
all_about_you.innerHTML = "ALL ABOUT YOU";
all_about_you.style.fontWeight = "bold";
all_about_you.style.textAlign = "left";
all_about_you.id = "all_about_you";
all_about_you.style.left = "86px";
all_about_you.style.top = "508px";
all_about_you.style.width = "482px";
all_about_you.style.height = "82px";
all_about_you.style.fontFamily = "Poppins";
all_about_you.style.fontSize = "34px";
all_about_you.style.overflow = "hidden";
all_about_you.style.color = "#000000";

page_onboard_1_ek1.appendChild(all_about_you);

var getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you = document.createElement("div");
getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you.innerHTML = "Getting to know about you will help build  your<br/>profile so we can filter the best <br/>roomate for you";
getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you.style.fontWeight = "bold";
getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you.style.textAlign = "center";
getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you.id = "getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you";
getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you.style.left = "67px";
getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you.style.top = "565px";
getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you.style.width = "343px";
getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you.style.height = "73px";
getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you.style.fontFamily = "Poppins";
getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you.style.fontSize = "14px";
getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you.style.overflow = "hidden";
getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you.style.color = "#000000";

page_onboard_1_ek1.appendChild(getting_to_know_about_you_will_help_build_your_profile_so_we_can_filter_the_best_roomate_for_you);

var _skip_ek1 = document.createElement("div");
_skip_ek1.innerHTML = "SKIP";
_skip_ek1.style.fontWeight = "bold";
_skip_ek1.style.textAlign = "center";
_skip_ek1.id = "_skip_ek1";
_skip_ek1.style.left = "370px";
_skip_ek1.style.top = "49px";
_skip_ek1.style.width = "44px";
_skip_ek1.style.height = "31px";
_skip_ek1.style.fontFamily = "Poppins";
_skip_ek1.style.fontSize = "14px";
_skip_ek1.style.overflow = "hidden";
_skip_ek1.style.color = "#000000";

page_onboard_1_ek1.appendChild(_skip_ek1);

_skip_ek1.style.cursor = "pointer";
_skip_ek1.onclick = (e) => {
	@page_view("sign_in");
}

var _next_ek4 = document.createElement("div");
_next_ek4.innerHTML = "NEXT";
_next_ek4.style.fontWeight = "bold";
_next_ek4.style.textAlign = "center";
_next_ek4.id = "_next_ek4";
_next_ek4.style.left = "364px";
_next_ek4.style.top = "791px";
_next_ek4.style.width = "49px";
_next_ek4.style.height = "31px";
_next_ek4.style.fontFamily = "Poppins";
_next_ek4.style.fontSize = "14px";
_next_ek4.style.overflow = "hidden";
_next_ek4.style.color = "#000000";

page_onboard_1_ek1.appendChild(_next_ek4);

_next_ek4.style.cursor = "pointer";
_next_ek4.onclick = (e) => {
	@page_view("onboard_2");
}

var rectangle_1_ek3 = document.createElement("div");
rectangle_1_ek3.id = "rectangle_1_ek3";
rectangle_1_ek3.style.left = "176px";
rectangle_1_ek3.style.top = "669px";
rectangle_1_ek3.style.width = "26px";
rectangle_1_ek3.style.height = "12px";
rectangle_1_ek3.style.borderRadius = "5px";
rectangle_1_ek3.style.background = 'rgba(203,90,122,1)';

page_onboard_1_ek1.appendChild(rectangle_1_ek3);

var _rectangle_2_ek4 = document.createElement("div");
_rectangle_2_ek4.id = "_rectangle_2_ek4";
_rectangle_2_ek4.style.left = "233px";
_rectangle_2_ek4.style.top = "669px";
_rectangle_2_ek4.style.width = "14px";
_rectangle_2_ek4.style.height = "12px";
_rectangle_2_ek4.style.borderRadius = "5px";
_rectangle_2_ek4.style.background = 'rgba(217,217,217,1)';

page_onboard_1_ek1.appendChild(_rectangle_2_ek4);

_rectangle_2_ek4.style.cursor = "pointer";
_rectangle_2_ek4.onclick = (e) => {
	@page_view("onboard_2");
}

var _rectangle_3_ek6 = document.createElement("div");
_rectangle_3_ek6.id = "_rectangle_3_ek6";
_rectangle_3_ek6.style.left = "271px";
_rectangle_3_ek6.style.top = "669px";
_rectangle_3_ek6.style.width = "14px";
_rectangle_3_ek6.style.height = "12px";
_rectangle_3_ek6.style.borderRadius = "5px";
_rectangle_3_ek6.style.background = 'rgba(217,217,217,1)';

page_onboard_1_ek1.appendChild(_rectangle_3_ek6);

_rectangle_3_ek6.style.cursor = "pointer";
_rectangle_3_ek6.onclick = (e) => {
	@page_view("onboard_3_3");
}

var teenagers_relaxing_at_home_on_the_sofa_with_a_cat = document.createElement("img");
teenagers_relaxing_at_home_on_the_sofa_with_a_cat.id = "teenagers_relaxing_at_home_on_the_sofa_with_a_cat";
teenagers_relaxing_at_home_on_the_sofa_with_a_cat.style.left = "-48px";
teenagers_relaxing_at_home_on_the_sofa_with_a_cat.style.top = "41px";
teenagers_relaxing_at_home_on_the_sofa_with_a_cat.style.width = "524px";
teenagers_relaxing_at_home_on_the_sofa_with_a_cat.style.height = "524px";
teenagers_relaxing_at_home_on_the_sofa_with_a_cat.src = "skins/teenagers_relaxing_at_home_on_the_sofa_with_a_cat.png";

page_onboard_1_ek1.appendChild(teenagers_relaxing_at_home_on_the_sofa_with_a_cat);

var status_bar_ek6 = document.createElement("div");
status_bar_ek6.id = "status_bar_ek6";
status_bar_ek6.style.width = "380px";
status_bar_ek6.style.height = "18px";
status_bar_ek6.style.left = "20px";
status_bar_ek6.style.top = "16px";
status_bar_ek6.style.position = "absolute";
page_onboard_1_ek1.appendChild(status_bar_ek6);

var wifi_ek9 = document.createElement("img");
wifi_ek9.id = "wifi_ek9";
wifi_ek9.style.left = "287px";
wifi_ek9.style.top = "4px";
wifi_ek9.style.width = "14.94px";
wifi_ek9.style.height = "10px";
wifi_ek9.src = "skins/wifi_ek9.png";

status_bar_ek6.appendChild(wifi_ek9);

var time_ek6 = document.createElement("div");
time_ek6.innerHTML = "9:41 AM";
time_ek6.style.textAlign = "center";
time_ek6.id = "time_ek6";
time_ek6.style.left = "-2px";
time_ek6.style.top = "0px";
time_ek6.style.width = "62px";
time_ek6.style.height = "26px";
time_ek6.style.fontFamily = "Poppins";
time_ek6.style.fontSize = "12px";
time_ek6.style.overflow = "hidden";
time_ek6.style.color = "#030303";

status_bar_ek6.appendChild(time_ek6);

var battery_ek6 = document.createElement("div");
battery_ek6.id = "battery_ek6";
battery_ek6.style.width = "27.61px";
battery_ek6.style.height = "11.5px";
battery_ek6.style.left = "352px";
battery_ek6.style.top = "4px";
battery_ek6.style.position = "absolute";
status_bar_ek6.appendChild(battery_ek6);

var border_ek6 = document.createElement("img");
border_ek6.id = "border_ek6";
border_ek6.style.left = "0px";
border_ek6.style.opacity = "0.40000000596046";
border_ek6.style.filter = "alpha(opacity='40.000000596046')";
border_ek6.style.top = "0px";
border_ek6.style.width = "25px";
border_ek6.style.height = "11.5px";
border_ek6.src = "skins/border_ek6.png";

battery_ek6.appendChild(border_ek6);

var nub_ek6 = document.createElement("img");
nub_ek6.id = "nub_ek6";
nub_ek6.style.left = "26px";
nub_ek6.style.opacity = "0.40000000596046";
nub_ek6.style.filter = "alpha(opacity='40.000000596046')";
nub_ek6.style.top = "4px";
nub_ek6.style.width = "1.56px";
nub_ek6.style.height = "3.87px";
nub_ek6.src = "skins/nub_ek6.png";

battery_ek6.appendChild(nub_ek6);

var charge_ek6 = document.createElement("img");
charge_ek6.id = "charge_ek6";
charge_ek6.style.left = "2px";
charge_ek6.style.top = "2px";
charge_ek6.style.width = "20.83px";
charge_ek6.style.height = "7.5px";
charge_ek6.src = "skins/charge_ek6.png";

battery_ek6.appendChild(charge_ek6);

var mobile_signal_ek6 = document.createElement("img");
mobile_signal_ek6.id = "mobile_signal_ek6";
mobile_signal_ek6.style.left = "318px";
mobile_signal_ek6.style.top = "3px";
mobile_signal_ek6.style.width = "17.19px";
mobile_signal_ek6.style.height = "10px";
mobile_signal_ek6.src = "skins/mobile_signal_ek6.png";

status_bar_ek6.appendChild(mobile_signal_ek6);


