/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);


var page_personality_2_ek1 = document.createElement("div");
page_personality_2_ek1.id = "page_personality_2_ek1";
page_personality_2_ek1.style.width = "428px";
page_personality_2_ek1.style.height = "826px";
page_personality_2_ek1.style.left = "0px";
page_personality_2_ek1.style.top = "0px";
page_personality_2_ek1.style.position = "absolute";
content_container.appendChild(page_personality_2_ek1);

var _bg__personality_2_ek2 = document.createElement("div");
_bg__personality_2_ek2.id = "_bg__personality_2_ek2";
_bg__personality_2_ek2.style.left = "0px";
_bg__personality_2_ek2.style.top = "0px";
_bg__personality_2_ek2.style.width = "428px";
_bg__personality_2_ek2.style.height = "826px";
_bg__personality_2_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_personality_2_ek1.appendChild(_bg__personality_2_ek2);

var rectangle_13_ek1 = document.createElement("div");
rectangle_13_ek1.id = "rectangle_13_ek1";
rectangle_13_ek1.style.left = "22px";
rectangle_13_ek1.style.top = "43px";
rectangle_13_ek1.style.width = "385px";
rectangle_13_ek1.style.height = "7px";
rectangle_13_ek1.style.borderRadius = "7px";
rectangle_13_ek1.style.background = 'rgba(205.2,205.2,205.2,1)';

page_personality_2_ek1.appendChild(rectangle_13_ek1);

var rectangle_14_ek1 = document.createElement("div");
rectangle_14_ek1.id = "rectangle_14_ek1";
rectangle_14_ek1.style.left = "22px";
rectangle_14_ek1.style.top = "43px";
rectangle_14_ek1.style.width = "159px";
rectangle_14_ek1.style.height = "7px";
rectangle_14_ek1.style.borderRadius = "7px";
rectangle_14_ek1.style.background = 'rgba(203,90,122,1)';

page_personality_2_ek1.appendChild(rectangle_14_ek1);

var steps_2_4_personality = document.createElement("div");
steps_2_4_personality.innerHTML = "Steps 2/4 Personality";
steps_2_4_personality.style.textAlign = "left";
steps_2_4_personality.id = "steps_2_4_personality";
steps_2_4_personality.style.left = "22px";
steps_2_4_personality.style.top = "22px";
steps_2_4_personality.style.width = "166px";
steps_2_4_personality.style.height = "31px";
steps_2_4_personality.style.fontFamily = "Poppins";
steps_2_4_personality.style.fontSize = "14px";
steps_2_4_personality.style.overflow = "hidden";
steps_2_4_personality.style.color = "#000000";

page_personality_2_ek1.appendChild(steps_2_4_personality);

var what_are_your_hobbies = document.createElement("div");
what_are_your_hobbies.innerHTML = "What are your Hobbies";
what_are_your_hobbies.style.fontWeight = "bold";
what_are_your_hobbies.style.textAlign = "left";
what_are_your_hobbies.id = "what_are_your_hobbies";
what_are_your_hobbies.style.left = "22px";
what_are_your_hobbies.style.top = "64px";
what_are_your_hobbies.style.width = "182px";
what_are_your_hobbies.style.height = "31px";
what_are_your_hobbies.style.fontFamily = "Poppins";
what_are_your_hobbies.style.fontSize = "14px";
what_are_your_hobbies.style.overflow = "hidden";
what_are_your_hobbies.style.color = "#000000";

page_personality_2_ek1.appendChild(what_are_your_hobbies);

var please_choose_all_that_apply_ek1 = document.createElement("div");
please_choose_all_that_apply_ek1.innerHTML = "Please choose all that apply";
please_choose_all_that_apply_ek1.style.textAlign = "left";
please_choose_all_that_apply_ek1.id = "please_choose_all_that_apply_ek1";
please_choose_all_that_apply_ek1.style.left = "28px";
please_choose_all_that_apply_ek1.style.top = "85px";
please_choose_all_that_apply_ek1.style.width = "152px";
please_choose_all_that_apply_ek1.style.height = "22px";
please_choose_all_that_apply_ek1.style.fontFamily = "Poppins";
please_choose_all_that_apply_ek1.style.fontSize = "10px";
please_choose_all_that_apply_ek1.style.overflow = "hidden";
please_choose_all_that_apply_ek1.style.color = "#000000";

page_personality_2_ek1.appendChild(please_choose_all_that_apply_ek1);

var rectangle_15_ek1 = document.createElement("div");
rectangle_15_ek1.id = "rectangle_15_ek1";
rectangle_15_ek1.style.left = "22px";
rectangle_15_ek1.style.top = "121px";
rectangle_15_ek1.style.width = "82px";
rectangle_15_ek1.style.height = "32px";
rectangle_15_ek1.style.borderRadius = "20px";
rectangle_15_ek1.style.background = 'rgba(203,90,122,1)';

page_personality_2_ek1.appendChild(rectangle_15_ek1);

var rectangle_19_ek1 = document.createElement("div");
rectangle_19_ek1.id = "rectangle_19_ek1";
rectangle_19_ek1.style.left = "22px";
rectangle_19_ek1.style.top = "174px";
rectangle_19_ek1.style.width = "82px";
rectangle_19_ek1.style.height = "32px";
rectangle_19_ek1.style.borderRadius = "20px";
rectangle_19_ek1.style.background = 'rgba(203,90,122,1)';

page_personality_2_ek1.appendChild(rectangle_19_ek1);

var rectangle_22_ek1 = document.createElement("div");
rectangle_22_ek1.id = "rectangle_22_ek1";
rectangle_22_ek1.style.left = "118px";
rectangle_22_ek1.style.top = "174px";
rectangle_22_ek1.style.width = "82px";
rectangle_22_ek1.style.height = "32px";
rectangle_22_ek1.style.borderRadius = "20px";
rectangle_22_ek1.style.background = 'rgba(203,90,122,1)';

page_personality_2_ek1.appendChild(rectangle_22_ek1);

var cooking = document.createElement("div");
cooking.innerHTML = "Cooking";
cooking.style.textAlign = "left";
cooking.id = "cooking";
cooking.style.left = "137px";
cooking.style.top = "183px";
cooking.style.width = "57px";
cooking.style.height = "22px";
cooking.style.fontFamily = "Poppins";
cooking.style.fontSize = "10px";
cooking.style.overflow = "hidden";
cooking.style.color = "#FFFFFF";

page_personality_2_ek1.appendChild(cooking);

var rectangle_23_ek1 = document.createElement("div");
rectangle_23_ek1.id = "rectangle_23_ek1";
rectangle_23_ek1.style.left = "214px";
rectangle_23_ek1.style.top = "174px";
rectangle_23_ek1.style.width = "82px";
rectangle_23_ek1.style.height = "32px";
rectangle_23_ek1.style.borderRadius = "20px";
rectangle_23_ek1.style.background = 'rgba(203,90,122,1)';

page_personality_2_ek1.appendChild(rectangle_23_ek1);

var photography = document.createElement("div");
photography.innerHTML = "Photography";
photography.style.textAlign = "left";
photography.id = "photography";
photography.style.left = "222px";
photography.style.top = "183px";
photography.style.width = "81px";
photography.style.height = "22px";
photography.style.fontFamily = "Poppins";
photography.style.fontSize = "10px";
photography.style.overflow = "hidden";
photography.style.color = "#FFFFFF";

page_personality_2_ek1.appendChild(photography);

var football = document.createElement("div");
football.innerHTML = "Football";
football.style.textAlign = "left";
football.id = "football";
football.style.left = "333px";
football.style.top = "183px";
football.style.width = "56px";
football.style.height = "22px";
football.style.fontFamily = "Poppins";
football.style.fontSize = "10px";
football.style.overflow = "hidden";
football.style.color = "#CB5A7A";

page_personality_2_ek1.appendChild(football);

var rectangle_24_ek1 = document.createElement("div");
rectangle_24_ek1.id = "rectangle_24_ek1";
rectangle_24_ek1.style.left = "310px";
rectangle_24_ek1.style.top = "174px";
rectangle_24_ek1.style.width = "84px";
rectangle_24_ek1.style.height = "34px";
rectangle_24_ek1.style.borderRadius = "20px";
rectangle_24_ek1.style.border = "1px solid #cb5a7a";
rectangle_24_ek1.style.background = 'rgba(255,255,255,0)';

page_personality_2_ek1.appendChild(rectangle_24_ek1);

var rectangle_20_ek1 = document.createElement("div");
rectangle_20_ek1.id = "rectangle_20_ek1";
rectangle_20_ek1.style.left = "22px";
rectangle_20_ek1.style.top = "227px";
rectangle_20_ek1.style.width = "82px";
rectangle_20_ek1.style.height = "32px";
rectangle_20_ek1.style.borderRadius = "20px";
rectangle_20_ek1.style.background = 'rgba(203,90,122,1)';

page_personality_2_ek1.appendChild(rectangle_20_ek1);

var swimming = document.createElement("div");
swimming.innerHTML = "Swimming";
swimming.style.textAlign = "left";
swimming.id = "swimming";
swimming.style.left = "36px";
swimming.style.top = "236px";
swimming.style.width = "69px";
swimming.style.height = "22px";
swimming.style.fontFamily = "Poppins";
swimming.style.fontSize = "10px";
swimming.style.overflow = "hidden";
swimming.style.color = "#FFFFFF";

page_personality_2_ek1.appendChild(swimming);

var rectangle_25_ek1 = document.createElement("div");
rectangle_25_ek1.id = "rectangle_25_ek1";
rectangle_25_ek1.style.left = "118px";
rectangle_25_ek1.style.top = "227px";
rectangle_25_ek1.style.width = "84px";
rectangle_25_ek1.style.height = "34px";
rectangle_25_ek1.style.borderRadius = "20px";
rectangle_25_ek1.style.border = "1px solid #cb5a7a";
rectangle_25_ek1.style.background = 'rgba(255,255,255,0)';

page_personality_2_ek1.appendChild(rectangle_25_ek1);

var basketball = document.createElement("div");
basketball.innerHTML = "Basketball";
basketball.style.textAlign = "left";
basketball.id = "basketball";
basketball.style.left = "132px";
basketball.style.top = "236px";
basketball.style.width = "68px";
basketball.style.height = "22px";
basketball.style.fontFamily = "Poppins";
basketball.style.fontSize = "10px";
basketball.style.overflow = "hidden";
basketball.style.color = "#CB5A7A";

page_personality_2_ek1.appendChild(basketball);

var rectangle_26_ek1 = document.createElement("div");
rectangle_26_ek1.id = "rectangle_26_ek1";
rectangle_26_ek1.style.left = "214px";
rectangle_26_ek1.style.top = "227px";
rectangle_26_ek1.style.width = "84px";
rectangle_26_ek1.style.height = "34px";
rectangle_26_ek1.style.borderRadius = "20px";
rectangle_26_ek1.style.border = "1px solid #cb5a7a";
rectangle_26_ek1.style.background = 'rgba(255,255,255,0)';

page_personality_2_ek1.appendChild(rectangle_26_ek1);

var singing = document.createElement("div");
singing.innerHTML = "Singing";
singing.style.textAlign = "left";
singing.id = "singing";
singing.style.left = "238px";
singing.style.top = "236px";
singing.style.width = "53px";
singing.style.height = "22px";
singing.style.fontFamily = "Poppins";
singing.style.fontSize = "10px";
singing.style.overflow = "hidden";
singing.style.color = "#CB5A7A";

page_personality_2_ek1.appendChild(singing);

var l_ek1 = document.createElement("div");
l_ek1.innerHTML = "l";
l_ek1.style.textAlign = "left";
l_ek1.id = "l_ek1";
l_ek1.style.left = "340px";
l_ek1.style.top = "240px";
l_ek1.style.width = "18px";
l_ek1.style.height = "22px";
l_ek1.style.fontFamily = "Poppins";
l_ek1.style.fontSize = "10px";
l_ek1.style.overflow = "hidden";
l_ek1.style.color = "#000000";

page_personality_2_ek1.appendChild(l_ek1);

var rectangle_27_ek1 = document.createElement("div");
rectangle_27_ek1.id = "rectangle_27_ek1";
rectangle_27_ek1.style.left = "310px";
rectangle_27_ek1.style.top = "227px";
rectangle_27_ek1.style.width = "82px";
rectangle_27_ek1.style.height = "32px";
rectangle_27_ek1.style.borderRadius = "20px";
rectangle_27_ek1.style.background = 'rgba(203,90,122,1)';

page_personality_2_ek1.appendChild(rectangle_27_ek1);

var rectangle_21_ek1 = document.createElement("div");
rectangle_21_ek1.id = "rectangle_21_ek1";
rectangle_21_ek1.style.left = "22px";
rectangle_21_ek1.style.top = "280px";
rectangle_21_ek1.style.width = "84px";
rectangle_21_ek1.style.height = "34px";
rectangle_21_ek1.style.borderRadius = "20px";
rectangle_21_ek1.style.border = "1px solid #cb5a7a";
rectangle_21_ek1.style.background = 'rgba(255,255,255,0)';

page_personality_2_ek1.appendChild(rectangle_21_ek1);

var movie = document.createElement("div");
movie.innerHTML = "Movie";
movie.style.textAlign = "left";
movie.id = "movie";
movie.style.left = "47px";
movie.style.top = "289px";
movie.style.width = "45px";
movie.style.height = "22px";
movie.style.fontFamily = "Poppins";
movie.style.fontSize = "10px";
movie.style.overflow = "hidden";
movie.style.color = "#CB5A7A";

page_personality_2_ek1.appendChild(movie);

var rectangle_28_ek1 = document.createElement("div");
rectangle_28_ek1.id = "rectangle_28_ek1";
rectangle_28_ek1.style.left = "118px";
rectangle_28_ek1.style.top = "280px";
rectangle_28_ek1.style.width = "84px";
rectangle_28_ek1.style.height = "34px";
rectangle_28_ek1.style.borderRadius = "20px";
rectangle_28_ek1.style.border = "1px solid #cb5a7a";
rectangle_28_ek1.style.background = 'rgba(255,255,255,0)';

page_personality_2_ek1.appendChild(rectangle_28_ek1);

var rectangle_29_ek1 = document.createElement("div");
rectangle_29_ek1.id = "rectangle_29_ek1";
rectangle_29_ek1.style.left = "118px";
rectangle_29_ek1.style.top = "280px";
rectangle_29_ek1.style.width = "84px";
rectangle_29_ek1.style.height = "34px";
rectangle_29_ek1.style.borderRadius = "20px";
rectangle_29_ek1.style.border = "1px solid #cb5a7a";
rectangle_29_ek1.style.background = 'rgba(255,255,255,0)';

page_personality_2_ek1.appendChild(rectangle_29_ek1);

var rectangle_30 = document.createElement("div");
rectangle_30.id = "rectangle_30";
rectangle_30.style.left = "214px";
rectangle_30.style.top = "280px";
rectangle_30.style.width = "84px";
rectangle_30.style.height = "34px";
rectangle_30.style.borderRadius = "20px";
rectangle_30.style.border = "1px solid #cb5a7a";
rectangle_30.style.background = 'rgba(255,255,255,0)';

page_personality_2_ek1.appendChild(rectangle_30);

var rectangle_16_ek1 = document.createElement("div");
rectangle_16_ek1.id = "rectangle_16_ek1";
rectangle_16_ek1.style.left = "118px";
rectangle_16_ek1.style.top = "121px";
rectangle_16_ek1.style.width = "84px";
rectangle_16_ek1.style.height = "34px";
rectangle_16_ek1.style.borderRadius = "20px";
rectangle_16_ek1.style.border = "1px solid #cb5a7a";
rectangle_16_ek1.style.background = 'rgba(255,255,255,0)';

page_personality_2_ek1.appendChild(rectangle_16_ek1);

var rectangle_17_ek1 = document.createElement("div");
rectangle_17_ek1.id = "rectangle_17_ek1";
rectangle_17_ek1.style.left = "214px";
rectangle_17_ek1.style.top = "121px";
rectangle_17_ek1.style.width = "84px";
rectangle_17_ek1.style.height = "34px";
rectangle_17_ek1.style.borderRadius = "20px";
rectangle_17_ek1.style.border = "1px solid #cb5a7a";
rectangle_17_ek1.style.background = 'rgba(255,255,255,0)';

page_personality_2_ek1.appendChild(rectangle_17_ek1);

var food = document.createElement("div");
food.innerHTML = "Food";
food.style.textAlign = "left";
food.id = "food";
food.style.left = "241px";
food.style.top = "130px";
food.style.width = "40px";
food.style.height = "22px";
food.style.fontFamily = "Poppins";
food.style.fontSize = "10px";
food.style.overflow = "hidden";
food.style.color = "#CB5A7A";

page_personality_2_ek1.appendChild(food);

var gaming = document.createElement("div");
gaming.innerHTML = "Gaming";
gaming.style.textAlign = "left";
gaming.id = "gaming";
gaming.style.left = "42px";
gaming.style.top = "183px";
gaming.style.width = "56px";
gaming.style.height = "22px";
gaming.style.fontFamily = "Poppins";
gaming.style.fontSize = "10px";
gaming.style.overflow = "hidden";
gaming.style.color = "#FFFFFF";

page_personality_2_ek1.appendChild(gaming);

var music = document.createElement("div");
music.innerHTML = "Music";
music.style.textAlign = "left";
music.id = "music";
music.style.left = "51px";
music.style.top = "130px";
music.style.width = "45px";
music.style.height = "22px";
music.style.fontFamily = "Poppins";
music.style.fontSize = "10px";
music.style.overflow = "hidden";
music.style.color = "#FFFFFF";

page_personality_2_ek1.appendChild(music);

var shopping = document.createElement("div");
shopping.innerHTML = "Shopping";
shopping.style.textAlign = "left";
shopping.id = "shopping";
shopping.style.left = "135px";
shopping.style.top = "130px";
shopping.style.width = "64px";
shopping.style.height = "22px";
shopping.style.fontFamily = "Poppins";
shopping.style.fontSize = "10px";
shopping.style.overflow = "hidden";
shopping.style.color = "#CB5A7A";

page_personality_2_ek1.appendChild(shopping);

var rectangle_18_ek1 = document.createElement("div");
rectangle_18_ek1.id = "rectangle_18_ek1";
rectangle_18_ek1.style.left = "310px";
rectangle_18_ek1.style.top = "121px";
rectangle_18_ek1.style.width = "82px";
rectangle_18_ek1.style.height = "32px";
rectangle_18_ek1.style.borderRadius = "20px";
rectangle_18_ek1.style.background = 'rgba(203,90,122,1)';

page_personality_2_ek1.appendChild(rectangle_18_ek1);

var reading = document.createElement("div");
reading.innerHTML = "Reading";
reading.style.textAlign = "left";
reading.id = "reading";
reading.style.left = "329px";
reading.style.top = "130px";
reading.style.width = "57px";
reading.style.height = "22px";
reading.style.fontFamily = "Poppins";
reading.style.fontSize = "10px";
reading.style.overflow = "hidden";
reading.style.color = "#FFFFFF";

page_personality_2_ek1.appendChild(reading);

var anime = document.createElement("div");
anime.innerHTML = "Anime";
anime.style.textAlign = "left";
anime.id = "anime";
anime.style.left = "338px";
anime.style.top = "236px";
anime.style.width = "48px";
anime.style.height = "22px";
anime.style.fontFamily = "Poppins";
anime.style.fontSize = "10px";
anime.style.overflow = "hidden";
anime.style.color = "#F9FDFF";

page_personality_2_ek1.appendChild(anime);

var comedy = document.createElement("div");
comedy.innerHTML = "Comedy";
comedy.style.textAlign = "left";
comedy.id = "comedy";
comedy.style.left = "137px";
comedy.style.top = "289px";
comedy.style.width = "59px";
comedy.style.height = "22px";
comedy.style.fontFamily = "Poppins";
comedy.style.fontSize = "10px";
comedy.style.overflow = "hidden";
comedy.style.color = "#CB5A7A";

page_personality_2_ek1.appendChild(comedy);

var tech = document.createElement("div");
tech.innerHTML = "Tech";
tech.style.textAlign = "left";
tech.id = "tech";
tech.style.left = "241px";
tech.style.top = "288px";
tech.style.width = "40px";
tech.style.height = "22px";
tech.style.fontFamily = "Poppins";
tech.style.fontSize = "10px";
tech.style.overflow = "hidden";
tech.style.color = "#CB5A7A";

page_personality_2_ek1.appendChild(tech);

var _next_ek1 = document.createElement("div");
_next_ek1.innerHTML = "Next";
_next_ek1.style.fontWeight = "bold";
_next_ek1.style.textAlign = "center";
_next_ek1.id = "_next_ek1";
_next_ek1.style.left = "361px";
_next_ek1.style.top = "734px";
_next_ek1.style.width = "57px";
_next_ek1.style.height = "40px";
_next_ek1.style.fontFamily = "Poppins";
_next_ek1.style.fontSize = "18px";
_next_ek1.style.overflow = "hidden";
_next_ek1.style.color = "#000000";

page_personality_2_ek1.appendChild(_next_ek1);

_next_ek1.style.cursor = "pointer";
_next_ek1.onclick = (e) => {
	@page_view("personality_3");
}














