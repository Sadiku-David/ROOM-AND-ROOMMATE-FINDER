/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);








var page_email_verification_ek1 = document.createElement("div");
page_email_verification_ek1.id = "page_email_verification_ek1";
page_email_verification_ek1.style.width = "414px";
page_email_verification_ek1.style.height = "826px";
page_email_verification_ek1.style.left = "0px";
page_email_verification_ek1.style.top = "0px";
page_email_verification_ek1.style.position = "absolute";
content_container.appendChild(page_email_verification_ek1);

var _bg__email_verification_ek2 = document.createElement("div");
_bg__email_verification_ek2.id = "_bg__email_verification_ek2";
_bg__email_verification_ek2.style.left = "0px";
_bg__email_verification_ek2.style.top = "0px";
_bg__email_verification_ek2.style.width = "414px";
_bg__email_verification_ek2.style.height = "826px";
_bg__email_verification_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_email_verification_ek1.appendChild(_bg__email_verification_ek2);

var sign_up_ek5 = document.createElement("div");
sign_up_ek5.innerHTML = "Sign up";
sign_up_ek5.style.textAlign = "left";
sign_up_ek5.id = "sign_up_ek5";
sign_up_ek5.style.left = "186px";
sign_up_ek5.style.top = "650px";
sign_up_ek5.style.width = "58px";
sign_up_ek5.style.height = "25px";
sign_up_ek5.style.fontFamily = "Coda";
sign_up_ek5.style.fontSize = "12px";
sign_up_ek5.style.overflow = "hidden";
sign_up_ek5.style.color = "#FFFFFF";

page_email_verification_ek1.appendChild(sign_up_ek5);

var verification = document.createElement("div");
verification.innerHTML = "Verification";
verification.style.textAlign = "left";
verification.id = "verification";
verification.style.left = "151px";
verification.style.top = "58px";
verification.style.width = "127px";
verification.style.height = "40px";
verification.style.fontFamily = "Poppins";
verification.style.fontSize = "18px";
verification.style.overflow = "hidden";
verification.style.color = "#000000";

page_email_verification_ek1.appendChild(verification);

var ellipse_5 = document.createElement("div");
ellipse_5.id = "ellipse_5";
ellipse_5.style.left = "138px";
ellipse_5.style.opacity = "0.15999999642372";
ellipse_5.style.filter = "alpha(opacity='15.999999642372')";
ellipse_5.style.top = "118px";
ellipse_5.style.width = "129px";
ellipse_5.style.height = "129px";
ellipse_5.style.borderRadius = "64.5px / 64.5px";
ellipse_5.style.background = 'rgba(85,9,9,0.16)';

page_email_verification_ek1.appendChild(ellipse_5);

var sign_mail = document.createElement("img");
sign_mail.id = "sign_mail";
sign_mail.style.left = "162px";
sign_mail.style.top = "142px";
sign_mail.style.width = "81px";
sign_mail.style.height = "81px";
sign_mail.src = "skins/sign_mail.png";

page_email_verification_ek1.appendChild(sign_mail);

var enter_your_verification_code = document.createElement("div");
enter_your_verification_code.innerHTML = "Enter your Verification Code";
enter_your_verification_code.style.fontWeight = "bold";
enter_your_verification_code.style.textAlign = "center";
enter_your_verification_code.id = "enter_your_verification_code";
enter_your_verification_code.style.left = "40px";
enter_your_verification_code.style.top = "290px";
enter_your_verification_code.style.width = "300px";
enter_your_verification_code.style.height = "44px";
enter_your_verification_code.style.fontFamily = "Poppins";
enter_your_verification_code.style.fontSize = "20px";
enter_your_verification_code.style.overflow = "hidden";
enter_your_verification_code.style.color = "#000000";

page_email_verification_ek1.appendChild(enter_your_verification_code);

var rectangle_5_ek1 = document.createElement("div");
rectangle_5_ek1.id = "rectangle_5_ek1";
rectangle_5_ek1.style.left = "43px";
rectangle_5_ek1.style.top = "360px";
rectangle_5_ek1.style.width = "72px";
rectangle_5_ek1.style.height = "72px";
rectangle_5_ek1.style.borderRadius = "10px";
rectangle_5_ek1.style.border = "2px solid #cb5a7a";
rectangle_5_ek1.style.background = 'rgba(255,255,255,0)';

page_email_verification_ek1.appendChild(rectangle_5_ek1);

var rectangle_6 = document.createElement("div");
rectangle_6.id = "rectangle_6";
rectangle_6.style.left = "298px";
rectangle_6.style.top = "360px";
rectangle_6.style.width = "72px";
rectangle_6.style.height = "72px";
rectangle_6.style.borderRadius = "10px";
rectangle_6.style.border = "2px solid #cb5a7a";
rectangle_6.style.background = 'rgba(255,255,255,0)';

page_email_verification_ek1.appendChild(rectangle_6);

var rectangle_7 = document.createElement("div");
rectangle_7.id = "rectangle_7";
rectangle_7.style.left = "213px";
rectangle_7.style.top = "360px";
rectangle_7.style.width = "72px";
rectangle_7.style.height = "72px";
rectangle_7.style.borderRadius = "10px";
rectangle_7.style.border = "2px solid #cb5a7a";
rectangle_7.style.background = 'rgba(255,255,255,0)';

page_email_verification_ek1.appendChild(rectangle_7);

var rectangle_8 = document.createElement("div");
rectangle_8.id = "rectangle_8";
rectangle_8.style.left = "128px";
rectangle_8.style.top = "360px";
rectangle_8.style.width = "72px";
rectangle_8.style.height = "72px";
rectangle_8.style.borderRadius = "10px";
rectangle_8.style.border = "2px solid #cb5a7a";
rectangle_8.style.background = 'rgba(255,255,255,0)';

page_email_verification_ek1.appendChild(rectangle_8);

var _04_59 = document.createElement("div");
_04_59.innerHTML = "04:59";
_04_59.style.fontWeight = "bold";
_04_59.style.textAlign = "center";
_04_59.id = "_04_59";
_04_59.style.left = "40px";
_04_59.style.top = "461px";
_04_59.style.width = "66px";
_04_59.style.height = "40px";
_04_59.style.fontFamily = "Poppins";
_04_59.style.fontSize = "18px";
_04_59.style.overflow = "hidden";
_04_59.style.color = "#CB5A7A";

page_email_verification_ek1.appendChild(_04_59);

var we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox = document.createElement("div");
we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox.innerHTML = "<span style=\"font-style:normal; text-decoration:NONE; \">We sent your Verification code to your <br/>email </span><span style=\"color:#CB5A7A; font-style:normal; text-decoration:NONE; \">someone*****@gmail.com.  </span><span style=\"font-style:normal; text-decoration:NONE; \">You<br/>can check your inbo</span>";
we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox.style.fontWeight = "bold";
we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox.style.textAlign = "left";
we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox.id = "we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox";
we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox.style.left = "43px";
we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox.style.top = "499px";
we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox.style.width = "378px";
we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox.style.height = "94px";
we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox.style.fontFamily = "Poppins";
we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox.style.fontSize = "18px";
we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox.style.overflow = "hidden";
we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox.style.color = "#000000";

page_email_verification_ek1.appendChild(we_sent_your_verification_code_to_your_email_someone______gmail_com__you_can_check_your_inbox);

var i_didn_t_recieve_the_code__send_again = document.createElement("div");
i_didn_t_recieve_the_code__send_again.innerHTML = "I didn\'t recieve the code? Send again";
i_didn_t_recieve_the_code__send_again.style.fontWeight = "bold";
i_didn_t_recieve_the_code__send_again.style.textAlign = "left";
i_didn_t_recieve_the_code__send_again.style.textDecoration = "underline";
i_didn_t_recieve_the_code__send_again.id = "i_didn_t_recieve_the_code__send_again";
i_didn_t_recieve_the_code__send_again.style.left = "43px";
i_didn_t_recieve_the_code__send_again.style.top = "613px";
i_didn_t_recieve_the_code__send_again.style.width = "360px";
i_didn_t_recieve_the_code__send_again.style.height = "40px";
i_didn_t_recieve_the_code__send_again.style.fontFamily = "Poppins";
i_didn_t_recieve_the_code__send_again.style.fontSize = "18px";
i_didn_t_recieve_the_code__send_again.style.overflow = "hidden";
i_didn_t_recieve_the_code__send_again.style.color = "#CB5A7A";

page_email_verification_ek1.appendChild(i_didn_t_recieve_the_code__send_again);

var _rectangle_2_ek2 = document.createElement("div");
_rectangle_2_ek2.id = "_rectangle_2_ek2";
_rectangle_2_ek2.style.left = "78px";
_rectangle_2_ek2.style.top = "707px";
_rectangle_2_ek2.style.width = "270px";
_rectangle_2_ek2.style.height = "52px";
_rectangle_2_ek2.style.borderRadius = "20px";
_rectangle_2_ek2.style.background = 'rgba(203,90,122,1)';

page_email_verification_ek1.appendChild(_rectangle_2_ek2);

_rectangle_2_ek2.style.cursor = "pointer";
_rectangle_2_ek2.onclick = (e) => {
	@page_view("id_verification");
}

var continue = document.createElement("div");
continue.innerHTML = "Continue";
continue.style.fontWeight = "bold";
continue.style.textAlign = "left";
continue.id = "continue";
continue.style.left = "172px";
continue.style.top = "720px";
continue.style.width = "108px";
continue.style.height = "40px";
continue.style.fontFamily = "Poppins";
continue.style.fontSize = "18px";
continue.style.overflow = "hidden";
continue.style.color = "#FFFFFF";

page_email_verification_ek1.appendChild(continue);

var status_bar_ek3 = document.createElement("div");
status_bar_ek3.id = "status_bar_ek3";
status_bar_ek3.style.width = "387px";
status_bar_ek3.style.height = "18px";
status_bar_ek3.style.left = "11px";
status_bar_ek3.style.top = "9px";
status_bar_ek3.style.position = "absolute";
page_email_verification_ek1.appendChild(status_bar_ek3);

var wifi_ek6 = document.createElement("img");
wifi_ek6.id = "wifi_ek6";
wifi_ek6.style.left = "294px";
wifi_ek6.style.top = "5px";
wifi_ek6.style.width = "14.94px";
wifi_ek6.style.height = "10px";
wifi_ek6.src = "skins/wifi_ek6.png";

status_bar_ek3.appendChild(wifi_ek6);

var time_ek3 = document.createElement("div");
time_ek3.innerHTML = "9:41 AM";
time_ek3.style.textAlign = "center";
time_ek3.id = "time_ek3";
time_ek3.style.left = "-2px";
time_ek3.style.top = "0px";
time_ek3.style.width = "62px";
time_ek3.style.height = "26px";
time_ek3.style.fontFamily = "Poppins";
time_ek3.style.fontSize = "12px";
time_ek3.style.overflow = "hidden";
time_ek3.style.color = "#030303";

status_bar_ek3.appendChild(time_ek3);

var battery_ek3 = document.createElement("div");
battery_ek3.id = "battery_ek3";
battery_ek3.style.width = "27.61px";
battery_ek3.style.height = "11.5px";
battery_ek3.style.left = "359px";
battery_ek3.style.top = "5px";
battery_ek3.style.position = "absolute";
status_bar_ek3.appendChild(battery_ek3);

var border_ek3 = document.createElement("img");
border_ek3.id = "border_ek3";
border_ek3.style.left = "0px";
border_ek3.style.opacity = "0.40000000596046";
border_ek3.style.filter = "alpha(opacity='40.000000596046')";
border_ek3.style.top = "0px";
border_ek3.style.width = "25px";
border_ek3.style.height = "11.5px";
border_ek3.src = "skins/border_ek3.png";

battery_ek3.appendChild(border_ek3);

var nub_ek3 = document.createElement("img");
nub_ek3.id = "nub_ek3";
nub_ek3.style.left = "26px";
nub_ek3.style.opacity = "0.40000000596046";
nub_ek3.style.filter = "alpha(opacity='40.000000596046')";
nub_ek3.style.top = "4px";
nub_ek3.style.width = "1.56px";
nub_ek3.style.height = "3.87px";
nub_ek3.src = "skins/nub_ek3.png";

battery_ek3.appendChild(nub_ek3);

var charge_ek3 = document.createElement("img");
charge_ek3.id = "charge_ek3";
charge_ek3.style.left = "2px";
charge_ek3.style.top = "2px";
charge_ek3.style.width = "20.83px";
charge_ek3.style.height = "7.5px";
charge_ek3.src = "skins/charge_ek3.png";

battery_ek3.appendChild(charge_ek3);

var mobile_signal_ek3 = document.createElement("img");
mobile_signal_ek3.id = "mobile_signal_ek3";
mobile_signal_ek3.style.left = "325px";
mobile_signal_ek3.style.top = "4px";
mobile_signal_ek3.style.width = "17.19px";
mobile_signal_ek3.style.height = "10px";
mobile_signal_ek3.src = "skins/mobile_signal_ek3.png";

status_bar_ek3.appendChild(mobile_signal_ek3);








