/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);












var page_room_search_ek1 = document.createElement("div");
page_room_search_ek1.id = "page_room_search_ek1";
page_room_search_ek1.style.width = "428px";
page_room_search_ek1.style.height = "826px";
page_room_search_ek1.style.left = "0px";
page_room_search_ek1.style.top = "0px";
page_room_search_ek1.style.position = "absolute";
content_container.appendChild(page_room_search_ek1);

var _bg__room_search_ek2 = document.createElement("div");
_bg__room_search_ek2.id = "_bg__room_search_ek2";
_bg__room_search_ek2.style.left = "0px";
_bg__room_search_ek2.style.top = "0px";
_bg__room_search_ek2.style.width = "428px";
_bg__room_search_ek2.style.height = "826px";
_bg__room_search_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_room_search_ek1.appendChild(_bg__room_search_ek2);

var rectangle_53_ek4 = document.createElement("div");
rectangle_53_ek4.id = "rectangle_53_ek4";
rectangle_53_ek4.style.left = "0px";
rectangle_53_ek4.style.top = "0px";
rectangle_53_ek4.style.width = "428px";
rectangle_53_ek4.style.height = "89px";
rectangle_53_ek4.style.background = 'rgba(203,90,122,1)';

page_room_search_ek1.appendChild(rectangle_53_ek4);

var _558_matches = document.createElement("div");
_558_matches.innerHTML = "558 Matches";
_558_matches.style.textAlign = "left";
_558_matches.id = "_558_matches";
_558_matches.style.left = "57px";
_558_matches.style.top = "44px";
_558_matches.style.width = "101.5px";
_558_matches.style.height = "29.5px";
_558_matches.style.fontFamily = "Poppins";
_558_matches.style.fontSize = "13px";
_558_matches.style.overflow = "hidden";
_558_matches.style.color = "#FFFFFF";

page_room_search_ek1.appendChild(_558_matches);

var eva_arrow_back_outline = document.createElement("div");
eva_arrow_back_outline.id = "eva_arrow_back_outline";
eva_arrow_back_outline.style.width = "33px";
eva_arrow_back_outline.style.height = "33px";
eva_arrow_back_outline.style.left = "12px";
eva_arrow_back_outline.style.top = "36px";
eva_arrow_back_outline.style.position = "absolute";
page_room_search_ek1.appendChild(eva_arrow_back_outline);

var vector_ek61 = document.createElement("img");
vector_ek61.id = "vector_ek61";
vector_ek61.style.left = "5.5px";
vector_ek61.style.top = "6.87px";
vector_ek61.style.width = "22px";
vector_ek61.style.height = "19.25px";
vector_ek61.src = "skins/vector_ek61.png";

eva_arrow_back_outline.appendChild(vector_ek61);

var rectangle_57 = document.createElement("div");
rectangle_57.id = "rectangle_57";
rectangle_57.style.left = "18px";
rectangle_57.style.opacity = "0.74000000953674";
rectangle_57.style.filter = "alpha(opacity='74.000000953674')";
rectangle_57.style.top = "101px";
rectangle_57.style.width = "106px";
rectangle_57.style.height = "39px";
rectangle_57.style.borderRadius = "10px";
rectangle_57.style.background = 'rgba(255,255,255,0.74)';

page_room_search_ek1.appendChild(rectangle_57);

var rectangle_58 = document.createElement("div");
rectangle_58.id = "rectangle_58";
rectangle_58.style.left = "161px";
rectangle_58.style.opacity = "0.74000000953674";
rectangle_58.style.filter = "alpha(opacity='74.000000953674')";
rectangle_58.style.top = "101px";
rectangle_58.style.width = "106px";
rectangle_58.style.height = "39px";
rectangle_58.style.borderRadius = "10px";
rectangle_58.style.background = 'rgba(255,255,255,0.74)';

page_room_search_ek1.appendChild(rectangle_58);

var rectangle_59 = document.createElement("div");
rectangle_59.id = "rectangle_59";
rectangle_59.style.left = "304px";
rectangle_59.style.opacity = "0.74000000953674";
rectangle_59.style.filter = "alpha(opacity='74.000000953674')";
rectangle_59.style.top = "101px";
rectangle_59.style.width = "106px";
rectangle_59.style.height = "39px";
rectangle_59.style.borderRadius = "10px";
rectangle_59.style.background = 'rgba(255,255,255,0.74)';

page_room_search_ek1.appendChild(rectangle_59);

var system_uicons_filtering = document.createElement("div");
system_uicons_filtering.id = "system_uicons_filtering";
system_uicons_filtering.style.width = "24px";
system_uicons_filtering.style.height = "24px";
system_uicons_filtering.style.left = "28px";
system_uicons_filtering.style.top = "108px";
system_uicons_filtering.style.position = "absolute";
page_room_search_ek1.appendChild(system_uicons_filtering);

var vector_ek62 = document.createElement("img");
vector_ek62.id = "vector_ek62";
vector_ek62.style.left = "2.86px";
vector_ek62.style.top = "4.57px";
vector_ek62.style.width = "18.29px";
vector_ek62.style.height = "16px";
vector_ek62.src = "skins/vector_ek62.png";

system_uicons_filtering.appendChild(vector_ek62);

var filters = document.createElement("div");
filters.innerHTML = "Filters";
filters.style.textAlign = "left";
filters.id = "filters";
filters.style.left = "57px";
filters.style.top = "108px";
filters.style.width = "69px";
filters.style.height = "36px";
filters.style.fontFamily = "Poppins";
filters.style.fontSize = "16px";
filters.style.lineHeight = "25px";
filters.style.overflow = "hidden";
filters.style.color = "#000000";

page_room_search_ek1.appendChild(filters);

var save = document.createElement("div");
save.innerHTML = "Save";
save.style.textAlign = "left";
save.id = "save";
save.style.left = "200px";
save.style.top = "108px";
save.style.width = "61px";
save.style.height = "36px";
save.style.fontFamily = "Poppins";
save.style.fontSize = "16px";
save.style.lineHeight = "25px";
save.style.overflow = "hidden";
save.style.color = "#000000";

page_room_search_ek1.appendChild(save);

var sort = document.createElement("div");
sort.innerHTML = "Sort";
sort.style.textAlign = "left";
sort.id = "sort";
sort.style.left = "343px";
sort.style.top = "108px";
sort.style.width = "53px";
sort.style.height = "36px";
sort.style.fontFamily = "Poppins";
sort.style.fontSize = "16px";
sort.style.lineHeight = "25px";
sort.style.overflow = "hidden";
sort.style.color = "#000000";

page_room_search_ek1.appendChild(sort);

var bi_save2 = document.createElement("div");
bi_save2.id = "bi_save2";
bi_save2.style.width = "24px";
bi_save2.style.height = "24px";
bi_save2.style.left = "170px";
bi_save2.style.top = "108px";
bi_save2.style.position = "absolute";
page_room_search_ek1.appendChild(bi_save2);

var vector_ek63 = document.createElement("img");
vector_ek63.id = "vector_ek63";
vector_ek63.style.left = "0px";
vector_ek63.style.top = "0px";
vector_ek63.style.width = "24px";
vector_ek63.style.height = "24px";
vector_ek63.src = "skins/vector_ek63.png";

bi_save2.appendChild(vector_ek63);

var ic_round_sort = document.createElement("div");
ic_round_sort.id = "ic_round_sort";
ic_round_sort.style.width = "24px";
ic_round_sort.style.height = "24px";
ic_round_sort.style.left = "313px";
ic_round_sort.style.top = "108px";
ic_round_sort.style.position = "absolute";
page_room_search_ek1.appendChild(ic_round_sort);

var vector_ek64 = document.createElement("img");
vector_ek64.id = "vector_ek64";
vector_ek64.style.left = "3px";
vector_ek64.style.top = "6px";
vector_ek64.style.width = "18px";
vector_ek64.style.height = "12px";
vector_ek64.src = "skins/vector_ek64.png";

ic_round_sort.appendChild(vector_ek64);

var cardss = document.createElement("div");
cardss.id = "cardss";
cardss.style.width = "382px";
cardss.style.height = "583px";
cardss.style.left = "23px";
cardss.style.top = "146px";
cardss.style.position = "absolute";
page_room_search_ek1.appendChild(cardss);

var card_1_ek2 = document.createElement("div");
card_1_ek2.id = "card_1_ek2";
card_1_ek2.style.width = "382px";
card_1_ek2.style.height = "449px";
card_1_ek2.style.left = "0px";
card_1_ek2.style.top = "0px";
card_1_ek2.style.position = "absolute";
cardss.appendChild(card_1_ek2);

var card_background_ek1 = document.createElement("div");
card_background_ek1.id = "card_background_ek1";
card_background_ek1.style.left = "0px";
card_background_ek1.style.top = "0px";
card_background_ek1.style.width = "382px";
card_background_ek1.style.height = "449px";
card_background_ek1.style.borderRadius = "16px";
card_background_ek1.style.background = 'rgba(255,255,255,1)';

card_1_ek2.appendChild(card_background_ek1);

var description_ek2 = document.createElement("div");
description_ek2.innerHTML = "Maitama, Abuja";
description_ek2.style.textAlign = "left";
description_ek2.id = "description_ek2";
description_ek2.style.left = "9px";
description_ek2.style.top = "291px";
description_ek2.style.width = "333px";
description_ek2.style.height = "36px";
description_ek2.style.fontFamily = "Poppins";
description_ek2.style.fontSize = "16px";
description_ek2.style.lineHeight = "25px";
description_ek2.style.overflow = "hidden";
description_ek2.style.color = "#6E798C";

card_1_ek2.appendChild(description_ek2);

var _2_bedroom_2_bath_beautiful_apartment = document.createElement("div");
_2_bedroom_2_bath_beautiful_apartment.innerHTML = "2 Bedroom 2 bath Beautiful Apartment ";
_2_bedroom_2_bath_beautiful_apartment.style.textAlign = "left";
_2_bedroom_2_bath_beautiful_apartment.id = "_2_bedroom_2_bath_beautiful_apartment";
_2_bedroom_2_bath_beautiful_apartment.style.left = "9px";
_2_bedroom_2_bath_beautiful_apartment.style.top = "236px";
_2_bedroom_2_bath_beautiful_apartment.style.width = "372px";
_2_bedroom_2_bath_beautiful_apartment.style.height = "64px";
_2_bedroom_2_bath_beautiful_apartment.style.fontFamily = "Poppins";
_2_bedroom_2_bath_beautiful_apartment.style.fontSize = "20px";
_2_bedroom_2_bath_beautiful_apartment.style.lineHeight = "25px";
_2_bedroom_2_bath_beautiful_apartment.style.overflow = "hidden";
_2_bedroom_2_bath_beautiful_apartment.style.color = "#081F32";

card_1_ek2.appendChild(_2_bedroom_2_bath_beautiful_apartment);

var pizza_photo_ek7 = document.createElement("div");
pizza_photo_ek7.id = "pizza_photo_ek7";
pizza_photo_ek7.style.left = "0px";
pizza_photo_ek7.style.top = "0px";
pizza_photo_ek7.style.width = "382px";
pizza_photo_ek7.style.height = "210px";
pizza_photo_ek7.style.borderRadius = "16px";
pizza_photo_ek7.style.background = 'rgba(196,196,196,1)';

card_1_ek2.appendChild(pizza_photo_ek7);

var rent_ek1 = document.createElement("div");
rent_ek1.innerHTML = "Rent";
rent_ek1.style.textAlign = "left";
rent_ek1.id = "rent_ek1";
rent_ek1.style.left = "10px";
rent_ek1.style.top = "342px";
rent_ek1.style.width = "56px";
rent_ek1.style.height = "36px";
rent_ek1.style.fontFamily = "Poppins";
rent_ek1.style.fontSize = "16px";
rent_ek1.style.lineHeight = "25px";
rent_ek1.style.overflow = "hidden";
rent_ek1.style.color = "#000000";

card_1_ek2.appendChild(rent_ek1);

var price_ek3 = document.createElement("div");
price_ek3.id = "price_ek3";
price_ek3.style.width = "140px";
price_ek3.style.height = "21px";
price_ek3.style.left = "10px";
price_ek3.style.top = "368px";
price_ek3.style.position = "absolute";
card_1_ek2.appendChild(price_ek3);

var price_ek4 = document.createElement("div");
price_ek4.innerHTML = "2,500,000/Year";
price_ek4.style.textAlign = "left";
price_ek4.id = "price_ek4";
price_ek4.style.left = "16px";
price_ek4.style.top = "0px";
price_ek4.style.width = "145px";
price_ek4.style.height = "32px";
price_ek4.style.fontFamily = "Poppins";
price_ek4.style.fontSize = "16px";
price_ek4.style.lineHeight = "25px";
price_ek4.style.overflow = "hidden";
price_ek4.style.color = "#081F32";

price_ek3.appendChild(price_ek4);

var fa6_solid_naira_sign_ek1 = document.createElement("div");
fa6_solid_naira_sign_ek1.id = "fa6_solid_naira_sign_ek1";
fa6_solid_naira_sign_ek1.style.width = "13px";
fa6_solid_naira_sign_ek1.style.height = "15px";
fa6_solid_naira_sign_ek1.style.left = "0px";
fa6_solid_naira_sign_ek1.style.top = "4px";
fa6_solid_naira_sign_ek1.style.position = "absolute";
price_ek3.appendChild(fa6_solid_naira_sign_ek1);

var vector_ek65 = document.createElement("img");
vector_ek65.id = "vector_ek65";
vector_ek65.style.left = "0px";
vector_ek65.style.top = "0.94px";
vector_ek65.style.width = "13px";
vector_ek65.style.height = "13.13px";
vector_ek65.src = "skins/vector_ek65.png";

fa6_solid_naira_sign_ek1.appendChild(vector_ek65);

var available_ek1 = document.createElement("div");
available_ek1.innerHTML = "Available";
available_ek1.style.textAlign = "left";
available_ek1.id = "available_ek1";
available_ek1.style.left = "296px";
available_ek1.style.top = "342px";
available_ek1.style.width = "92px";
available_ek1.style.height = "36px";
available_ek1.style.fontFamily = "Poppins";
available_ek1.style.fontSize = "16px";
available_ek1.style.lineHeight = "25px";
available_ek1.style.overflow = "hidden";
available_ek1.style.color = "#000000";

card_1_ek2.appendChild(available_ek1);

var january_17th_ek1 = document.createElement("div");
january_17th_ek1.innerHTML = "January 17th";
january_17th_ek1.style.textAlign = "left";
january_17th_ek1.id = "january_17th_ek1";
january_17th_ek1.style.left = "271px";
january_17th_ek1.style.top = "364px";
january_17th_ek1.style.width = "121px";
january_17th_ek1.style.height = "36px";
january_17th_ek1.style.fontFamily = "Poppins";
january_17th_ek1.style.fontSize = "16px";
january_17th_ek1.style.lineHeight = "25px";
january_17th_ek1.style.overflow = "hidden";
january_17th_ek1.style.color = "#000000";

card_1_ek2.appendChild(january_17th_ek1);

var save_ek1 = document.createElement("div");
save_ek1.id = "save_ek1";
save_ek1.style.width = "35px";
save_ek1.style.height = "35px";
save_ek1.style.left = "341px";
save_ek1.style.top = "13px";
save_ek1.style.position = "absolute";
card_1_ek2.appendChild(save_ek1);

var ellipse_14 = document.createElement("div");
ellipse_14.id = "ellipse_14";
ellipse_14.style.left = "0px";
ellipse_14.style.top = "0px";
ellipse_14.style.width = "35px";
ellipse_14.style.height = "35px";
ellipse_14.style.borderRadius = "17.5px / 17.5px";
ellipse_14.style.background = 'rgba(249,253,255,1)';

save_ek1.appendChild(ellipse_14);

var vector_ek66 = document.createElement("img");
vector_ek66.id = "vector_ek66";
vector_ek66.style.left = "7px";
vector_ek66.style.top = "7px";
vector_ek66.style.width = "20px";
vector_ek66.style.height = "20px";
vector_ek66.src = "skins/vector_ek66.png";

save_ek1.appendChild(vector_ek66);

var card_2_ek2 = document.createElement("div");
card_2_ek2.id = "card_2_ek2";
card_2_ek2.style.width = "382px";
card_2_ek2.style.height = "449px";
card_2_ek2.style.left = "0px";
card_2_ek2.style.top = "468px";
card_2_ek2.style.position = "absolute";
cardss.appendChild(card_2_ek2);

var card_background_ek2 = document.createElement("div");
card_background_ek2.id = "card_background_ek2";
card_background_ek2.style.left = "0px";
card_background_ek2.style.top = "0px";
card_background_ek2.style.width = "382px";
card_background_ek2.style.height = "449px";
card_background_ek2.style.borderRadius = "16px";
card_background_ek2.style.background = 'rgba(255,255,255,1)';

card_2_ek2.appendChild(card_background_ek2);

var description_ek3 = document.createElement("div");
description_ek3.innerHTML = "Lekki Phase 2, Lagos";
description_ek3.style.textAlign = "left";
description_ek3.id = "description_ek3";
description_ek3.style.left = "11px";
description_ek3.style.top = "263px";
description_ek3.style.width = "333px";
description_ek3.style.height = "36px";
description_ek3.style.fontFamily = "Poppins";
description_ek3.style.fontSize = "16px";
description_ek3.style.lineHeight = "25px";
description_ek3.style.overflow = "hidden";
description_ek3.style.color = "#6E798C";

card_2_ek2.appendChild(description_ek3);

var king_s_palace_apartment = document.createElement("div");
king_s_palace_apartment.innerHTML = "King\'s Palace Apartment";
king_s_palace_apartment.style.textAlign = "left";
king_s_palace_apartment.id = "king_s_palace_apartment";
king_s_palace_apartment.style.left = "9px";
king_s_palace_apartment.style.top = "236px";
king_s_palace_apartment.style.width = "376px";
king_s_palace_apartment.style.height = "42px";
king_s_palace_apartment.style.fontFamily = "Poppins";
king_s_palace_apartment.style.fontSize = "24px";
king_s_palace_apartment.style.lineHeight = "25px";
king_s_palace_apartment.style.overflow = "hidden";
king_s_palace_apartment.style.color = "#081F32";

card_2_ek2.appendChild(king_s_palace_apartment);

var pizza_photo_ek8 = document.createElement("div");
pizza_photo_ek8.id = "pizza_photo_ek8";
pizza_photo_ek8.style.left = "0px";
pizza_photo_ek8.style.top = "0px";
pizza_photo_ek8.style.width = "382px";
pizza_photo_ek8.style.height = "210px";
pizza_photo_ek8.style.borderRadius = "16px";
pizza_photo_ek8.style.background = 'rgba(196,196,196,1)';

card_2_ek2.appendChild(pizza_photo_ek8);

var rent_ek2 = document.createElement("div");
rent_ek2.innerHTML = "Rent";
rent_ek2.style.textAlign = "left";
rent_ek2.id = "rent_ek2";
rent_ek2.style.left = "18px";
rent_ek2.style.top = "308px";
rent_ek2.style.width = "56px";
rent_ek2.style.height = "36px";
rent_ek2.style.fontFamily = "Poppins";
rent_ek2.style.fontSize = "16px";
rent_ek2.style.lineHeight = "25px";
rent_ek2.style.overflow = "hidden";
rent_ek2.style.color = "#000000";

card_2_ek2.appendChild(rent_ek2);

var price_ek5 = document.createElement("div");
price_ek5.id = "price_ek5";
price_ek5.style.width = "132px";
price_ek5.style.height = "21px";
price_ek5.style.left = "18px";
price_ek5.style.top = "334px";
price_ek5.style.position = "absolute";
card_2_ek2.appendChild(price_ek5);

var price_ek6 = document.createElement("div");
price_ek6.innerHTML = "1,500,000/Year";
price_ek6.style.textAlign = "left";
price_ek6.id = "price_ek6";
price_ek6.style.left = "16px";
price_ek6.style.top = "0px";
price_ek6.style.width = "137px";
price_ek6.style.height = "32px";
price_ek6.style.fontFamily = "Poppins";
price_ek6.style.fontSize = "16px";
price_ek6.style.lineHeight = "25px";
price_ek6.style.overflow = "hidden";
price_ek6.style.color = "#081F32";

price_ek5.appendChild(price_ek6);

var fa6_solid_naira_sign_ek2 = document.createElement("div");
fa6_solid_naira_sign_ek2.id = "fa6_solid_naira_sign_ek2";
fa6_solid_naira_sign_ek2.style.width = "13px";
fa6_solid_naira_sign_ek2.style.height = "15px";
fa6_solid_naira_sign_ek2.style.left = "0px";
fa6_solid_naira_sign_ek2.style.top = "4px";
fa6_solid_naira_sign_ek2.style.position = "absolute";
price_ek5.appendChild(fa6_solid_naira_sign_ek2);

var vector_ek67 = document.createElement("img");
vector_ek67.id = "vector_ek67";
vector_ek67.style.left = "0px";
vector_ek67.style.top = "0.94px";
vector_ek67.style.width = "13px";
vector_ek67.style.height = "13.13px";
vector_ek67.src = "skins/vector_ek67.png";

fa6_solid_naira_sign_ek2.appendChild(vector_ek67);

var available_ek2 = document.createElement("div");
available_ek2.innerHTML = "Available";
available_ek2.style.textAlign = "left";
available_ek2.id = "available_ek2";
available_ek2.style.left = "300px";
available_ek2.style.top = "308px";
available_ek2.style.width = "92px";
available_ek2.style.height = "36px";
available_ek2.style.fontFamily = "Poppins";
available_ek2.style.fontSize = "16px";
available_ek2.style.lineHeight = "25px";
available_ek2.style.overflow = "hidden";
available_ek2.style.color = "#000000";

card_2_ek2.appendChild(available_ek2);

var september_5th = document.createElement("div");
september_5th.innerHTML = "September 5th";
september_5th.style.textAlign = "left";
september_5th.id = "september_5th";
september_5th.style.left = "253px";
september_5th.style.top = "334px";
september_5th.style.width = "141px";
september_5th.style.height = "36px";
september_5th.style.fontFamily = "Poppins";
september_5th.style.fontSize = "16px";
september_5th.style.lineHeight = "25px";
september_5th.style.overflow = "hidden";
september_5th.style.color = "#000000";

card_2_ek2.appendChild(september_5th);

var save_ek2 = document.createElement("div");
save_ek2.id = "save_ek2";
save_ek2.style.width = "35px";
save_ek2.style.height = "35px";
save_ek2.style.left = "341px";
save_ek2.style.top = "13px";
save_ek2.style.position = "absolute";
card_2_ek2.appendChild(save_ek2);

var ellipse_14_ek1 = document.createElement("div");
ellipse_14_ek1.id = "ellipse_14_ek1";
ellipse_14_ek1.style.left = "0px";
ellipse_14_ek1.style.top = "0px";
ellipse_14_ek1.style.width = "35px";
ellipse_14_ek1.style.height = "35px";
ellipse_14_ek1.style.borderRadius = "17.5px / 17.5px";
ellipse_14_ek1.style.background = 'rgba(249,253,255,1)';

save_ek2.appendChild(ellipse_14_ek1);

var vector_ek68 = document.createElement("img");
vector_ek68.id = "vector_ek68";
vector_ek68.style.left = "7px";
vector_ek68.style.top = "7px";
vector_ek68.style.width = "20px";
vector_ek68.style.height = "20px";
vector_ek68.src = "skins/vector_ek68.png";

save_ek2.appendChild(vector_ek68);

var card_3_ek2 = document.createElement("div");
card_3_ek2.id = "card_3_ek2";
card_3_ek2.style.width = "382px";
card_3_ek2.style.height = "449px";
card_3_ek2.style.left = "0px";
card_3_ek2.style.top = "936px";
card_3_ek2.style.position = "absolute";
cardss.appendChild(card_3_ek2);

var card_background_ek3 = document.createElement("div");
card_background_ek3.id = "card_background_ek3";
card_background_ek3.style.left = "0px";
card_background_ek3.style.top = "0px";
card_background_ek3.style.width = "382px";
card_background_ek3.style.height = "449px";
card_background_ek3.style.borderRadius = "16px";
card_background_ek3.style.background = 'rgba(255,255,255,1)';

card_3_ek2.appendChild(card_background_ek3);

var description_ek4 = document.createElement("div");
description_ek4.innerHTML = "Gwarimpa, Abuja";
description_ek4.style.textAlign = "left";
description_ek4.id = "description_ek4";
description_ek4.style.left = "9px";
description_ek4.style.top = "263px";
description_ek4.style.width = "333px";
description_ek4.style.height = "36px";
description_ek4.style.fontFamily = "Poppins";
description_ek4.style.fontSize = "16px";
description_ek4.style.lineHeight = "25px";
description_ek4.style.overflow = "hidden";
description_ek4.style.color = "#6E798C";

card_3_ek2.appendChild(description_ek4);

var private_room = document.createElement("div");
private_room.innerHTML = "Private Room";
private_room.style.textAlign = "left";
private_room.id = "private_room";
private_room.style.left = "9px";
private_room.style.top = "236px";
private_room.style.width = "376px";
private_room.style.height = "42px";
private_room.style.fontFamily = "Poppins";
private_room.style.fontSize = "24px";
private_room.style.lineHeight = "25px";
private_room.style.overflow = "hidden";
private_room.style.color = "#081F32";

card_3_ek2.appendChild(private_room);

var pizza_photo_ek9 = document.createElement("div");
pizza_photo_ek9.id = "pizza_photo_ek9";
pizza_photo_ek9.style.left = "0px";
pizza_photo_ek9.style.top = "0px";
pizza_photo_ek9.style.width = "382px";
pizza_photo_ek9.style.height = "210px";
pizza_photo_ek9.style.borderRadius = "16px";
pizza_photo_ek9.style.background = 'rgba(196,196,196,1)';

card_3_ek2.appendChild(pizza_photo_ek9);

var rent_ek3 = document.createElement("div");
rent_ek3.innerHTML = "Rent";
rent_ek3.style.textAlign = "left";
rent_ek3.id = "rent_ek3";
rent_ek3.style.left = "14px";
rent_ek3.style.top = "302px";
rent_ek3.style.width = "56px";
rent_ek3.style.height = "36px";
rent_ek3.style.fontFamily = "Poppins";
rent_ek3.style.fontSize = "16px";
rent_ek3.style.lineHeight = "25px";
rent_ek3.style.overflow = "hidden";
rent_ek3.style.color = "#000000";

card_3_ek2.appendChild(rent_ek3);

var price_ek7 = document.createElement("div");
price_ek7.id = "price_ek7";
price_ek7.style.width = "132px";
price_ek7.style.height = "21px";
price_ek7.style.left = "14px";
price_ek7.style.top = "331px";
price_ek7.style.position = "absolute";
card_3_ek2.appendChild(price_ek7);

var price_ek8 = document.createElement("div");
price_ek8.innerHTML = "1,500,000/Year";
price_ek8.style.textAlign = "left";
price_ek8.id = "price_ek8";
price_ek8.style.left = "16px";
price_ek8.style.top = "0px";
price_ek8.style.width = "137px";
price_ek8.style.height = "32px";
price_ek8.style.fontFamily = "Poppins";
price_ek8.style.fontSize = "16px";
price_ek8.style.lineHeight = "25px";
price_ek8.style.overflow = "hidden";
price_ek8.style.color = "#081F32";

price_ek7.appendChild(price_ek8);

var fa6_solid_naira_sign_ek3 = document.createElement("div");
fa6_solid_naira_sign_ek3.id = "fa6_solid_naira_sign_ek3";
fa6_solid_naira_sign_ek3.style.width = "13px";
fa6_solid_naira_sign_ek3.style.height = "15px";
fa6_solid_naira_sign_ek3.style.left = "0px";
fa6_solid_naira_sign_ek3.style.top = "4px";
fa6_solid_naira_sign_ek3.style.position = "absolute";
price_ek7.appendChild(fa6_solid_naira_sign_ek3);

var vector_ek69 = document.createElement("img");
vector_ek69.id = "vector_ek69";
vector_ek69.style.left = "0px";
vector_ek69.style.top = "0.94px";
vector_ek69.style.width = "13px";
vector_ek69.style.height = "13.13px";
vector_ek69.src = "skins/vector_ek69.png";

fa6_solid_naira_sign_ek3.appendChild(vector_ek69);

var available_ek3 = document.createElement("div");
available_ek3.innerHTML = "Available";
available_ek3.style.textAlign = "left";
available_ek3.id = "available_ek3";
available_ek3.style.left = "297px";
available_ek3.style.top = "307px";
available_ek3.style.width = "92px";
available_ek3.style.height = "36px";
available_ek3.style.fontFamily = "Poppins";
available_ek3.style.fontSize = "16px";
available_ek3.style.lineHeight = "25px";
available_ek3.style.overflow = "hidden";
available_ek3.style.color = "#000000";

card_3_ek2.appendChild(available_ek3);

var december_20th = document.createElement("div");
december_20th.innerHTML = "December 20th";
december_20th.style.textAlign = "left";
december_20th.id = "december_20th";
december_20th.style.left = "254px";
december_20th.style.top = "331px";
december_20th.style.width = "145px";
december_20th.style.height = "36px";
december_20th.style.fontFamily = "Poppins";
december_20th.style.fontSize = "16px";
december_20th.style.lineHeight = "25px";
december_20th.style.overflow = "hidden";
december_20th.style.color = "#000000";

card_3_ek2.appendChild(december_20th);

var save_ek3 = document.createElement("div");
save_ek3.id = "save_ek3";
save_ek3.style.width = "35px";
save_ek3.style.height = "35px";
save_ek3.style.left = "341px";
save_ek3.style.top = "13px";
save_ek3.style.position = "absolute";
card_3_ek2.appendChild(save_ek3);

var ellipse_14_ek2 = document.createElement("div");
ellipse_14_ek2.id = "ellipse_14_ek2";
ellipse_14_ek2.style.left = "0px";
ellipse_14_ek2.style.top = "0px";
ellipse_14_ek2.style.width = "35px";
ellipse_14_ek2.style.height = "35px";
ellipse_14_ek2.style.borderRadius = "17.5px / 17.5px";
ellipse_14_ek2.style.background = 'rgba(249,253,255,1)';

save_ek3.appendChild(ellipse_14_ek2);

var vector_ek70 = document.createElement("img");
vector_ek70.id = "vector_ek70";
vector_ek70.style.left = "7px";
vector_ek70.style.top = "7px";
vector_ek70.style.width = "20px";
vector_ek70.style.height = "20px";
vector_ek70.src = "skins/vector_ek70.png";

save_ek3.appendChild(vector_ek70);

var down_ek2 = document.createElement("div");
down_ek2.id = "down_ek2";
down_ek2.style.width = "428px";
down_ek2.style.height = "105px";
down_ek2.style.left = "-9px";
down_ek2.style.top = "729px";
down_ek2.style.position = "absolute";
page_room_search_ek1.appendChild(down_ek2);

var rectangle_3_ek4 = document.createElement("div");
rectangle_3_ek4.id = "rectangle_3_ek4";
rectangle_3_ek4.style.left = "0px";
rectangle_3_ek4.style.opacity = "0.75999999046326";
rectangle_3_ek4.style.filter = "alpha(opacity='75.999999046326')";
rectangle_3_ek4.style.top = "0px";
rectangle_3_ek4.style.width = "428px";
rectangle_3_ek4.style.height = "105px";
rectangle_3_ek4.style.borderRadius = "10px";
rectangle_3_ek4.style.background = 'rgba(253.94,253.94,253.94,0.76)';

down_ek2.appendChild(rectangle_3_ek4);

var vector_ek71 = document.createElement("img");
vector_ek71.id = "vector_ek71";
vector_ek71.style.left = "30.64px";
vector_ek71.style.top = "38px";
vector_ek71.style.width = "29.62px";
vector_ek71.style.height = "29px";
vector_ek71.src = "skins/vector_ek71.png";

down_ek2.appendChild(vector_ek71);

var vector_ek72 = document.createElement("img");
vector_ek72.id = "vector_ek72";
vector_ek72.style.left = "147.09px";
vector_ek72.style.top = "38px";
vector_ek72.style.width = "29.62px";
vector_ek72.style.height = "29px";
vector_ek72.src = "skins/vector_ek72.png";

down_ek2.appendChild(vector_ek72);

var vector_ek73 = document.createElement("img");
vector_ek73.id = "vector_ek73";
vector_ek73.style.left = "260.48px";
vector_ek73.style.top = "43px";
vector_ek73.style.width = "29.62px";
vector_ek73.style.height = "29px";
vector_ek73.src = "skins/vector_ek73.png";

down_ek2.appendChild(vector_ek73);

var group_ek9 = document.createElement("div");
group_ek9.id = "group_ek9";
group_ek9.style.width = "29.62px";
group_ek9.style.height = "29px";
group_ek9.style.left = "375px";
group_ek9.style.top = "9px";
group_ek9.style.position = "absolute";
down_ek2.appendChild(group_ek9);

var vector_ek74 = document.createElement("img");
vector_ek74.id = "vector_ek74";
vector_ek74.style.left = "0px";
vector_ek74.style.top = "0px";
vector_ek74.style.width = "29.62px";
vector_ek74.style.height = "29px";
vector_ek74.src = "skins/vector_ek74.png";

group_ek9.appendChild(vector_ek74);

var home_ek5 = document.createElement("div");
home_ek5.innerHTML = "Home";
home_ek5.style.textAlign = "left";
home_ek5.id = "home_ek5";
home_ek5.style.left = "26.56px";
home_ek5.style.top = "72px";
home_ek5.style.width = "61.9px";
home_ek5.style.height = "31px";
home_ek5.style.fontFamily = "Poppins";
home_ek5.style.fontSize = "14px";
home_ek5.style.overflow = "hidden";
home_ek5.style.color = "#000000";

down_ek2.appendChild(home_ek5);

var search_ek9 = document.createElement("div");
search_ek9.innerHTML = "Search";
search_ek9.style.textAlign = "left";
search_ek9.id = "search_ek9";
search_ek9.style.left = "138.92px";
search_ek9.style.top = "72px";
search_ek9.style.width = "70.07px";
search_ek9.style.height = "31px";
search_ek9.style.fontFamily = "Poppins";
search_ek9.style.fontSize = "14px";
search_ek9.style.overflow = "hidden";
search_ek9.style.color = "#CB5A7A";

down_ek2.appendChild(search_ek9);

var saved_ek2 = document.createElement("div");
saved_ek2.innerHTML = "Saved";
saved_ek2.style.textAlign = "left";
saved_ek2.id = "saved_ek2";
saved_ek2.style.left = "253.33px";
saved_ek2.style.top = "72px";
saved_ek2.style.width = "63.95px";
saved_ek2.style.height = "31px";
saved_ek2.style.fontFamily = "Poppins";
saved_ek2.style.fontSize = "14px";
saved_ek2.style.overflow = "hidden";
saved_ek2.style.color = "#000000";

down_ek2.appendChild(saved_ek2);

var account_ek2 = document.createElement("div");
account_ek2.innerHTML = "Account";
account_ek2.style.textAlign = "left";
account_ek2.id = "account_ek2";
account_ek2.style.left = "359.56px";
account_ek2.style.top = "72px";
account_ek2.style.width = "79.27px";
account_ek2.style.height = "31px";
account_ek2.style.fontFamily = "Poppins";
account_ek2.style.fontSize = "14px";
account_ek2.style.overflow = "hidden";
account_ek2.style.color = "#07132A";

down_ek2.appendChild(account_ek2);




