/*
 *	This content is generated from the PSD File Info.
 *	(Alt+Shift+Ctrl+I).
 *
 *	@desc 		
 *	@file 		personality_1
 *	@date 		Tuesday 30th of August 2022 10:57:13 PM
 *	@title 		DESIGN
 *	@author 	
 *	@keywords 	
 *	@generator 	Export Kit v1.3.figma
 *
*/

var content_container = document.createElement("div");
content_container.style.width = "428px";
content_container.id = "content_container";
content_container.style.position = "relative";
content_container.style.display = "block";
content_container.style.margin = "0 auto";
document.body.appendChild(content_container);




var page_messages_ek1 = document.createElement("div");
page_messages_ek1.id = "page_messages_ek1";
page_messages_ek1.style.width = "428px";
page_messages_ek1.style.height = "826px";
page_messages_ek1.style.left = "0px";
page_messages_ek1.style.top = "0px";
page_messages_ek1.style.position = "absolute";
content_container.appendChild(page_messages_ek1);

var _bg__messages_ek2 = document.createElement("div");
_bg__messages_ek2.id = "_bg__messages_ek2";
_bg__messages_ek2.style.left = "0px";
_bg__messages_ek2.style.top = "0px";
_bg__messages_ek2.style.width = "428px";
_bg__messages_ek2.style.height = "826px";
_bg__messages_ek2.style.background = 'rgba(234.81,234.81,234.81,1)';

page_messages_ek1.appendChild(_bg__messages_ek2);

var rectangle_53_ek2 = document.createElement("div");
rectangle_53_ek2.id = "rectangle_53_ek2";
rectangle_53_ek2.style.left = "0px";
rectangle_53_ek2.style.top = "0px";
rectangle_53_ek2.style.width = "428px";
rectangle_53_ek2.style.height = "89px";
rectangle_53_ek2.style.background = 'rgba(203,90,122,1)';

page_messages_ek1.appendChild(rectangle_53_ek2);

var rectangle_69 = document.createElement("img");
rectangle_69.id = "rectangle_69";
rectangle_69.style.left = "0px";
rectangle_69.style.top = "593px";
rectangle_69.style.width = "428px";
rectangle_69.style.height = "75px";
rectangle_69.src = "skins/rectangle_69.png";

page_messages_ek1.appendChild(rectangle_69);

var vector_ek13 = document.createElement("img");
vector_ek13.id = "vector_ek13";
vector_ek13.style.left = "16px";
vector_ek13.style.top = "37px";
vector_ek13.style.width = "18.41px";
vector_ek13.style.height = "15.41px";
vector_ek13.src = "skins/vector_ek13.png";

page_messages_ek1.appendChild(vector_ek13);

var ellipse_23 = document.createElement("img");
ellipse_23.id = "ellipse_23";
ellipse_23.style.left = "53px";
ellipse_23.style.top = "28px";
ellipse_23.style.width = "40px";
ellipse_23.style.height = "40px";
ellipse_23.src = "skins/ellipse_23.png";

page_messages_ek1.appendChild(ellipse_23);

var chris_walker = document.createElement("div");
chris_walker.innerHTML = "Chris Walker";
chris_walker.style.fontWeight = "bold";
chris_walker.style.textAlign = "left";
chris_walker.id = "chris_walker";
chris_walker.style.left = "99px";
chris_walker.style.top = "33px";
chris_walker.style.width = "125px";
chris_walker.style.height = "35px";
chris_walker.style.fontFamily = "Poppins";
chris_walker.style.fontSize = "16px";
chris_walker.style.overflow = "hidden";
chris_walker.style.color = "#FFFFFF";

page_messages_ek1.appendChild(chris_walker);

var online = document.createElement("div");
online.innerHTML = "Online";
online.style.textAlign = "left";
online.id = "online";
online.style.left = "99px";
online.style.top = "56px";
online.style.width = "51.5px";
online.style.height = "24.5px";
online.style.fontFamily = "Poppins";
online.style.fontSize = "11px";
online.style.overflow = "hidden";
online.style.color = "#FFFFFF";

page_messages_ek1.appendChild(online);

var rectangle_70 = document.createElement("div");
rectangle_70.id = "rectangle_70";
rectangle_70.style.left = "178px";
rectangle_70.style.top = "115px";
rectangle_70.style.width = "222px";
rectangle_70.style.height = "51px";
rectangle_70.style.borderRadius = "10px";
rectangle_70.style.background = 'rgba(203,90,122,1)';

page_messages_ek1.appendChild(rectangle_70);

var rectangle_73 = document.createElement("div");
rectangle_73.id = "rectangle_73";
rectangle_73.style.left = "272px";
rectangle_73.style.top = "326px";
rectangle_73.style.width = "131px";
rectangle_73.style.height = "33px";
rectangle_73.style.borderRadius = "10px";
rectangle_73.style.background = 'rgba(203,90,122,1)';

page_messages_ek1.appendChild(rectangle_73);

var hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile = document.createElement("div");
hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile.innerHTML = "Hi Chris, i would like to be your roomate. <br/>you can check my Profile";
hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile.style.textAlign = "left";
hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile.id = "hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile";
hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile.style.left = "182px";
hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile.style.top = "125px";
hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile.style.width = "237.5px";
hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile.style.height = "41.5px";
hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile.style.fontFamily = "Poppins";
hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile.style.fontSize = "11px";
hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile.style.overflow = "hidden";
hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile.style.color = "#FFFFFF";

page_messages_ek1.appendChild(hi_chris__i_would_like_to_be_your_roomate__you_can_check_my_profile);

var _750k_is_that_okay_ = document.createElement("div");
_750k_is_that_okay_.innerHTML = "750k is that okay?";
_750k_is_that_okay_.style.textAlign = "left";
_750k_is_that_okay_.id = "_750k_is_that_okay_";
_750k_is_that_okay_.style.left = "279px";
_750k_is_that_okay_.style.top = "334px";
_750k_is_that_okay_.style.width = "114.5px";
_750k_is_that_okay_.style.height = "24.5px";
_750k_is_that_okay_.style.fontFamily = "Poppins";
_750k_is_that_okay_.style.fontSize = "11px";
_750k_is_that_okay_.style.overflow = "hidden";
_750k_is_that_okay_.style.color = "#FFFFFF";

page_messages_ek1.appendChild(_750k_is_that_okay_);

var _9_27am = document.createElement("div");
_9_27am.innerHTML = "9:27AM";
_9_27am.style.textAlign = "left";
_9_27am.id = "_9_27am";
_9_27am.style.left = "363px";
_9_27am.style.top = "173px";
_9_27am.style.width = "41px";
_9_27am.style.height = "18px";
_9_27am.style.fontFamily = "Poppins";
_9_27am.style.fontSize = "8px";
_9_27am.style.overflow = "hidden";
_9_27am.style.color = "#000000";

page_messages_ek1.appendChild(_9_27am);

var _10_27am = document.createElement("div");
_10_27am.innerHTML = "10:27AM";
_10_27am.style.textAlign = "left";
_10_27am.id = "_10_27am";
_10_27am.style.left = "13px";
_10_27am.style.top = "297px";
_10_27am.style.width = "44px";
_10_27am.style.height = "18px";
_10_27am.style.fontFamily = "Poppins";
_10_27am.style.fontSize = "8px";
_10_27am.style.overflow = "hidden";
_10_27am.style.color = "#000000";

page_messages_ek1.appendChild(_10_27am);

var _11_27am = document.createElement("div");
_11_27am.innerHTML = "11:27AM";
_11_27am.style.textAlign = "left";
_11_27am.id = "_11_27am";
_11_27am.style.left = "356px";
_11_27am.style.top = "369px";
_11_27am.style.width = "42px";
_11_27am.style.height = "18px";
_11_27am.style.fontFamily = "Poppins";
_11_27am.style.fontSize = "8px";
_11_27am.style.overflow = "hidden";
_11_27am.style.color = "#000000";

page_messages_ek1.appendChild(_11_27am);

var _11_27am_ek1 = document.createElement("div");
_11_27am_ek1.innerHTML = "11:27AM";
_11_27am_ek1.style.textAlign = "left";
_11_27am_ek1.id = "_11_27am_ek1";
_11_27am_ek1.style.left = "17px";
_11_27am_ek1.style.top = "461px";
_11_27am_ek1.style.width = "42px";
_11_27am_ek1.style.height = "18px";
_11_27am_ek1.style.fontFamily = "Poppins";
_11_27am_ek1.style.fontSize = "8px";
_11_27am_ek1.style.overflow = "hidden";
_11_27am_ek1.style.color = "#000000";

page_messages_ek1.appendChild(_11_27am_ek1);

var teenyicons_tick_circle_solid = document.createElement("div");
teenyicons_tick_circle_solid.id = "teenyicons_tick_circle_solid";
teenyicons_tick_circle_solid.style.width = "7px";
teenyicons_tick_circle_solid.style.height = "7px";
teenyicons_tick_circle_solid.style.left = "47px";
teenyicons_tick_circle_solid.style.top = "299px";
teenyicons_tick_circle_solid.style.position = "absolute";
page_messages_ek1.appendChild(teenyicons_tick_circle_solid);

var vector_ek14 = document.createElement("img");
vector_ek14.id = "vector_ek14";
vector_ek14.style.left = "px";
vector_ek14.style.top = "px";
vector_ek14.style.width = "7px";
vector_ek14.style.height = "7px";
vector_ek14.src = "skins/vector_ek14.png";

teenyicons_tick_circle_solid.appendChild(vector_ek14);

var teenyicons_tick_circle_solid_ek1 = document.createElement("div");
teenyicons_tick_circle_solid_ek1.id = "teenyicons_tick_circle_solid_ek1";
teenyicons_tick_circle_solid_ek1.style.width = "7px";
teenyicons_tick_circle_solid_ek1.style.height = "7px";
teenyicons_tick_circle_solid_ek1.style.left = "390px";
teenyicons_tick_circle_solid_ek1.style.top = "371px";
teenyicons_tick_circle_solid_ek1.style.position = "absolute";
page_messages_ek1.appendChild(teenyicons_tick_circle_solid_ek1);

var vector_ek15 = document.createElement("img");
vector_ek15.id = "vector_ek15";
vector_ek15.style.left = "px";
vector_ek15.style.top = "px";
vector_ek15.style.width = "7px";
vector_ek15.style.height = "7px";
vector_ek15.src = "skins/vector_ek15.png";

teenyicons_tick_circle_solid_ek1.appendChild(vector_ek15);

var teenyicons_tick_circle_solid_ek2 = document.createElement("div");
teenyicons_tick_circle_solid_ek2.id = "teenyicons_tick_circle_solid_ek2";
teenyicons_tick_circle_solid_ek2.style.width = "7px";
teenyicons_tick_circle_solid_ek2.style.height = "7px";
teenyicons_tick_circle_solid_ek2.style.left = "51px";
teenyicons_tick_circle_solid_ek2.style.top = "463px";
teenyicons_tick_circle_solid_ek2.style.position = "absolute";
page_messages_ek1.appendChild(teenyicons_tick_circle_solid_ek2);

var vector_ek16 = document.createElement("img");
vector_ek16.id = "vector_ek16";
vector_ek16.style.left = "px";
vector_ek16.style.top = "px";
vector_ek16.style.width = "7px";
vector_ek16.style.height = "7px";
vector_ek16.src = "skins/vector_ek16.png";

teenyicons_tick_circle_solid_ek2.appendChild(vector_ek16);

var teenyicons_tick_circle_solid_ek3 = document.createElement("div");
teenyicons_tick_circle_solid_ek3.id = "teenyicons_tick_circle_solid_ek3";
teenyicons_tick_circle_solid_ek3.style.width = "7px";
teenyicons_tick_circle_solid_ek3.style.height = "7px";
teenyicons_tick_circle_solid_ek3.style.left = "393px";
teenyicons_tick_circle_solid_ek3.style.top = "176px";
teenyicons_tick_circle_solid_ek3.style.position = "absolute";
page_messages_ek1.appendChild(teenyicons_tick_circle_solid_ek3);

var vector_ek17 = document.createElement("img");
vector_ek17.id = "vector_ek17";
vector_ek17.style.left = "px";
vector_ek17.style.top = "px";
vector_ek17.style.width = "7px";
vector_ek17.style.height = "7px";
vector_ek17.src = "skins/vector_ek17.png";

teenyicons_tick_circle_solid_ek3.appendChild(vector_ek17);

var rectangle_71 = document.createElement("div");
rectangle_71.id = "rectangle_71";
rectangle_71.style.left = "13px";
rectangle_71.style.top = "216px";
rectangle_71.style.width = "241px";
rectangle_71.style.height = "33px";
rectangle_71.style.borderRadius = "10px";
rectangle_71.style.background = 'rgba(188,209,255,1)';

page_messages_ek1.appendChild(rectangle_71);

var rectangle_72 = document.createElement("div");
rectangle_72.id = "rectangle_72";
rectangle_72.style.left = "13px";
rectangle_72.style.top = "260px";
rectangle_72.style.width = "150px";
rectangle_72.style.height = "33px";
rectangle_72.style.borderRadius = "10px";
rectangle_72.style.background = 'rgba(188,209,255,1)';

page_messages_ek1.appendChild(rectangle_72);

var rectangle_74 = document.createElement("div");
rectangle_74.id = "rectangle_74";
rectangle_74.style.left = "13px";
rectangle_74.style.top = "260px";
rectangle_74.style.width = "150px";
rectangle_74.style.height = "33px";
rectangle_74.style.borderRadius = "10px";
rectangle_74.style.background = 'rgba(188,209,255,1)';

page_messages_ek1.appendChild(rectangle_74);

var rectangle_75 = document.createElement("div");
rectangle_75.id = "rectangle_75";
rectangle_75.style.left = "13px";
rectangle_75.style.top = "422px";
rectangle_75.style.width = "86px";
rectangle_75.style.height = "33px";
rectangle_75.style.borderRadius = "10px";
rectangle_75.style.background = 'rgba(188,209,255,1)';

page_messages_ek1.appendChild(rectangle_75);

var hey__saw_your_request_to_be_my_roommate = document.createElement("div");
hey__saw_your_request_to_be_my_roommate.innerHTML = "Hey, saw your request to be my roommate";
hey__saw_your_request_to_be_my_roommate.style.textAlign = "left";
hey__saw_your_request_to_be_my_roommate.id = "hey__saw_your_request_to_be_my_roommate";
hey__saw_your_request_to_be_my_roommate.style.left = "17px";
hey__saw_your_request_to_be_my_roommate.style.top = "224px";
hey__saw_your_request_to_be_my_roommate.style.width = "249.5px";
hey__saw_your_request_to_be_my_roommate.style.height = "24.5px";
hey__saw_your_request_to_be_my_roommate.style.fontFamily = "Poppins";
hey__saw_your_request_to_be_my_roommate.style.fontSize = "11px";
hey__saw_your_request_to_be_my_roommate.style.overflow = "hidden";
hey__saw_your_request_to_be_my_roommate.style.color = "#000000";

page_messages_ek1.appendChild(hey__saw_your_request_to_be_my_roommate);

var what_is_your_budget_like_ = document.createElement("div");
what_is_your_budget_like_.innerHTML = "What is your budget like?";
what_is_your_budget_like_.style.textAlign = "left";
what_is_your_budget_like_.id = "what_is_your_budget_like_";
what_is_your_budget_like_.style.left = "17px";
what_is_your_budget_like_.style.top = "268px";
what_is_your_budget_like_.style.width = "152.5px";
what_is_your_budget_like_.style.height = "24.5px";
what_is_your_budget_like_.style.fontFamily = "Poppins";
what_is_your_budget_like_.style.fontSize = "11px";
what_is_your_budget_like_.style.overflow = "hidden";
what_is_your_budget_like_.style.color = "#000000";

page_messages_ek1.appendChild(what_is_your_budget_like_);

var yeah_sure = document.createElement("div");
yeah_sure.innerHTML = "Yeah Sure";
yeah_sure.style.textAlign = "left";
yeah_sure.id = "yeah_sure";
yeah_sure.style.left = "25px";
yeah_sure.style.top = "430px";
yeah_sure.style.width = "71.5px";
yeah_sure.style.height = "24.5px";
yeah_sure.style.fontFamily = "Poppins";
yeah_sure.style.fontSize = "11px";
yeah_sure.style.overflow = "hidden";
yeah_sure.style.color = "#000000";

page_messages_ek1.appendChild(yeah_sure);












